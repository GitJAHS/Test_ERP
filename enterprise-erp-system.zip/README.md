# Material You Expressive ERP System

A state-of-the-art, offline-first Enterprise Resource Planning (ERP) platform designed inspired by Google's modern **Material You Design (Material 3)**. It is built entirely using **React**, **TypeScript**, and **Tailwind CSS**.

As an offline-first single-page application (SPA), this system works natively inside the browser, allowing single-user operators to manage complete enterprise workflows without requiring a database server or expensive cloud host. Data is persisted in browser storage and can be seamlessly backed up & synced to your **Google Drive** with **Sign in with Google** credentials.

---

## 🚀 Key Modules & Capabilities

1. **Material You Executive Dashboard**: High-fidelity KPI boxes displaying total CRM, active products, sales, cash collection, outstanding dues, raw procurement cost, and operational expenses paired with Material-styled SVG graphs for trending products and monthly custom acquisitions.
2. **CRM Customer Registry**: Maintain detailed biographical matrices (Credit ratings, status tracking, limits, NID/SSN data) with complete, proper sorting (by Name, Due, and Debt risk), date filtering, and live transaction profiles.
3. **Product Logistics & Inventory**: Real-time stock tracking with custom automated SKU generators, category filters, and reorder status badge alerts.
4. **Compile Checkout Checkout (Invoicing)**: Comprehensive multi-item ledger supporting customer lookup, staff salesperson assignment, linear line discounts, itemized tax rates, and dynamic promotional code deductions.
5. **Supplier Procurements**: Complete supplier lifecycle log with integrated Purchase Order compiling, status workflows, and automated stock replenishment.
6. **Accounts Finance Ledger**: Dynamic accounts-ledger tracking operational expenses, direct sales incomes, margins, and taxes.
7. **Human Resources & Payroll**: Staff rosters tracking bio directories (national IDs), positions, interactive attendance records, and pay slips.
8. **Operations & Logistic Delivery**: Delivery schedules supporting status queues, courier tracking numbers, and address routing profiles.
9. **Heads-Up Notification Hub**: Material-style interactive toasts popping from the top with custom countdown timers and an offline persistent notification log tray at the header bar.
10. **Unified System Configuration**: Custom branding settings, exchange currency config, and automatic **Google Drive API** backup synchronization.

---

## 🛠️ Tech Stack & Architecture

- **Framework**: React 18+ (bundled with Vite)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Animations**: `motion` (by Framer)
- **Icons**: Lucide icons
- **State Management**: React Context (`src/context/ERPContext.tsx`)
- **Persistence**: Hybrid Storage (HTML5 LocalStorage persistent engines + cloud-managed Google Drive Sync)

---

## 🌐 Deploying to GitHub Pages (Serverless)

Because this ERP is serverless-compatible, you can publish and run it completely free of charge on **GitHub Pages**.

### Step 1: Initialize Git Repository
In your local command terminal, run the following:
```bash
git init
git add .
git commit -m "Initialize Material You ERP System"
```

### Step 2: Push to GitHub
Create a new public or private repository on your GitHub account, then link and push the codebase:
```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git branch -M main
git push -u origin main
```

### Step 3: Install GitHub Pages Deploy Tool
Install the standard `gh-pages` helper tool to automate the static build deployment:
```bash
npm install -D gh-pages
```

### Step 4: Configure `package.json`
Open `package.json` and add a `"homepage"` field near the top pointing to your future URL:
```json
"homepage": "https://YOUR_USERNAME.github.io/YOUR_REPO_NAME",
```

Then add the deployment scripts under your `"scripts"` block:
```json
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -p dist",
  "dev": "vite",
  "build": "vite build",
  "lint": "tsc --noEmit"
}
```

### Step 5: Publish
Execute the deployment script:
```bash
npm run deploy
```
This compiles the application and pushes the production assets directly to a clean `gh-pages` branch on GitHub. Your ERP system will be live at `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME` within seconds!

---

## 🔒 Security & Google Workspace Settings

Authentication and backup operations use the **Google Identity Services ** SDK loaded directly at runtime.
To configure:
1. Visit the [Google Cloud Console API Credentials](https://console.cloud.google.com/apis/credentials).
2. Create an **OAuth 2.0 Web Application Client ID**.
3. Add your GitHub Pages URL (e.g., `https://YOUR_USERNAME.github.io`) to **Authorized JavaScript Origins**.
4. Enter this Client ID in your ERP Settings workspace under the Integration panel.

No server database is ever used; your company records remain fully under your control!
