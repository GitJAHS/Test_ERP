/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Address {
  street: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
}

export interface CustomerPersonalInfo {
  fullName: string;
  phone: string;
  email: string;
  gender: string;
  dateOfBirth: string;
  address: Address;
}

export interface CustomerBusinessInfo {
  customerType: 'retail' | 'wholesale' | 'vip';
  companyName: string;
  industry: string;
  source: 'manual' | 'referral' | 'online' | 'marketing';
}

export interface CustomerFinancialInfo {
  creditLimit: number;
  totalSpent: number;
  totalPaid: number;
  totalDue: number;
  loyaltyPoints: number;
  riskLevel: 'low' | 'medium' | 'high';
}

export interface Customer {
  id: string;
  createdAt: string;
  updatedAt: string;
  personalInfo: CustomerPersonalInfo;
  businessInfo: CustomerBusinessInfo;
  financialInfo: CustomerFinancialInfo;
  status: 'active' | 'inactive' | 'blocked';
}

export interface ProductBasicInfo {
  name: string;
  description: string;
  category: string;
  brand: string;
  size: string; // comma-separated
  notes: string;
}

export interface ProductPricing {
  costPrice: number;
  salePrice: number;
  taxRate: number; // percentage
  discount: number; // percentage
}

export interface ProductStock {
  quantity: number;
  reserved: number;
  available: number;
  reorderLevel: number;
  warehouseLocation: string;
}

export interface Product {
  id: string;
  sku: string;
  barcode: string;
  basicInfo: ProductBasicInfo;
  pricing: ProductPricing;
  stock: ProductStock;
  supplierId: string | null;
  status: 'active' | 'inactive' | 'discontinued';
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  address: string;
  paymentTerms: string;
  rating: number;
  suppliedProducts: string[]; // product IDs
}

export interface InvoiceItem {
  productId: string;
  name: string;
  size: string;
  quantity: number;
  unitPrice: number;
  discount: number; // raw value
  taxRate: number; // percentage
  subtotal: number; // after discount and tax
}

export interface InvoiceCalculations {
  subTotal: number;
  totalDiscount: number;
  totalTax: number;
  grandTotal: number;
}

export interface InvoicePayment {
  status: 'paid' | 'unpaid' | 'partial';
  method: 'cash' | 'bank' | 'mobile' | 'card' | 'cod';
  paidAmount: number;
  dueAmount: number;
  transactionId: string;
}

export interface Invoice {
  id: string;
  createdAt: string;
  updatedAt: string;
  businessId: string;
  customer: {
    customerId: string;
    name: string;
    phone: string;
    email: string;
    address: string;
  };
  seller: {
    id: string;
    name: string;
    role: string;
  } | null;
  items: InvoiceItem[];
  calculations: InvoiceCalculations;
  payment: InvoicePayment;
  status: 'draft' | 'issued' | 'partial' | 'paid';
  dueDate: string | null;
  promo: {
    code: string;
    discountAmount: number;
    promoId: string;
  } | null;
  note: string;
  terms: string;
  termsApplied: boolean;
  stockDeducted: boolean;
}

export interface SaleItem {
  productId: string;
  quantity: number;
  price: number;
}

export interface Sale {
  id: string;
  invoiceId: string;
  customerId: string;
  seller: {
    id: string;
    name: string;
    role: string;
  } | null;
  items: SaleItem[];
  totalAmount: number;
  profit: number;
  date: string;
  status: 'completed' | 'cancelled';
}

export interface IncomeRecord {
  id: string;
  source: 'invoice' | 'manual' | 'other';
  amount: number;
  date: string;
  referenceId?: string;
}

export interface ExpenseRecord {
  id: string;
  category: string;
  amount: number;
  date: string;
  note: string;
}

export interface FinanceState {
  income: IncomeRecord[];
  expenses: ExpenseRecord[];
}

export interface EmployeeJobInfo {
  department: string;
  role: string;
  status: 'active' | 'inactive' | 'terminated';
  salary: number;
  joinDate: string | null;
}

export interface Employee {
  id: string;
  personalInfo: {
    fullName: string;
    phone: string;
    email: string;
    address: string;
    NID: string;
    fatherName: string;
    motherName: string;
  };
  jobInfo: EmployeeJobInfo;
  attendance: never[]; // expandable placeholder
  payroll: never[]; // expandable placeholder
}

export interface PurchaseItem {
  productId: string;
  quantity: number;
  costPrice: number;
  size: string;
  notes: string;
}

export interface Purchase {
  id: string;
  supplierId: string;
  items: PurchaseItem[];
  totalCost: number;
  date: string;
  status: 'pending' | 'completed';
  paymentMethod?: string;
  transactionId?: string;
}

export interface Delivery {
  id: string;
  invoiceId: string;
  customerId: string;
  address: string;
  status: 'pending' | 'shipped' | 'delivered';
  tracking: { timestamp: string; location: string; status: string }[];
  cost: number;
}

export interface Offer {
  id: string;
  name: string;
  promoCode: string;
  type: 'percentage' | 'fixed';
  value: number;
  productId: string | null; // null means valid on all goods
  startDate: string | null;
  expiryDate: string | null;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Report {
  id: string;
  type: 'daily' | 'monthly' | 'custom';
  data: {
    totalSales: number;
    totalProfit: number;
    totalExpense: number;
  };
  generatedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  details: string;
}

export interface CompanyConfig {
  name: string;
  address: string;
  phone: string;
}

export interface ThemeConfig {
  mode: 'light' | 'dark';
  accentColor: string;
}

export interface GeneralSettings {
  autoBackup: boolean;
  performanceMode: 'standard' | 'high';
  googleClientId: string;
}

export interface SystemConfig {
  company: CompanyConfig;
  language: string;
  country: string;
  currency: string;
  timezone: string;
  theme: ThemeConfig;
  settings: GeneralSettings;
  logo: string | null; // base64 string or null
}

export interface BusinessProfile {
  id: string;
  name: string;
  createdAt: string;
}

export interface ERPDataState {
  customers: Customer[];
  products: Product[];
  invoices: Invoice[];
  sales: Sale[];
  finance: FinanceState;
  employees: Employee[];
  suppliers: Supplier[];
  purchases: Purchase[];
  deliveries: Delivery[];
  offers: Offer[];
  reports: Report[];
  auditLog: AuditLog[];
  config: SystemConfig;
}

export interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'error' | 'info' | 'warning';
}

export interface HeadsUpNotification {
  id: string;
  title: string;
  message: string;
  icon: string;
  type: 'success' | 'alert' | 'info' | 'warning';
  timestamp: string;
  durationMs: number;
}
