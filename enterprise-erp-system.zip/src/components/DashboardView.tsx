/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useERP } from '../context/ERPContext';
import { 
  Users, Package, DollarSign, FileText, ShoppingBag, 
  ArrowUpRight, ArrowDownRight, Award, TrendingUp, Calendar, ShoppingCart 
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const { data } = useERP();

  // Metric variables
  const totalCustomers = data.customers.length;
  const totalProducts = data.products.filter(p => p.status === 'active').length;
  
  // Total Revenue (issued / paid invoices totals)
  const totalSalesRevenue = data.invoices
    .filter(i => i.status === 'issued' || i.status === 'paid')
    .reduce((sum, current) => sum + (current.calculations?.grandTotal || 0), 0);

  // Total Payments Collected
  const totalPaidAmount = data.invoices
    .filter(i => i.status === 'issued' || i.status === 'paid')
    .reduce((sum, current) => sum + (current.payment?.paidAmount || 0), 0);

  // Total Outstanding Customer Due
  const totalOutstandingDue = data.customers
    .reduce((sum, current) => sum + (current.financialInfo?.totalDue || 0), 0);

  const totalExpenses = data.finance.expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const totalPurchases = data.purchases
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + (p.totalCost || 0), 0);

  // Profit calculations
  const netEarnings = totalPaidAmount - totalExpenses;

  // Recent 5 Invoices
  const recentInvoices = [...data.invoices]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: data.config.currency || 'USD'
    }).format(val || 0);
  };

  // Trending Products data preparation
  // Group sales items by product name
  const productQuantities: { [key: string]: { name: string; sold: number; stock: number } } = {};
  
  // Prefill with products so everything is loaded
  data.products.forEach(p => {
    productQuantities[p.id] = { name: p.basicInfo.name, sold: 0, stock: p.stock.available };
  });

  data.sales.forEach(s => {
    s.items.forEach(it => {
      if (productQuantities[it.productId]) {
        productQuantities[it.productId].sold += it.quantity;
      }
    });
  });

  const productChartData = Object.values(productQuantities)
    .sort((a, b) => b.sold - a.sold)
    .slice(0, 5);

  const maxSoldVolume = Math.max(...productChartData.map(p => p.sold), 1);

  // Customer registered over time (monthly / yearly buckets)
  // Let's create monthly bucket values
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyCustomerCounts: { [key: string]: number } = {};
  monthNames.forEach(m => (monthlyCustomerCounts[m] = 0));

  // Count creations
  data.customers.forEach(c => {
    const d = new Date(c.createdAt);
    const mName = monthNames[d.getMonth()];
    if (mName) monthlyCustomerCounts[mName]++;
  });

  const customerGraphPoints = monthNames.map((m, idx) => ({
    label: m,
    value: monthlyCustomerCounts[m]
  }));

  const maxCustomersBucket = Math.max(...customerGraphPoints.map(p => p.value), 1);

  // Financial comparative chart data (sales income vs expense vs net)
  const financesCompare = [
    { name: 'Direct Sales', value: totalPaidAmount, color: 'rgb(79, 55, 139)' }, // Primary UI
    { name: 'Internal Expenses', value: totalExpenses, color: 'rgb(186, 26, 26)' }, // Error red
    { name: 'Net Cash margin', value: Math.max(0, netEarnings), color: 'rgb(56, 107, 33)' } // Safe green
  ];
  const maxFinValue = Math.max(...financesCompare.map(f => f.value), 1);

  return (
    <div className="space-y-6">
      
      {/* 2. KPIs Layout Boxed Grid */}
      <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">Core Business Performance Indicators</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        {/* KPI: Customers */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Total CRM</span>
            <div className="w-8 h-8 rounded-full bg-indigo-50 dark:bg-indigo-950/40 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-neutral-900 dark:text-neutral-50">{totalCustomers}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Registered Accounts
            </p>
          </div>
        </div>

        {/* KPI: Products */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Active Stock Items</span>
            <div className="w-8 h-8 rounded-full bg-teal-50 dark:bg-teal-950/40 flex items-center justify-center text-teal-600 dark:text-teal-400">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-neutral-900 dark:text-neutral-50">{totalProducts}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Ready in Warehouse
            </p>
          </div>
        </div>

        {/* KPI: Revenue */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Sales (Invoiced)</span>
            <div className="w-8 h-8 rounded-full bg-indigo-50 dark:bg-indigo-950/40 flex items-center justify-center text-[#6750A4] dark:text-[#EADDFF]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-[#6750A4] dark:text-[#EADDFF]">{formatMoney(totalSalesRevenue)}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Gross billed transactions
            </p>
          </div>
        </div>

        {/* KPI: Cash Inflows Collected */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Cash Collected</span>
            <div className="w-8 h-8 rounded-full bg-emerald-50 dark:bg-emerald-950/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-emerald-600 dark:text-emerald-400">{formatMoney(totalPaidAmount)}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Cleared payments
            </p>
          </div>
        </div>

        {/* KPI: Outstanding Dues */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Outstanding Due</span>
            <div className="w-8 h-8 rounded-full bg-amber-50 dark:bg-amber-950/40 flex items-center justify-center text-amber-600 dark:text-amber-400">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-amber-600 dark:text-amber-400">{formatMoney(totalOutstandingDue)}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Receivable balances
            </p>
          </div>
        </div>

        {/* KPI: Purchases */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Procurements Cost</span>
            <div className="w-8 h-8 rounded-full bg-rose-50 dark:bg-rose-950/40 flex items-center justify-center text-rose-600 dark:text-rose-400">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-neutral-900 dark:text-neutral-50">{formatMoney(totalPurchases)}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Raw supplier costs
            </p>
          </div>
        </div>

        {/* KPI: Operating Expense */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Op Expenses</span>
            <div className="w-8 h-8 rounded-full bg-orange-50 dark:bg-orange-950/40 flex items-center justify-center text-orange-600 dark:text-orange-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h4 className="text-2xl font-bold font-sans tracking-tight text-neutral-900 dark:text-neutral-50">{formatMoney(totalExpenses)}</h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Tax, rent, bills & wages
            </p>
          </div>
        </div>

        {/* KPI: Net earnings */}
        <div className="bg-[#FAF8FE] dark:bg-[#1D1B20] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">Net Liquidity</span>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${netEarnings >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
              {netEarnings >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            </div>
          </div>
          <div className="mt-4">
            <h4 className={`text-2xl font-bold font-sans tracking-tight ${netEarnings >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
              {formatMoney(netEarnings)}
            </h4>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-1 flex items-center gap-0.5 font-medium">
              Income minus expenses
            </p>
          </div>
        </div>

      </div>

      {/* 3. CHARTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Chart 1: Trending Products Bar Chart */}
        <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 lg:col-span-1 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-neutral-800 dark:text-neutral-100 flex items-center gap-1.5 mb-1">
              <Award className="w-5 h-5 text-indigo-500" />
              Trending Products Index
            </h3>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-medium">Popular items by quantity sold</p>
          </div>
          
          <div className="space-y-4 my-6">
            {productChartData.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-center opacity-40">
                <Package className="w-10 h-10 mb-2" />
                <p className="text-xs">No active sales recorded for product charting.</p>
              </div>
            ) : (
              productChartData.map((item, idx) => {
                const ratio = (item.sold / maxSoldVolume) * 100;
                return (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-neutral-700 dark:text-neutral-300 truncate max-w-[150px]">{item.name}</span>
                      <span className="text-[11px] font-mono font-bold text-neutral-400">{item.sold} sold ({item.stock} left)</span>
                    </div>
                    {/* Material You Bar filled */}
                    <div className="w-full h-3 bg-neutral-100 dark:bg-neutral-800/80 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-[#EADDFF] dark:bg-[#4F378B] rounded-full border-r border-[#6750A4] transition-all duration-500 ease-in-out"
                        style={{ width: `${ratio}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
          <div className="border-t border-neutral-100 dark:border-neutral-800/80 pt-3 text-[10px] text-neutral-400 font-medium text-center">
            Logistics ranking updates automatically.
          </div>
        </div>

        {/* Chart 2: Monthly Customer Growth Line/Area Chart */}
        <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 lg:col-span-1 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-neutral-800 dark:text-neutral-100 flex items-center gap-1.5 mb-1">
              <Calendar className="w-5 h-5 text-teal-600" />
              Monthly Customer Acquisitions
            </h3>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-medium">New registrations across year timeline</p>
          </div>

          <div className="my-3 flex items-end justify-between h-40 pt-4 px-2">
            {customerGraphPoints.map((pt, idx) => {
              const hRatio = (pt.value / maxCustomersBucket) * 92; // Max out at 92% height
              return (
                <div key={idx} className="flex flex-col items-center flex-1 group">
                  <div className="h-28 w-full flex items-end justify-center pb-1">
                    <div 
                      className="w-1.5 sm:w-2 bg-[#E8DEF8] dark:bg-[#4A4458] group-hover:bg-[#6750A4] dark:group-hover:bg-[#D0BCFF] rounded-t-full transition-all duration-300 relative group-cursor-pointer"
                      style={{ height: `${Math.max(hRatio, 4)}%` }} // Minimum height 4% for design
                    >
                      {/* Tooltip on hover */}
                      <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-neutral-900 text-white rounded text-[9px] py-0.5 px-1.5 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none font-bold">
                        {pt.value} new
                      </div>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono leading-none text-neutral-400 mt-2">{pt.label}</span>
                </div>
              );
            })}
          </div>

          <div className="border-t border-neutral-100 dark:border-neutral-800/80 pt-3 flex justify-between items-center text-[10px] text-neutral-400 font-medium">
            <span>Period Tracker: Year 2026</span>
            <span className="font-bold text-neutral-600 dark:text-neutral-300">Total: {totalCustomers} Active</span>
          </div>
        </div>

        {/* Chart 3: Financial Margins Analysis */}
        <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 lg:col-span-1 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-neutral-800 dark:text-neutral-100 flex items-center gap-1.5 mb-1">
              <ShoppingCart className="w-5 h-5 text-purple-600" />
              Financial Liquidity Split
            </h3>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-medium">Profit vs Expenses breakdown</p>
          </div>

          <div className="space-y-4 my-6">
            {financesCompare.map((item, idx) => {
              const barWidth = (item.value / maxFinValue) * 100;
              return (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-neutral-700 dark:text-neutral-300">{item.name}</span>
                    <span className="font-mono text-neutral-500 font-semibold">{formatMoney(item.value)}</span>
                  </div>
                  <div className="w-full h-2.5 bg-neutral-100 dark:bg-neutral-800/80 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-500 ease-out"
                      style={{ 
                        width: `${Math.max(barWidth, 2)}%`,
                        backgroundColor: item.color
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border-t border-neutral-100 dark:border-neutral-800/80 pt-3 text-[10px] text-neutral-400 font-medium text-center">
            Cleared cash indicators updated in real-time.
          </div>
        </div>

      </div>

      {/* 4. RECENT INVOICES LEDGER VIEW */}
      <div className="bg-[#FAF8FE] dark:bg-[#1C1B1F] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-sm overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-sm text-neutral-900 dark:text-neutral-100 flex items-center gap-1.5">
            <TrendingUp className="w-5 h-5 text-[#6750A4]" />
            Recent Invoice Activities
          </h3>
          <span className="text-[10px] font-mono bg-indigo-50 dark:bg-indigo-950/20 text-[#21005D] dark:text-[#EADDFF] py-1 px-2.5 rounded-full font-bold">
            Live Stream
          </span>
        </div>
        
        <div className="relative overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
            <thead className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider border-b border-neutral-100 dark:border-neutral-800/80">
              <tr>
                <th className="py-3 px-4">Invoice ID</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Total Amount</th>
                <th className="py-3 px-4">Payment Method</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Date Recorded</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900">
              {recentInvoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-xs text-neutral-400">
                    No active invoice records compiled yet.
                  </td>
                </tr>
              ) : (
                recentInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{inv.id}</td>
                    <td className="py-3.5 px-4 font-semibold text-neutral-700 dark:text-neutral-300">{inv.customer.name}</td>
                    <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{formatMoney(inv.calculations?.grandTotal)}</td>
                    <td className="py-3.5 px-4 font-semibold text-neutral-500 uppercase">{inv.payment.method}</td>
                    <td className="py-3.5 px-4">
                      <span className={`inline-block py-1 px-3 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        inv.status === 'paid' 
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400'
                          : inv.status === 'partial'
                          ? 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400'
                          : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-900/20 dark:text-indigo-400'
                      }`}>
                        {inv.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-neutral-400 font-mono font-semibold">
                      {new Date(inv.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
