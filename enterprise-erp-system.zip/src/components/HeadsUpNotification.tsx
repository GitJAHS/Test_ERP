/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useERP } from '../context/ERPContext';
import { Bell, X, CheckCircle, AlertTriangle, AlertCircle, Info, Calendar } from 'lucide-react';

export const HeadsUpNotificationContainer: React.FC = () => {
  const { activeHeadsUp, clearHeadsUp } = useERP();
  const [percentLeft, setPercentLeft] = useState(100);

  useEffect(() => {
    if (!activeHeadsUp) return;

    setPercentLeft(100);
    const duration = activeHeadsUp.durationMs || 6000;
    const updateInterval = 50; // ms
    const decrements = (updateInterval / duration) * 100;

    const timer = setInterval(() => {
      setPercentLeft(prev => {
        const next = prev - decrements;
        if (next <= 0) {
          clearInterval(timer);
          clearHeadsUp();
          return 0;
        }
        return next;
      });
    }, updateInterval);

    return () => clearInterval(timer);
  }, [activeHeadsUp, clearHeadsUp]);

  const getThemeBg = () => {
    if (!activeHeadsUp) return '';
    switch (activeHeadsUp.type) {
      case 'success':
        return 'bg-emerald-50 border-emerald-200 text-emerald-900 dark:bg-emerald-950/40 dark:border-emerald-800/60 dark:text-emerald-150';
      case 'alert':
        return 'bg-rose-50 border-rose-200 text-rose-900 dark:bg-rose-950/40 dark:border-rose-800/60 dark:text-rose-150';
      case 'warning':
        return 'bg-amber-50 border-amber-200 text-amber-900 dark:bg-amber-950/40 dark:border-amber-850/60 dark:text-amber-100';
      default:
        return 'bg-[#F0EDF5] border-[#E5E1EC] text-indigo-950 dark:bg-[#1C1B1F] dark:border-[#49454F] dark:text-[#E6E1E5]';
    }
  };

  const getBarColor = () => {
    if (!activeHeadsUp) return '';
    switch (activeHeadsUp.type) {
      case 'success': return 'bg-emerald-500';
      case 'alert': return 'bg-rose-500';
      case 'warning': return 'bg-amber-500';
      default: return 'bg-indigo-600 dark:bg-indigo-400';
    }
  };

  const decodeIcon = (char: string) => {
    if (char === '📦') return <CheckCircle className="w-5 h-5 text-indigo-500" />;
    return <span className="text-xl self-center leading-none">{char}</span>;
  };

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[300] w-[92%] max-w-md pointer-events-none">
      <AnimatePresence>
        {activeHeadsUp && (
          <motion.div
            id="heads-up-card"
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className={`shadow-lg border rounded-3xl overflow-hidden backdrop-blur-md pointer-events-auto flex flex-col ${getThemeBg()}`}
          >
            <div className="p-4 flex gap-3 relative">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-white/50 dark:bg-black/20 flex items-center justify-center">
                {decodeIcon(activeHeadsUp.icon)}
              </div>
              <div className="flex-1 pr-6">
                <h4 className="font-bold text-sm tracking-tight">{activeHeadsUp.title}</h4>
                <p className="text-xs mt-1 leading-relaxed opacity-90">{activeHeadsUp.message}</p>
              </div>
              <button
                id="close-heads-up-btn"
                onClick={clearHeadsUp}
                className="absolute top-4 right-4 p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {/* Progress countdown bar */}
            <div className="w-full h-1 bg-black/5 dark:bg-white/10 mt-auto">
              <div
                className={`h-full transition-all duration-75 ease-linear ${getBarColor()}`}
                style={{ width: `${percentLeft}%` }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export const NotificationHistoryDrawer: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { headsUpHistory } = useERP();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay mask */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-[250] cursor-pointer"
          />
          {/* Panel */}
          <motion.div
            id="notification-history-panel"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.25 }}
            className="fixed right-0 top-0 bottom-0 w-full sm:max-w-md bg-white dark:bg-[#141218] border-l border-neutral-200 dark:border-neutral-800 shadow-2xl z-[260] flex flex-col"
          >
            <div className="p-5 border-b border-neutral-100 dark:border-neutral-900 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full bg-[#EADDFF] dark:bg-[#4F378B] flex items-center justify-center">
                  <Bell className="w-5 h-5 text-[#21005D] dark:text-[#EADDFF]" />
                </div>
                <h3 className="font-bold text-lg text-neutral-900 dark:text-neutral-100">System Notification Logs</h3>
              </div>
              <button
                id="close-history-btn"
                onClick={onClose}
                className="p-1 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {headsUpHistory.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                  <Bell className="w-12 h-12 mb-3 text-neutral-400" />
                  <p className="text-sm font-medium">No alerts recorded in this session.</p>
                </div>
              ) : (
                headsUpHistory.map(item => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl border border-neutral-100 dark:border-neutral-900 bg-neutral-50 dark:bg-neutral-950/30 flex gap-3"
                  >
                    <div className="text-xl self-start mt-0.5">{item.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-xs text-neutral-800 dark:text-neutral-200 truncate">{item.title}</span>
                        <span className="text-[10px] text-neutral-400 font-mono whitespace-nowrap">
                          {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 leading-relaxed">{item.message}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="p-4 border-t border-neutral-100 dark:border-neutral-900 bg-neutral-50 dark:bg-neutral-950/10 text-center text-[10px] text-neutral-400 font-medium">
              Real-time audit telemetry active. Logs stored recursively up to 50 counts.
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
