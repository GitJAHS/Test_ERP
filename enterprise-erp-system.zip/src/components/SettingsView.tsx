/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useERP } from '../context/ERPContext';
import { 
  Building, MapPin, Phone, Landmark, DollarSign, Cloud, CheckCircle2,
  Upload, Trash2, ShieldAlert, ArrowRight, Check, Database, RefreshCw, LogIn, Key
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { data, updateConfig, syncToGoogleDrive, connectGoogleDrive, disconnectGoogleDrive } = useERP();
  
  // Local state for configuration
  const [companyName, setCompanyName] = useState(data.config.company.name);
  const [address, setAddress] = useState(data.config.company.address);
  const [phone, setPhone] = useState(data.config.company.phone);
  const [currency, setCurrency] = useState(data.config.currency);
  const [vatRate, setVatRate] = useState(data.config.taxRate);

  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);

  // Handle image logo uploading
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      updateConfig({ logo: base64 });
    };
    reader.readAsDataURL(file);
  };

  const removeLogo = () => {
    updateConfig({ logo: null });
  };

  // Submit company detail changes
  const handleSave = () => {
    setSaving(true);
    updateConfig({
      currency,
      taxRate: vatRate,
      company: {
        name: companyName,
        address,
        phone
      }
    });
    setTimeout(() => {
      setSaving(false);
    }, 600);
  };

  // Trigger Google Drive sync backup immediately
  const handleTriggerSync = async () => {
    setSyncing(true);
    await syncToGoogleDrive();
    setSyncing(false);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      
      {/* 1. Header Hero Panel */}
      <div className="bg-[#FAF8FE] dark:bg-[#1C1B1F] border border-neutral-200 dark:border-neutral-800 p-6 rounded-[32px] shadow-sm select-none">
        <h3 className="text-xl font-bold text-neutral-900 dark:text-neutral-50 tracking-tight flex items-center gap-2">
          ⚙️ Workspace Configurations Panel
        </h3>
        <p className="text-xs text-neutral-450 mt-1 max-w-2xl leading-relaxed">
          Manage corporate billing presets, upload logo badges for dynamic PDF invoice voucher generation, and execute instant encrypted backups to Google Drive.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-semibold text-xs">
        
        {/* Left Column: Config Panel Form */}
        <div className="lg:col-span-2 bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-sm space-y-6">
          <h4 className="font-bold text-[#6750A4] dark:text-[#D0BCFF] text-sm uppercase tracking-wider flex items-center gap-1.5 border-b border-neutral-100 dark:border-neutral-900 pb-3">
            <Building className="w-5 h-5" /> Company Specifications
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Name */}
            <div>
              <label className="text-neutral-450 uppercase text-[10px] tracking-widest font-bold block mb-1">Company Trade Name</label>
              <input
                type="text"
                value={companyName}
                onChange={e => setCompanyName(e.target.value)}
                placeholder="Enterprise Corp"
                className="w-full border border-neutral-200 dark:border-neutral-800 rounded-2xl px-4 py-3 bg-transparent text-neutral-800 dark:text-neutral-100 placeholder-neutral-400"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="text-neutral-450 uppercase text-[10px] tracking-widest font-bold block mb-1">Support Telephone No.</label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+1 555-0199"
                className="w-full border border-neutral-200 dark:border-neutral-800 rounded-2xl px-4 py-3 bg-transparent text-neutral-800 dark:text-neutral-100 placeholder-neutral-400"
              />
            </div>

            {/* Address */}
            <div className="sm:col-span-2">
              <label className="text-neutral-450 uppercase text-[10px] tracking-widest font-bold block mb-1">Mail Corporate Address</label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                placeholder="45 Quantum Way, Suite 300, California"
                className="w-full border border-neutral-200 dark:border-neutral-800 rounded-2xl px-4 py-3 bg-transparent text-neutral-800 dark:text-neutral-100 placeholder-neutral-400"
              />
            </div>

            {/* Currency */}
            <div>
              <label className="text-neutral-450 uppercase text-[10px] tracking-widest font-bold block mb-1">Standard Billing Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value)}
                className="w-full border border-neutral-200 dark:border-neutral-800 rounded-2xl px-4 py-3 bg-white dark:bg-[#1C1B1F] text-neutral-800 dark:text-neutral-100"
              >
                <option value="USD">USD ($) Standard</option>
                <option value="EUR">EUR (€) Eurozone</option>
                <option value="GBP">GBP (£) Sterling</option>
                <option value="CAD">CAD (C$) Canadian</option>
                <option value="AUD">AUD (A$) Australian</option>
                <option value="INR">INR (₹) Rupees</option>
                <option value="JPY">JPY (¥) Yen</option>
              </select>
            </div>

            {/* VAT Rate */}
            <div>
              <label className="text-neutral-450 uppercase text-[10px] tracking-widest font-bold block mb-1">Standard Tax Charge (%)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={vatRate}
                onChange={e => setVatRate(Number(e.target.value))}
                placeholder="15%"
                className="w-full border border-neutral-200 dark:border-neutral-800 rounded-2xl px-4 py-3 bg-transparent text-neutral-800 dark:text-neutral-100 placeholder-neutral-400"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end pointer-events-auto">
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-3 bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] hover:opacity-90 transition-opacity font-bold rounded-full flex items-center gap-1 cursor-pointer select-none"
            >
              {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {saving ? 'Saving Specs...' : 'Save Specifications'}
            </button>
          </div>
        </div>

        {/* Right Column: Logo & Cloud Storage Sync Options */}
        <div className="space-y-6">
          
          {/* Logo Section */}
          <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-sm flex flex-col items-center">
            <h4 className="w-full font-bold text-neutral-800 dark:text-neutral-100 text-sm mb-4 text-left border-b border-neutral-100 dark:border-neutral-900 pb-3 flex items-center gap-2">
              📂 Voucher Logo Badge
            </h4>

            {data.config.logo ? (
              <div className="relative group p-3 bg-[#FAF8FE] rounded-3xl border border-neutral-150 shadow-sm flex flex-col items-center">
                <img src={data.config.logo} alt="Company Logo" className="max-h-[82px] max-w-full rounded-xl object-contain" />
                <button
                  onClick={removeLogo}
                  className="mt-3.5 px-4 py-1.5 rounded-full border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 font-bold text-[10px] cursor-pointer flex items-center gap-1 hover:opacity-90"
                >
                  <Trash2 className="w-3 h-3" /> Remove Logo
                </button>
              </div>
            ) : (
              <label className="border-2 border-dashed border-neutral-200 dark:border-neutral-800 hover:border-[#6750A4] cursor-pointer rounded-2xl p-6 w-full flex flex-col items-center text-center transition-colors font-semibold py-8 bg-neutral-50/20 dark:bg-transparent">
                <Upload className="w-8 h-8 text-neutral-400 mb-2" />
                <span className="text-xs text-neutral-800 dark:text-neutral-200 block">Click or Drag Image</span>
                <span className="text-[10px] text-neutral-400 block mt-1">PNG, JPG, SVG max 1MB</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {/* Cloud Storage Backups Section */}
          <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-sm space-y-4">
            <h4 className="font-bold text-neutral-800 dark:text-neutral-100 text-sm border-b border-neutral-100 dark:border-neutral-900 pb-3 flex items-center gap-2">
              <Cloud className="w-5 h-5 text-sky-500" /> Automated Cloud Sync
            </h4>

            <p className="text-[11px] leading-relaxed text-neutral-400">
              Synchronize your database directly to Google Drive as an encapsulated backup file `erp-backup-store.json`. Allows instant recovery if your LocalStorage gets cleared.
            </p>

            {data.googleToken ? (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-150 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-400 rounded-2xl flex gap-2">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <div>
                  <div className="font-bold">Google Driver connected</div>
                  <div className="text-[9px] mt-0.5 opacity-80 font-mono">Scope: drive.file enabled</div>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-neutral-50 dark:bg-neutral-950/10 border border-neutral-200 dark:border-neutral-850 rounded-2xl flex gap-2">
                <Database className="w-5 h-5 text-neutral-450" />
                <div>
                  <div className="font-bold text-neutral-550 dark:text-neutral-400">Offline-first mode is active</div>
                  <div className="text-[9px] mt-0.5 text-neutral-450 font-medium">Connect dynamic Drive below</div>
                </div>
              </div>
            )}

            <div className="space-y-2 pt-2 pointer-events-auto">
              {!data.googleToken ? (
                <button
                  onClick={connectGoogleDrive}
                  className="w-full py-3 rounded-2xl bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] hover:opacity-90 font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm shadow-indigo-600/5 select-none"
                >
                  <LogIn className="w-4 h-4" /> Sign In & Connect Drive
                </button>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={handleTriggerSync}
                    disabled={syncing}
                    className="w-full py-3 rounded-2xl border border-emerald-150 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/15 font-bold flex items-center justify-center gap-2 cursor-pointer select-none"
                  >
                    <RefreshCw className={`w-4 h-4 ${syncing && 'animate-spin'}`} />
                    {syncing ? 'Backing Up...' : 'Execute Backup Sync'}
                  </button>
                  <button
                    onClick={disconnectGoogleDrive}
                    className="w-full py-2.5 rounded-2xl border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 font-bold flex items-center justify-center gap-1.5 cursor-pointer select-none"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Disconnect Google API
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
