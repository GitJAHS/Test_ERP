/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useERP } from '../context/ERPContext';
import { 
  Search, Calendar, ArrowUpDown, ChevronDown, Printer, Mail, 
  Trash, Edit2, QrCode, Phone, Mail as MailIcon, Star, Filter, TrendingUp, RefreshCw
} from 'lucide-react';
import { Customer, Product, Invoice, Sale, Employee, Supplier, Purchase, Delivery, Offer, Report } from '../types';

// ==================== REUSABLE HEADERS & LOGIC ====================
interface FilterSortHeaderProps {
  onSearchChange: (val: string) => void;
  searchPlaceholder?: string;
  onStartDateChange?: (val: string) => void;
  onEndDateChange?: (val: string) => void;
  startDate?: string;
  endDate?: string;
  onFilterSelectChange?: (val: string) => void;
  filterOptions?: { value: string; label: string }[];
  addButtonLabel?: string;
  onAddClick?: () => void;
}

const TableHeaderSection: React.FC<FilterSortHeaderProps> = ({ 
  searchPlaceholder, searchValue, onSearchChange, 
  fromD, setFromD, toD, setToD, onClearFilters, addButtonLabel, onAddClick 
}) => {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between py-3">
      {/* Search Input */}
      <div className="relative max-w-sm w-full pointer-events-auto">
        <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          value={searchValue}
          onChange={e => onSearchChange(e.target.value)}
          placeholder={searchPlaceholder || "Quick search rows..."}
          className="border border-neutral-200 dark:border-neutral-800 rounded-full pl-10 pr-4 py-2.5 text-xs bg-transparent w-full pointer-events-auto shadow-sm"
        />
      </div>

      {/* Operations (Date Range + Action Button) */}
      <div className="flex flex-wrap items-center gap-3">
        {setFromD && setToD && (
          <div className="flex flex-wrap items-center gap-2 bg-[#FAF8FE] dark:bg-[#1C1B1F] p-1.5 border border-neutral-200 dark:border-neutral-800 rounded-[20px] shadow-sm select-none">
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wide px-2">Timeline Range:</span>
            <input
              type="date"
              value={fromD}
              onChange={e => setFromD(e.target.value)}
              className="bg-transparent text-[11px] font-mono border-none outline-none text-neutral-700 dark:text-neutral-300 py-1"
            />
            <span className="text-neutral-300">—</span>
            <input
              type="date"
              value={toD}
              onChange={e => setToD(e.target.value)}
              className="bg-transparent text-[11px] font-mono border-none outline-none text-neutral-700 dark:text-neutral-300 py-1"
            />
            {(fromD || toD) && (
              <button
                onClick={onClearFilters}
                className="text-[10px] font-bold text-red-500 hover:underline px-2 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        )}

        {onAddClick && addButtonLabel && (
          <button
            onClick={onAddClick}
            className="px-5 py-2.5 rounded-full bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] hover:opacity-90 transition-opacity font-bold text-xs flex items-center gap-1 cursor-pointer pointer-events-auto shadow-md shadow-indigo-600/5 select-none"
          >
            <Plus className="w-4 h-4" /> {addButtonLabel}
          </button>
        )}
      </div>
    </div>
  );
};

interface FilterSortHeaderProps {
  searchPlaceholder?: string;
  searchValue: string;
  onSearchChange: (v: string) => void;
  fromD?: string;
  setFromD?: (v: string) => void;
  toD?: string;
  setToD?: (v: string) => void;
  onClearFilters?: () => void;
  addButtonLabel?: string;
  onAddClick?: () => void;
}

const Plus: React.FC<{ className?: string }> = ({ className }) => <PlusIcon className={className} />;
import { Plus as PlusIcon } from 'lucide-react';

// ==================== DETAILED INVOICE PRINTER AND DOWNLOADER ====================
// Standard HTML template renderer matches classical specs perfectly
const generateHTMLInvoiceTemplate = (inv: Invoice, companyName: string, companyConf: any, currencyCode: string, logoBase64: string | null) => {
  const invDate = new Date(inv.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const dueDate = inv.dueDate ? new Date(inv.dueDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : 'standard Net 30';
  
  const logoHTML = logoBase64 ? `<img src="${logoBase64}" style="max-height: 50px; margin-bottom: 12px; border-radius: 8px;">` : `<span style="font-size: 24px; font-weight: 800; color: #6750A4;">🏢 ${companyName}</span>`;

  const rowsHTML = inv.items.map(it => `
    <tr class="item">
      <td><span style="font-family: monospace; font-weight: bold;">${it.productId}</span><br><small style="color: #888;">${it.name}</small></td>
      <td>${it.size || 'Standard'}</td>
      <td style="text-align: center;">${it.quantity}</td>
      <td style="text-align: right;">${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(it.unitPrice)}</td>
      <td style="text-align: right; color: rgb(186, 26, 26);">${it.discount > 0 ? '-' + new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(it.discount) : '—'}</td>
      <td style="text-align: right;">${it.taxRate}%</td>
      <td style="text-align: right; font-weight: bold;">${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(it.subtotal)}</td>
    </tr>
  `).join('');

  return `
    <html>
      <head>
        <meta charset="utf-8">
        <title>Invoice - ${inv.id}</title>
        <style>
          body { font-family: 'Segoe UI', system-ui, sans-serif; color: #444; background: #fff; line-height: 1.4; padding: 20px; margin: 0; }
          .invoice-box { max-width: 800px; margin: auto; padding: 30px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0,0,0,.05); border-radius: 16px; position: relative; }
          .header { display: flex; justify-content: space-between; align-items: start; margin-bottom: 40px; }
          .title { font-size: 28px; font-weight: 800; color: #1D1B20; margin: 0 0 4px 0; }
          .meta-info { text-align: right; }
          .meta-info h2 { margin: 0 0 5px 0; font-size: 24px; color: #6750A4; }
          .meta-info p { margin: 0; font-size: 11px; text-transform: uppercase; font-weight: bold; color: #888; }
          .contacts { display: flex; justify-content: space-between; gap: 20px; margin-bottom: 30px; }
          .contacts h4 { margin: 0 0 8px; font-size: 11px; font-bold; text-transform: uppercase; color: #6750A4; tracking-widest; border-bottom: 1.5px solid #EADDFF; padding-bottom: 3px; }
          .contacts p { margin: 4px 0; font-size: 13px; line-height: 1.3; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
          th { background: #FAF8FE; color: #49454F; font-size: 10px; font-weight: bold; text-transform: uppercase; border-bottom: 2px solid #EADDFF; padding: 12px 10px; text-align: left; }
          td { border-bottom: 1px solid #E8DEF8; padding: 12px 10px; font-size: 13px; }
          tr.item:hover { background: #fafafa; }
          .summary-side { display: flex; justify-content: flex-end; margin-bottom: 30px; }
          .summary-table { width: 300px; margin: 0; }
          .summary-table td { padding: 8px 10px; border-bottom: 1px solid #eee; text-align: right; font-size: 13px; }
          .summary-table td:first-child { text-align: left; font-weight: bold; color: #666; }
          .summary-table tr.total-row td { border-top: 1.5px solid #6750A4; font-size: 16px; font-weight: bold; color: #1D1B20; }
          .notes { background: #fbfbfb; border: 1.5px dashed #EADDFF; padding: 15px; border-radius: 12px; margin-bottom: 40px; font-size: 12px; }
          .footer { text-align: center; border-top: 1px solid #eee; padding-top: 20px; color: #999; font-size: 12px; font-weight: 500; }
          .qr-box { margin-bottom: 12px; text-align: right; }
          @media print { .no-print { display: none !important; } .invoice-box { border: none; box-shadow: none; padding: 0; } }
          .tools-row { display: flex; justify-content: space-between; max-width: 800px; margin: 0 auto 20px auto; }
          .btn { background: #6750A4; color: #fff; border: none; padding: 10px 20px; border-radius: 20px; font-weight: bold; font-size: 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; }
          .btn-outlined { background: transparent; color: #6750A4; border: 1.5px solid #6750A4; }
        </style>
      </head>
      <body>
        <div class="tools-row no-print">
          <button class="btn" onclick="window.print()">🖨️ Print Invoice</button>
          <button class="btn btn-outlined" onclick="window.close()">Close Window</button>
        </div>
        <div class="invoice-box">
          <div class="header">
            <div>
              ${logoHTML}
              <p style="margin: 6px 0; font-size: 13px;">${companyConf.address}<br>Phone: ${companyConf.phone}</p>
            </div>
            <div class="meta-info">
              <div class="title">INVOICE</div>
              <p>ID: <span style="font-family: monospace; font-size: 13px; font-weight: 800; color: #000;">${inv.id}</span></p>
              <div class="qr-box">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=72x72&data=${encodeURIComponent(JSON.stringify({ id: inv.id, total: inv.calculations.grandTotal }))}" alt="Scan code" style="border: 1.5px solid #EADDFF; border-radius: 8px;">
              </div>
            </div>
          </div>

          <div class="contacts">
            <div style="width: 48%;">
              <h4>Bill To Person</h4>
              <p><strong>${inv.customer.name}</strong></p>
              <p>${inv.customer.address}</p>
              <p>Phone: ${inv.customer.phone}</p>
              <p>Email: ${inv.customer.email}</p>
            </div>
            <div style="width: 48%; text-align: right;">
              <h4>Filing Particulars</h4>
              <p><strong>Created:</strong> ${invDate}</p>
              <p><strong>Due Maturity:</strong> ${dueDate}</p>
              <p><strong>Filing Standard:</strong> ON-LINE CLOUD SECURE</p>
              <p><strong>Filing Operator:</strong> ${inv.seller?.name || 'Self managed'}</p>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Product Information</th>
                <th>Selected Size</th>
                <th style="text-align: center;">Qty</th>
                <th style="text-align: right;">Unit Price</th>
                <th style="text-align: right;">Disc</th>
                <th style="text-align: right;">VAT Tax</th>
                <th style="text-align: right;">Net Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHTML}
            </tbody>
          </table>

          <div class="summary-side">
            <table class="summary-table">
              <tr>
                <td>Group Subtotal</td>
                <td>${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(inv.calculations.subTotal)}</td>
              </tr>
              <tr>
                <td>Aggregate Discounts</td>
                <td style="color: rgb(186, 26, 26); font-weight: bold;">-${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(inv.calculations.totalDiscount)}</td>
              </tr>
              <tr>
                <td>Calculated VAT</td>
                <td>+${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(inv.calculations.totalTax)}</td>
              </tr>
              <tr class="total-row">
                <td>GRAND NET TOTAL</td>
                <td>${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(inv.calculations.grandTotal)}</td>
              </tr>
              <tr>
                <td>Amount Paid Ledger</td>
                <td style="color: rgb(56, 107, 33); font-weight: bold;">${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(inv.payment.paidAmount)}</td>
              </tr>
              <tr style="font-weight: bold;">
                <td>Outstanding Bal Due</td>
                <td class="outstanding" style="color: rgb(186, 26, 26);">${new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(inv.payment.dueAmount)}</td>
              </tr>
            </table>
          </div>

          <div class="notes">
            <strong>Voucher Audit Notes:</strong>
            <p style="margin: 5px 0 0 0;">${inv.note || 'No custom notes file attached.'}</p>
            ${inv.termsApplied ? `<p style="margin: 10px 0 0 0; font-size: 11px; color:#777;"><strong style="color: #6750A4;">Standard terms implemented:</strong> ${inv.terms}</p>` : ''}
          </div>

          <div class="footer">
            <p>Thank you for doing business with ${companyName}</p>
            <p style="font-size: 9px; color: #999;">ERP System compiled invoice telemetries are secured via offline LocalStorage database.</p>
          </div>
        </div>
      </body>
    </html>
  `;
};

// ==================== CUSTOMER LIST ====================
export const CustomerListView: React.FC<{ onEdit: (c: Customer) => void }> = ({ onEdit }) => {
  const { data, deleteCustomer } = useERP();
  const [search, setSearch] = useState('');
  const [colSort, setColSort] = useState<'name' | 'spent' | 'id'>('name');
  const [asc, setAsc] = useState(true);

  // Sorting
  const sorted = [...data.customers].filter(c => {
    return c.personalInfo.fullName.toLowerCase().includes(search.toLowerCase()) ||
           c.personalInfo.phone.includes(search) ||
           (c.businessInfo.companyName && c.businessInfo.companyName.toLowerCase().includes(search.toLowerCase()));
  }).sort((a,b) => {
    let outcome = 0;
    if (colSort === 'name') outcome = a.personalInfo.fullName.localeCompare(b.personalInfo.fullName);
    if (colSort === 'spent') outcome = a.financialInfo.totalSpent - b.financialInfo.totalSpent;
    if (colSort === 'id') outcome = a.id.localeCompare(b.id);
    return asc ? outcome : -outcome;
  });

  const toggleSort = (col: 'name' | 'spent' | 'id') => {
    if (colSort === col) setAsc(!asc);
    else { setColSort(col); setAsc(true); }
  };

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
      <TableHeaderSection 
        searchPlaceholder="Search customer by name, corporation, phone..." 
        searchValue={search} 
        onSearchChange={setSearch} 
      />
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900">
        <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4 flex items-center gap-1 cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('id')}>Customer ID <ArrowUpDown className="w-3 h-3" /></th>
              <th className="py-3 px-4 cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('name')}>Profile Details <ArrowUpDown className="w-3 h-3" /></th>
              <th className="py-3 px-4">Contact</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4 cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('spent')}>Total Spent <ArrowUpDown className="w-3 h-3" /></th>
              <th className="py-3 px-4">Dues Balance</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
            {sorted.length === 0 ? (
              <tr><td colSpan={8} className="py-8 text-center text-xs text-neutral-400">No matching customer logs found.</td></tr>
            ) : (
              sorted.map(c => (
                <tr key={c.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                  <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{c.id}</td>
                  <td className="py-4 px-4">
                    <div className="font-semibold text-neutral-800 dark:text-neutral-150 text-sm leading-tight">{c.personalInfo.fullName}</div>
                    {c.businessInfo.companyName && <div className="text-[10px] text-neutral-400 mt-0.5">{c.businessInfo.companyName} ({c.businessInfo.industry})</div>}
                  </td>
                  <td className="py-4 px-4">
                    <div>{c.personalInfo.phone}</div>
                    {c.personalInfo.email && <div className="text-[10px] text-neutral-400 mt-0.5">{c.personalInfo.email}</div>}
                  </td>
                  <td className="py-4 px-4">
                    <span className="capitalize px-2.5 py-1 text-[10px] font-bold rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                      {c.businessInfo.customerType}
                    </span>
                  </td>
                  <td className="py-4 px-4 font-bold text-neutral-900 dark:text-neutral-100 font-mono">
                    {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(c.financialInfo.totalSpent)}
                  </td>
                  <td className="py-4 px-4 font-bold font-mono text-rose-500">
                    {c.financialInfo.totalDue > 0 ? new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(c.financialInfo.totalDue) : '—'}
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full ${
                      c.status === 'active' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400' 
                                            : 'bg-rose-50 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400'
                    }`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex gap-2 justify-end pointer-events-auto">
                      <button onClick={() => onEdit(c)} className="p-2 border border-neutral-250 dark:border-neutral-850 hover:bg-neutral-50 dark:hover:bg-neutral-800 rounded-xl cursor-pointer">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => deleteCustomer(c.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== PRODUCT LIST ====================
export const ProductListView: React.FC<{ onEdit: (p: Product) => void }> = ({ onEdit }) => {
  const { data, deleteProduct } = useERP();
  const [search, setSearch] = useState('');
  const [colSort, setColSort] = useState<'sku' | 'price' | 'qty'>('price');
  const [asc, setAsc] = useState(true);

  const sorted = [...data.products].filter(p => {
    return p.basicInfo.name.toLowerCase().includes(search.toLowerCase()) ||
           p.sku.toLowerCase().includes(search.toLowerCase()) ||
           p.basicInfo.category.toLowerCase().includes(search.toLowerCase());
  }).sort((a,b) => {
    let outcome = 0;
    if (colSort === 'sku') outcome = a.sku.localeCompare(b.sku);
    if (colSort === 'price') outcome = a.pricing.salePrice - b.pricing.salePrice;
    if (colSort === 'qty') outcome = a.stock.available - b.stock.available;
    return asc ? outcome : -outcome;
  });

  const toggleSort = (col: 'sku' | 'price' | 'qty') => {
    if (colSort === col) setAsc(!asc);
    else { setColSort(col); setAsc(true); }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
        <TableHeaderSection 
          searchPlaceholder="Search catalog stock by SKU, product category..." 
          searchValue={search} 
          onSearchChange={setSearch} 
        />
        <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900">
          <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
            <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
              <tr>
                <th className="py-3 px-4 cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('sku')}>SKU Item <ArrowUpDown className="w-3 h-3" /></th>
                <th className="py-3 px-4">Descriptions</th>
                <th className="py-3 px-4">Catalog specs</th>
                <th className="py-3 px-4 text-right">Retail Price</th>
                <th className="py-3 px-4 text-right">Cost Value</th>
                <th className="py-3 px-4 text-center cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('qty')}>Stock Count <ArrowUpDown className="w-3 h-3" /></th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
              {sorted.length === 0 ? (
                <tr><td colSpan={8} className="py-8 text-center text-xs text-neutral-400">No catalog products registered.</td></tr>
              ) : (
                sorted.map(p => {
                  const critical = p.stock.available < p.stock.reorderLevel;
                  return (
                    <tr key={p.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                      <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{p.sku}</td>
                      <td className="py-4 px-4">
                        <div className="font-semibold text-neutral-800 dark:text-neutral-150 text-sm leading-snug">{p.basicInfo.name}</div>
                        {p.barcode && <div className="text-[10px] text-neutral-400 font-mono mt-0.5">UPC: {p.barcode}</div>}
                      </td>
                      <td className="py-4 px-4 text-neutral-500">
                        <div>Size: {p.basicInfo.size || '—'}</div>
                        <div className="text-[10px] text-neutral-400 font-semibold mt-0.5">Dept: {p.basicInfo.category}</div>
                      </td>
                      <td className="py-4 px-4 text-right font-bold text-neutral-900 dark:text-neutral-50 font-mono">
                        {p.pricing.discount > 0 && <span className="line-through text-[10px] text-rose-500 mr-1 opacity-70">{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(p.pricing.salePrice)}</span>}
                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(p.pricing.salePrice * (1 - p.pricing.discount / 100))}
                      </td>
                      <td className="py-4 px-4 text-right text-neutral-450 dark:text-neutral-400 font-mono">
                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(p.pricing.costPrice)}
                      </td>
                      <td className="py-4 px-4 text-center">
                        <div className={`font-bold font-mono text-sm leading-tight ${critical ? 'text-rose-500 animate-blink' : 'text-emerald-600'}`}>
                          {p.stock.available} / {p.stock.quantity}
                        </div>
                        <span className="text-[9px] text-neutral-400 uppercase tracking-widest block font-bold mt-0.5">
                          {critical ? '⚠️ Critical stock' : `Aisle: ${p.stock.warehouseLocation || 'A'}`}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-center">
                        <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full ${
                          p.status === 'active' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400' 
                                                : 'bg-rose-50 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400'
                        }`}>
                          {p.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex gap-2 justify-end pointer-events-auto">
                          <button onClick={() => onEdit(p)} className="p-2 border border-neutral-250 dark:border-neutral-850 hover:bg-neutral-50 dark:hover:bg-neutral-800 rounded-xl cursor-pointer">
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => deleteProduct(p.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ==================== INVOICE LIST ====================
export const InvoiceListView: React.FC<{ onEdit: (i: Invoice) => void }> = ({ onEdit }) => {
  const { data, deleteInvoice } = useERP();
  const [search, setSearch] = useState('');
  
  // Date intervals
  const [fromD, setFromD] = useState('');
  const [toD, setToD] = useState('');

  const [activeQRURL, setActiveQRURL] = useState<string | null>(null);

  // Sorting
  const [colSort, setColSort] = useState<'id' | 'grand' | 'date'>('id');
  const [asc, setAsc] = useState(false);

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(val || 0);
  };

  const sortedInvoices = [...data.invoices].filter(i => {
    const term = search.toLowerCase();
    const matchSearch = i.id.toLowerCase().includes(term) ||
                        i.customer.name.toLowerCase().includes(term) ||
                        i.customer.phone.includes(term);

    const invoiceDate = new Date(i.createdAt);
    let matchFrom = true;
    let matchTo = true;

    if (fromD) {
      const fromDObj = new Date(fromD + 'T00:00:00');
      matchFrom = invoiceDate >= fromDObj;
    }
    if (toD) {
      const toDObj = new Date(toD + 'T23:59:59');
      matchTo = invoiceDate <= toDObj;
    }

    return matchSearch && matchFrom && matchTo;
  }).sort((a,b) => {
    let outcome = 0;
    if (colSort === 'id') outcome = a.id.localeCompare(b.id);
    if (colSort === 'grand') outcome = a.calculations.grandTotal - b.calculations.grandTotal;
    if (colSort === 'date') outcome = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    return asc ? outcome : -outcome;
  });

  const toggleSort = (col: 'id' | 'grand' | 'date') => {
    if (colSort === col) setAsc(!asc);
    else { setColSort(col); setAsc(true); }
  };

  const clearFilters = () => {
    setFromD('');
    setToD('');
  };

  // Launch Invoice Printable interface in secondary tab
  const launchPrintWindow = (inv: Invoice) => {
    const companyConf = data.config.company;
    const bodyStr = generateHTMLInvoiceTemplate(inv, companyConf.name, companyConf, data.config.currency, data.config.logo);
    const win = window.open('', '_blank', 'width=840,height=800');
    if (win) {
      win.document.open();
      win.document.write(bodyStr);
      win.document.close();
      win.focus();
    }
  };

  // Mail to trigger (download triggers + prefill mailto)
  const triggerEmailPdfRemind = (inv: Invoice) => {
    const mailtoSubject = `Invoice Remind #${inv.id} balances outstanding`;
    const mailtoBody = `Dear ${inv.customer.name},\n\nProvide dynamic payment remit for invoice ${inv.id}.\nOutstanding Due balance: ${formatMoney(inv.payment.dueAmount)}\n\nBest regards,\n${data.config.company.name}`;
    window.location.href = `mailto:${inv.customer.email}?subject=${encodeURIComponent(mailtoSubject)}&body=${encodeURIComponent(mailtoBody)}`;
  };

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
      <TableHeaderSection 
        searchPlaceholder="Filter invoice ID, client phone numbers..." 
        searchValue={search} 
        onSearchChange={setSearch} 
        fromD={fromD}
        setFromD={setFromD}
        toD={toD}
        setToD={setToD}
        onClearFilters={clearFilters}
      />
      
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900">
        <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4 cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('id')}>Invoice ID <ArrowUpDown className="w-3 h-3" /></th>
              <th className="py-3 px-4">Contact Client</th>
              <th className="py-3 px-4 text-center">Items count</th>
              <th className="py-3 px-4 text-right cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('grand')}>Grand Total <ArrowUpDown className="w-3 h-3" /></th>
              <th className="py-3 px-4 text-right">Payments Received</th>
              <th className="py-3 px-4 text-center cursor-pointer pointer-events-auto select-none" onClick={() => toggleSort('date')}>Date generated <ArrowUpDown className="w-3 h-3" /></th>
              <th className="py-3 px-4 text-center">Maturity Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium whitespace-nowrap">
            {sortedInvoices.length === 0 ? (
              <tr><td colSpan={8} className="py-8 text-center text-xs text-neutral-400">No dynamic invoices issued during this period.</td></tr>
            ) : (
              sortedInvoices.map(i => {
                const badDue = i.payment.dueAmount > 0 && i.dueDate && new Date(i.dueDate) <= new Date();
                return (
                  <tr key={i.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                    <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{i.id}</td>
                    <td className="py-4 px-4">
                      <div className="font-semibold text-neutral-850 dark:text-neutral-150 leading-tight">{i.customer.name}</div>
                      <div className="text-[10px] text-neutral-400 font-mono mt-0.5">{i.customer.phone}</div>
                    </td>
                    <td className="py-4 px-4 text-center text-neutral-700 dark:text-neutral-300 font-mono">
                      {i.items.reduce((s, it) => s + it.quantity, 0)}
                    </td>
                    <td className="py-4 px-4 text-right font-bold text-neutral-900 dark:text-neutral-100 font-mono">
                      {formatMoney(i.calculations.grandTotal)}
                    </td>
                    <td className="py-4 px-4 text-right text-emerald-600 font-mono">
                      {formatMoney(i.payment.paidAmount)}
                    </td>
                    <td className="py-4 px-4 text-center text-neutral-450 font-semibold font-mono">
                      {new Date(i.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className={`inline-block py-1 px-3 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        i.status === 'paid' 
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-990/30'
                          : badDue 
                          ? 'bg-red-50 text-red-700 dark:bg-red-950/30 animate-blink'
                          : 'bg-amber-50 text-amber-700 dark:bg-amber-950/30'
                      }`}>
                        {i.status} {badDue && ' Overdue'}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="flex gap-2 justify-end pointer-events-auto">
                        <button onClick={() => {
                          const payloadJSON = JSON.stringify({ id: i.id, total: i.calculations.grandTotal });
                          setActiveQRURL(`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(payloadJSON)}`);
                        }} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer" title="QR Code verification">
                          <QrCode className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => launchPrintWindow(i)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer" title="Print Ledger">
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => triggerEmailPdfRemind(i)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer" title="Compose Email reminder">
                          <Mail className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => onEdit(i)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => deleteInvoice(i.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                          <Trash className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Slide-out QR code dialog validation */}
      {activeQRURL && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm pointer-events-auto">
          <div className="bg-white dark:bg-[#1C1B1F] p-8 rounded-[36px] max-w-sm border border-neutral-100 dark:border-neutral-850 shadow-2xl flex flex-col items-center select-none animate-scale-up">
            <h4 className="font-bold text-sm tracking-tight text-neutral-900 dark:text-neutral-50 mb-1">Invoice Validation QR Code</h4>
            <p className="text-[10px] text-neutral-450 mb-6 text-center font-medium leading-relaxed">Let consumers scan to verify order profile totals & invoice identifiers instantly on client portals</p>
            <div className="p-4 bg-white rounded-3xl border border-neutral-100 shadow-md">
              <img src={activeQRURL} alt="invoice code" className="w-[180px] h-[180px]" />
            </div>
            <button onClick={() => setActiveQRURL(null)} className="mt-8 px-6 py-2 bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] font-semibold text-xs rounded-full hover:opacity-90 cursor-pointer pointer-events-auto">
              Close Code Drawer
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

// ==================== SALES LEDGER LIST ====================
export const SalesListView: React.FC = () => {
  const { data } = useERP();
  const [search, setSearch] = useState('');

  const filtered = data.sales.filter(s => {
    return s.id.toLowerCase().includes(search.toLowerCase()) ||
           s.invoiceId.toLowerCase().includes(search.toLowerCase()) ||
           s.customerId.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
      <TableHeaderSection 
        searchPlaceholder="Quick filter sales transactions, client references..." 
        searchValue={search} 
        onSearchChange={setSearch} 
      />
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900">
        <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4">Sales Ticket ID</th>
              <th className="py-3 px-4">Origin invoice</th>
              <th className="py-3 px-4">Authorized Agent</th>
              <th className="py-3 px-4 text-right">Gross revenue</th>
              <th className="py-3 px-4 text-right">Net Profit</th>
              <th className="py-3 px-4 text-center">Filing Date</th>
              <th className="py-3 px-4 text-center">Roster Code</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
            {filtered.length === 0 ? (
              <tr><td colSpan={7} className="py-8 text-center text-xs text-neutral-400">No secondary retail sale logs recorded. Add checked out invoices to log.</td></tr>
            ) : (
              filtered.map(s => {
                const isLoss = s.profit < 0;
                return (
                  <tr key={s.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                    <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{s.id}</td>
                    <td className="py-4 px-4 font-mono text-neutral-450 font-bold">{s.invoiceId}</td>
                    <td className="py-4 px-4 text-neutral-700 dark:text-neutral-300">
                      {s.seller?.name || 'Automated Clerk'}
                    </td>
                    <td className="py-4 px-4 text-right font-bold text-neutral-900 dark:text-neutral-50 font-mono">
                      {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(s.totalAmount)}
                    </td>
                    <td className={`py-4 px-4 text-right font-bold font-mono ${isLoss ? 'text-rose-500' : 'text-emerald-600'}`}>
                      {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(s.profit)}
                    </td>
                    <td className="py-4 px-4 text-center text-neutral-400 font-semibold font-mono">
                      {new Date(s.date).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-4 px-4 text-center font-bold text-neutral-400 font-mono text-[10px]">
                      {s.status}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== FINANCE LEDGER ====================
export const FinanceListView: React.FC = () => {
  const { data, deleteFinanceItem } = useERP();
  const [incSearch, setIncSearch] = useState('');
  const [expSearch, setExpSearch] = useState('');

  const incFiltered = data.finance.income.filter(i => {
    return i.source.toLowerCase().includes(incSearch.toLowerCase()) ||
           (i.referenceId && i.referenceId.toLowerCase().includes(incSearch.toLowerCase()));
  });

  const expFiltered = data.finance.expenses.filter(e => {
    return e.category.toLowerCase().includes(expSearch.toLowerCase()) ||
           e.note.toLowerCase().includes(expSearch.toLowerCase());
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      
      {/* 2. Inflow Ledger */}
      <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
        <h3 className="font-bold text-sm text-[#21005D] dark:text-[#EADDFF] uppercase tracking-wider mb-2">Income Credit Inflows</h3>
        <TableHeaderSection 
          searchPlaceholder="Filter cash flows, slips..." 
          searchValue={incSearch} 
          onSearchChange={setIncSearch} 
        />
        <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 max-h-[380px]">
          <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
            <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
              <tr>
                <th className="py-3 px-4">Receipt ID</th>
                <th className="py-3 px-4">Payment Channel</th>
                <th className="py-3 px-4 text-right">Inflow sum</th>
                <th className="py-3 px-4 text-center">Filing Date</th>
                <th className="py-3 px-4 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
              {incFiltered.length === 0 ? (
                <tr><td colSpan={5} className="py-6 text-center text-xs text-neutral-400">No inbound transactions received.</td></tr>
              ) : (
                incFiltered.map(i => (
                  <tr key={i.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{i.id}</td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-neutral-800 dark:text-neutral-200 uppercase text-[10px]">{i.source}</div>
                      {i.referenceId && <div className="text-[9px] text-[#6750A4] font-semibold mt-0.5">{i.referenceId}</div>}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-emerald-600 font-mono">
                      +{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(i.amount)}
                    </td>
                    <td className="py-3.5 px-4 text-center text-neutral-400 font-mono font-semibold">
                      {new Date(i.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="py-3.5 px-4 text-right pointer-events-auto">
                      <button onClick={() => deleteFinanceItem('income', i.id)} className="p-1.5 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-lg cursor-pointer">
                        <Trash className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Expense Ledger */}
      <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
        <h3 className="font-bold text-sm text-rose-700 uppercase tracking-wider mb-2">Operating Outflow Expenses</h3>
        <TableHeaderSection 
          searchPlaceholder="Filter cash outflows, categories..." 
          searchValue={expSearch} 
          onSearchChange={setExpSearch} 
        />
        <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 max-h-[380px]">
          <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
            <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
              <tr>
                <th className="py-3 px-4">Debit Voucher ID</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Debit sum</th>
                <th className="py-3 px-4 text-center">Filing Date</th>
                <th className="py-3 px-4 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium font-semibold">
              {expFiltered.length === 0 ? (
                <tr><td colSpan={5} className="py-6 text-center text-xs text-neutral-400">No outbound debits registered.</td></tr>
              ) : (
                expFiltered.map(e => (
                  <tr key={e.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{e.id}</td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-neutral-800 dark:text-neutral-200 text-xs">{e.category}</div>
                      {e.note && <div className="text-[10px] text-neutral-400 font-medium mt-0.5">{e.note}</div>}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-rose-500 font-mono">
                      -{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(e.amount)}
                    </td>
                    <td className="py-3.5 px-4 text-center text-neutral-400 font-mono font-semibold">
                      {new Date(e.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="py-3.5 px-4 text-right pointer-events-auto">
                      <button onClick={() => deleteFinanceItem('expense', e.id)} className="p-1.5 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-lg cursor-pointer">
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

// ==================== EMPLOYEE ROSTER LIST ====================
export const EmployeeListView: React.FC<{ onEdit: (e: Employee) => void }> = ({ onEdit }) => {
  const { data, deleteEmployee } = useERP();
  const [search, setSearch] = useState('');

  // Count active sales authorized by each salesperson dynamically
  const salespersonStats: { [key: string]: { amount: number; count: number } } = {};
  data.sales.forEach(s => {
    if (s.seller?.id) {
      if (!salespersonStats[s.seller.id]) salespersonStats[s.seller.id] = { amount: 0, count: 0 };
      salespersonStats[s.seller.id].amount += s.totalAmount;
      salespersonStats[s.seller.id].count++;
    }
  });

  const filtered = data.employees.filter(e => {
    return e.personalInfo.fullName.toLowerCase().includes(search.toLowerCase()) ||
           e.jobInfo.department.toLowerCase().includes(search.toLowerCase()) ||
           e.jobInfo.role.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
        <TableHeaderSection 
          searchPlaceholder="Quick filter details, roles, department codes..." 
          searchValue={search} 
          onSearchChange={setSearch} 
        />
        <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900">
          <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
            <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
              <tr>
                <th className="py-3 px-4">Roster ID</th>
                <th className="py-3 px-4">Profile Details</th>
                <th className="py-3 px-4">Job Designation</th>
                <th className="py-3 px-4 text-right">Roster Salary</th>
                <th className="py-3 px-4 text-center">Filing Sales count</th>
                <th className="py-3 px-4 text-right">Filing Revenue volume</th>
                <th className="py-3 px-4 text-center">Employment status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium whitespace-nowrap">
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="py-8 text-center text-xs text-neutral-400">No active employees recorded on the roster ledger.</td></tr>
              ) : (
                filtered.map(e => {
                  const stat = salespersonStats[e.id] || { amount: 0, count: 0 };
                  return (
                    <tr key={e.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                      <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">{e.id}</td>
                      <td className="py-4 px-4">
                        <div className="font-semibold text-neutral-850 dark:text-neutral-150 text-sm leading-snug">{e.personalInfo.fullName}</div>
                        {e.personalInfo.phone && <div className="text-[10px] text-neutral-400 mt-0.5">{e.personalInfo.phone} | SSN: {e.personalInfo.NID || '—'}</div>}
                      </td>
                      <td className="py-4 px-4">
                        <div className="font-semibold text-neutral-700 dark:text-neutral-350">{e.jobInfo.role}</div>
                        <div className="text-[10px] text-[#6750A4] dark:text-[#D0BCFF] font-semibold mt-0.5">Dep: {e.jobInfo.department || 'N/A'}</div>
                      </td>
                      <td className="py-4 px-4 text-right font-bold text-neutral-900 dark:text-neutral-50 font-mono">
                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(e.jobInfo.salary)}
                      </td>
                      <td className="py-4 px-4 text-center font-bold font-mono">
                        {stat.count}
                      </td>
                      <td className="py-4 px-4 text-right text-emerald-600 font-bold font-mono">
                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(stat.amount)}
                      </td>
                      <td className="py-4 px-4 text-center">
                        <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full ${
                          e.jobInfo.status === 'active' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400' 
                                                        : 'bg-rose-50 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400'
                        }`}>
                          {e.jobInfo.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex gap-2 justify-end pointer-events-auto">
                          <button onClick={() => onEdit(e)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer">
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => deleteEmployee(e.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ==================== SUPPLIERS LIST ====================
export const SupplierListView: React.FC<{ onEdit: (s: Supplier) => void }> = ({ onEdit }) => {
  const { data, deleteSupplier } = useERP();
  const [search, setSearch] = useState('');

  const filtered = data.suppliers.filter(s => {
    return s.name.toLowerCase().includes(search.toLowerCase()) ||
           s.company.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
      <TableHeaderSection 
        searchPlaceholder="Quick filter agency partners, corporations..." 
        searchValue={search} 
        onSearchChange={setSearch} 
      />
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 font-semibold text-xs text-neutral-600 dark:text-neutral-300">
        <table className="w-full text-left">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4">Partner ID</th>
              <th className="py-3 px-4">Supplier Credentials</th>
              <th className="py-3 px-4">Corporate Office Address</th>
              <th className="py-3 px-4">Payment terms Option</th>
              <th className="py-3 px-4">Rating KPI</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
            {filtered.length === 0 ? (
              <tr><td colSpan={6} className="py-8 text-center text-neutral-400">No logistics partner suppliers indexed.</td></tr>
            ) : (
              filtered.map(s => (
                <tr key={s.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-900/10 transition-colors">
                  <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-150">{s.id}</td>
                  <td className="py-4 px-4">
                    <div className="font-semibold text-neutral-850 dark:text-neutral-100 text-sm leading-snug">{s.name}</div>
                    <div className="text-[10px] text-[#6750A4] dark:text-[#D0BCFF] font-semibold mt-0.5">{s.company}</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-1">
                      <span className="text-neutral-500">{s.address}</span>
                    </div>
                    {s.phone && (
                      <div className="text-[10px] text-neutral-400 flex items-center gap-1 mt-1 pointer-events-auto">
                        <Phone className="w-3 h-3 flex-shrink-0" />
                        <a href={`tel:${s.phone}`} className="hover:underline">{s.phone}</a>
                        {s.email && <span className="text-neutral-300">|</span>}
                        {s.email && <MailIcon className="w-3 h-3 flex-shrink-0" />}
                        {s.email && <a href={`mailto:${s.email}`} className="hover:underline">{s.email}</a>}
                      </div>
                    )}
                  </td>
                  <td className="py-4 px-4 font-bold text-indigo-500 font-mono text-[11px] uppercase tracking-wide">
                    {s.paymentTerms || 'COD'}
                  </td>
                  <td className="py-4 px-4 text-emerald-600 font-sans">
                    <div className="flex gap-0.5 text-amber-500">
                      {Array.from({ length: s.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-current" />
                      ))}
                    </div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex gap-2 justify-end pointer-events-auto">
                      <button onClick={() => onEdit(s)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => deleteSupplier(s.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== PROCUREMENT PO LIST ====================
export const PurchaseListView: React.FC<{ onEdit: (p: Purchase) => void }> = ({ onClose, onEdit, editPurchase } : any) => {
  const { data, deletePurchase } = useERP();
  const [supplierId, setSupplierId] = useState('');

  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setToDate] = useState('');

  let filtered = [...data.purchases];

  if (supplierId) {
    filtered = filtered.filter(p => p.supplierId === supplierId);
  }
  if (search) {
    // searching supplier name
    filtered = filtered.filter(p => {
      const s = data.suppliers.find(sup => sup.id === p.supplierId);
      return s?.name.toLowerCase().includes(search.toLowerCase()) || p.id.toLowerCase().includes(search.toLowerCase());
    });
  }
  // date boundaries
  if (dateFrom) {
    filtered = filtered.filter(p => new Date(p.date) >= new Date(dateFrom));
  }
  if (dateTo) {
    filtered = filtered.filter(p => new Date(p.date) <= new Date(dateTo + 'T23:59:59'));
  }

  // print PO on external frame
  const handlePrintPo = (p: Purchase) => {
    const sName = data.suppliers.find(s => s.id === p.supplierId)?.name || p.supplierId;
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`
      <html>
        <head>
          <title>Procurement PO #${p.id}</title>
          <style>
            body { font-family: sans-serif; padding: 40px; color: #1c1b1f; }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #EADDFF; padding-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 30px; }
            th { text-align: left; background: #EADDFF; padding: 10px; font-size: 11px; text-transform: uppercase; }
            td { padding: 12px 10px; border-bottom: 1px solid #CAC4D0; font-size: 13px; }
          </style>
        </head>
        <body>
          <h2>Purchase Order PO-${p.id}</h2>
          <p><strong>Supplier:</strong> ${sName}</p>
          <p><strong>Date:</strong> ${new Date(p.date).toLocaleString()}</p>
          <p><strong>Method:</strong> ${p.paymentMethod || 'standard account ledger'}</p>
          <hr />
          <table>
            <thead>
              <tr>
                <th>Product Core</th>
                <th>Purchased Quantity</th>
                <th>Unit Cost</th>
                <th>Total Value</th>
              </tr>
            </thead>
            <tbody>
              ${p.items.map(it => {
                const prodName = data.products.find(pr => pr.id === it.productId)?.basicInfo.name || it.productId;
                return `
                  <tr>
                    <td>${prodName} (${it.size || 'N/A'})</td>
                    <td>${it.quantity}</td>
                    <td>$${it.costPrice}</td>
                    <td>$${(it.quantity * it.costPrice).toFixed(2)}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
          <h3 style="text-align: right; margin-top: 30px;">Total PO Amount: $${p.totalCost.toFixed(2)}</h3>
        </body>
      </html>
    `);
    w.document.close();
  };

  return (
    <div className="card">
      <div className="card-header pb-4 border-b border-neutral-100 dark:border-neutral-800 flex justify-between items-center flex-wrap gap-4">
        <div>
          <h3 className="font-bold text-neutral-900 dark:text-neutral-50 text-base">Purchase Orders ({data.purchases.length})</h3>
          <p className="text-[10px] text-neutral-400 font-medium">Inbound procurements list</p>
        </div>
        <button onClick={() => onEdit(null)} className="px-5 py-2.5 rounded-full bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] hover:opacity-90 transition-opacity font-bold text-xs cursor-pointer select-none">
          + Add Purchase
        </button>
      </div>

      {/* Date filters and select sorting UI */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 select-none">
        <input 
          placeholder="Filter supplier or PO ID..." 
          value={search} 
          onChange={e => setSearch(e.target.value)} 
          className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-2.5 text-xs bg-transparent"
        />
        <div className="flex gap-2 items-center bg-[#FAF8FE]/50 dark:bg-transparent border border-neutral-200 dark:border-neutral-800 rounded-xl px-2.5 py-1 text-xs">
          <Calendar className="w-4 h-4 text-neutral-450" />
          <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="bg-transparent border-none outline-none font-mono text-[11px]" />
          <span>to</span>
          <input type="date" value={dateTo} onChange={e => setToDate(e.target.value)} className="bg-transparent border-none outline-none font-mono text-[11px]" />
        </div>
      </div>

      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 font-semibold text-xs text-neutral-600 dark:text-neutral-300">
        <table className="w-full text-left">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4">PO REF ID</th>
              <th className="py-3 px-4">Origin Supplier Details</th>
              <th className="py-3 px-4 text-center">Items Group count</th>
              <th className="py-3 px-4 text-right">Cost Volume</th>
              <th className="py-3 px-4 text-center">PO Date</th>
              <th className="py-3 px-4 text-center">Receipt Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
            {filtered.length === 0 ? (
              <tr><td colSpan={7} className="py-8 text-center text-neutral-400">No matching procurement records found.</td></tr>
            ) : (
              filtered.map(p => (
                <tr key={p.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-150">{p.id}</td>
                  <td className="py-3.5 px-4 text-neutral-800 dark:text-neutral-100 font-semibold">
                    {data.suppliers.find(s => s.id === p.supplierId)?.name || p.supplierId}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono">
                    {p.items.reduce((s, it) => s + it.quantity, 0)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-bold text-neutral-900 dark:text-neutral-50 font-mono">
                    {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(p.totalCost)}
                  </td>
                  <td className="py-3.5 px-4 text-center text-neutral-405 font-mono font-semibold">
                    {new Date(p.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full uppercase ${
                      p.status === 'completed' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400' 
                                               : 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400'
                    }`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex gap-2 justify-end pointer-events-auto">
                      <button onClick={() => handlePrintPo(p)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer" title="Print PO sheet">
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => onEdit(p)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => deletePurchase(p.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== DELIVERY ROUTING COURIER LIST ====================
export const DeliveryListView: React.FC<{ onEdit: (d: Delivery) => void }> = ({ onEdit }) => {
  const { data, deleteDelivery } = useERP();
  const [search, setSearch] = useState('');

  const filtered = data.deliveries.filter(d => {
    return d.id.toLowerCase().includes(search.toLowerCase()) ||
           d.invoiceId.toLowerCase().includes(search.toLowerCase()) ||
           d.address.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
      <TableHeaderSection 
        searchPlaceholder="Quick filter delivery references, shipping zip codes..." 
        searchValue={search} 
        onSearchChange={setSearch} 
      />
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 font-semibold text-xs text-neutral-600 dark:text-neutral-300">
        <table className="w-full text-left">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4">Tracking Dispatch ID</th>
              <th className="py-3 px-4">Origin Invoice</th>
              <th className="py-3 px-4">Shipping Destination address</th>
              <th className="py-3 px-4 text-right">Route Charges</th>
              <th className="py-3 px-4 text-center">Filing Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium whitespace-nowrap">
            {filtered.length === 0 ? (
              <tr><td colSpan={6} className="py-8 text-center text-neutral-400 font-medium">No logistics tracking deliveries compiled.</td></tr>
            ) : (
              filtered.map(d => (
                <tr key={d.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                  <td className="py-4 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-150">{d.id}</td>
                  <td className="py-4 px-4 font-mono font-bold text-indigo-500">{d.invoiceId}</td>
                  <td className="py-4 px-4 truncate max-w-[200px]" title={d.address}>
                    {d.address}
                  </td>
                  <td className="py-4 px-4 text-right font-bold text-neutral-900 dark:text-neutral-50 font-mono">
                    {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(d.cost)}
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full uppercase ${
                      d.status === 'delivered' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20' 
                                               : 'bg-amber-50 text-amber-700 dark:bg-amber-900/20'
                    }`}>
                      {d.status}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex gap-2 justify-end pointer-events-auto">
                      <button onClick={() => onEdit(d)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => deleteDelivery(d.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== OFFERS & CAMPAIGNS LIST ====================
export const OfferListView: React.FC<{ onEdit: (o: Offer) => void }> = ({ onEdit }) => {
  const { data, deleteOffer } = useERP();
  const [search, setSearch] = useState('');

  const filtered = data.offers.filter(o => {
    return o.name.toLowerCase().includes(search.toLowerCase()) ||
           o.promoCode.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm">
      <TableHeaderSection 
        searchPlaceholder="Quick filter campaign titles, codes..." 
        searchValue={search} 
        onSearchChange={setSearch} 
      />
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 font-semibold text-xs text-neutral-600 dark:text-neutral-300">
        <table className="w-full text-left">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4">Campaign Title</th>
              <th className="py-3 px-4">CODE Value</th>
              <th className="py-3 px-4">Deduction Type</th>
              <th className="py-3 px-4">Reduction Value</th>
              <th className="py-3 px-4">Scope Level</th>
              <th className="py-3 px-4 text-center">Filing Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
            {filtered.length === 0 ? (
              <tr><td colSpan={7} className="py-8 text-center text-neutral-400">No active discounts or promo codes registered.</td></tr>
            ) : (
              filtered.map(o => (
                <tr key={o.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                  <td className="py-4 px-4">
                    <div className="font-semibold text-neutral-850 dark:text-neutral-100 text-sm leading-snug">{o.name}</div>
                    {o.startDate && <div className="text-[9px] font-mono text-neutral-450 mt-0.5">Duration: {new Date(o.startDate).toLocaleDateString()} — {o.expiryDate ? new Date(o.expiryDate).toLocaleDateString() : 'Active'}</div>}
                  </td>
                  <td className="py-4 px-4">
                    <span className="font-bold text-xs font-mono bg-[#EADDFF] text-[#21005D] dark:bg-[#4F378B] dark:text-[#EADDFF] py-1 px-3 rounded-full">
                      {o.promoCode}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-xs font-semibold uppercase">{o.type}</td>
                  <td className="py-4 px-4 font-bold font-mono text-indigo-600">
                    {o.type === 'percentage' ? `${o.value}% Off` : new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(o.value)}
                  </td>
                  <td className="py-4 px-4 text-neutral-500 font-medium">
                    {o.productId ? `Item: ${data.products.find(p=>p.id===o.productId)?.basicInfo.name || o.productId}` : 'Store-wide catalog promotion'}
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full ${
                      o.status === 'active' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20' 
                                            : 'bg-rose-50 text-rose-700 dark:bg-rose-900/20'
                    }`}>
                      {o.status}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex gap-2 justify-end pointer-events-auto">
                      <button onClick={() => onEdit(o)} className="p-2 border border-neutral-250 dark:border-neutral-800 rounded-xl cursor-pointer">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => deleteOffer(o.id)} className="p-2 border border-[#F9DEDC] hover:bg-[#F9DEDC]/25 text-rose-500 rounded-xl cursor-pointer">
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== REPORTS HISTORIC TABULARS ====================
export const ReportsListView: React.FC = () => {
  const { data, generateReport } = useERP();

  const totalSalesVolumeSum = data.sales.reduce((s, sl) => s + sl.totalAmount, 0);
  const totalExpensesLedgerSum = data.finance.expenses.reduce((s, e) => s + e.amount, 0);
  const aggregateProfitVolumeSum = data.sales.reduce((s, sl) => s + sl.profit, 0);

  return (
    <div className="space-y-6 animate-fade-in select-none">
      <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-6 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="font-bold text-neutral-900 dark:text-neutral-100 text-sm flex items-center gap-1.5"><TrendingUp className="w-5 h-5 text-indigo-500" /> Compiled Analytics Snapshots</h3>
            <p className="text-[10px] text-neutral-400 font-medium">Log dynamic snapshots representing total financial margins</p>
          </div>
          <button onClick={generateReport} className="px-5 py-2.5 bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] hover:opacity-90 font-bold text-xs rounded-full pointer-events-auto cursor-pointer shadow-sm select-none">
            Generate Snapshot
          </button>
        </div>

        <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 font-semibold text-xs text-neutral-600 dark:text-neutral-300">
          <table className="w-full text-left">
            <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
              <tr>
                <th className="py-3 px-4">Snapshot ID</th>
                <th className="py-3 px-4">Compilation Class</th>
                <th className="py-3 px-4 text-right">Sales volume sum</th>
                <th className="py-3 px-4 text-right">Expense margin sum</th>
                <th className="py-3 px-4 text-right">Profit generated</th>
                <th className="py-3 px-4 text-center">Snapshot timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-900 font-medium">
              {data.reports.length === 0 ? (
                <tr><td colSpan={6} className="py-6 text-center text-neutral-400 font-medium">No business snapshot files logged yet in this workspace.</td></tr>
              ) : (
                [...data.reports].reverse().map(r => (
                  <tr key={r.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-150">{r.id}</td>
                    <td className="py-3.5 px-4"><span className="text-[10px] font-bold uppercase tracking-wide bg-neutral-100 dark:bg-neutral-800 py-0.5 px-2.5 rounded-full">{r.type}</span></td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold">{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(r.data.totalSales)}</td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-rose-500">-{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(r.data.totalExpense)}</td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-600">+{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(r.data.totalProfit)}</td>
                    <td className="py-3.5 px-4 text-center text-neutral-450 font-mono font-semibold">
                      {new Date(r.generatedAt).toLocaleString([], { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ==================== AUDIT TELEMETRY LOGS ====================
export const AuditLogView: React.FC = () => {
  const { data } = useERP();

  return (
    <div className="bg-white dark:bg-[#1C1B1F] border border-neutral-200 dark:border-[#49454F] rounded-3xl p-5 shadow-sm select-text">
      <div className="pb-4 border-b border-neutral-100 dark:border-neutral-800">
        <h3 className="font-bold text-neutral-900 dark:text-neutral-50 text-base">Filing Telemetry Audit Logs</h3>
        <p className="text-[10px] text-neutral-400 font-medium">Immutable registers representing client database writes & deletes</p>
      </div>
      <div className="relative overflow-x-auto mt-4 rounded-xl border border-neutral-100 dark:border-neutral-900 max-h-[460px]">
        <table className="w-full text-left text-xs text-neutral-600 dark:text-neutral-300">
          <thead className="text-[10px] uppercase font-bold text-neutral-400 bg-neutral-50 dark:bg-neutral-950/20 border-b border-neutral-150 dark:border-neutral-800">
            <tr>
              <th className="py-3 px-4">Audit Ticket</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4">Agent Scope</th>
              <th className="py-3 px-4">Registry Action Class</th>
              <th className="py-3 px-4">Telemetric Logs Detail</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-930 font-medium whitespace-nowrap">
            {data.auditLog.length === 0 ? (
              <tr><td colSpan={5} className="py-8 text-center text-neutral-400">Telemetry logs clean. No audit registries tracked.</td></tr>
            ) : (
              data.auditLog.map(item => (
                <tr key={item.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-950/25 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-neutral-150">{item.id}</td>
                  <td className="py-3.5 px-4 font-mono font-semibold text-neutral-450">{new Date(item.timestamp).toLocaleString()}</td>
                  <td className="py-3.5 px-4 font-bold text-[#6750A4] dark:text-[#D0BCFF] text-[10px] tracking-wider uppercase">{item.user} ({item.role})</td>
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-[10px] font-mono leading-none tracking-wide text-neutral-620 dark:text-neutral-350">{item.action}</span>
                  </td>
                  <td className="py-3.5 px-4 truncate max-w-[250px] font-mono text-[11px] leading-relaxed select-text" title={item.details}>
                    {item.details}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
