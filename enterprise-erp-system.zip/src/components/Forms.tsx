/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useERP } from '../context/ERPContext';
import { 
  Customer, Product, Invoice, Employee, Supplier, Purchase, 
  Delivery, Offer, InvoiceItem, PurchaseItem 
} from '../types';
import { X, Plus, Trash, UserPlus, Image as ImageIcon } from 'lucide-react';

interface FormModalProps {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  onSubmit: () => void;
  submitLabel?: string;
}

const MaterialModal: React.FC<FormModalProps> = ({ title, onClose, children, onSubmit, submitLabel = 'Save changes' }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/55 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-[#1C1B1F] w-full max-w-4xl max-h-[88vh] overflow-y-auto rounded-[32px] border border-neutral-100 dark:border-neutral-800 shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <h3 className="font-bold text-lg text-neutral-900 dark:text-neutral-50">{title}</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800/80 text-neutral-400 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {children}
        </div>

        {/* Modal Footer */}
        <div className="p-6 border-t border-neutral-100 dark:border-neutral-800 flex justify-end gap-3 bg-neutral-50/50 dark:bg-neutral-950/15">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-full border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 font-bold text-sm hover:bg-neutral-50 dark:hover:bg-neutral-850 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onSubmit}
            className="px-6 py-2.5 rounded-full bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] font-bold text-sm hover:opacity-90 cursor-pointer shadow-md shadow-indigo-600/10"
          >
            {submitLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

// ==================== CUSTOMER FORM ====================
export const CustomerFormModal: React.FC<{ editCustomer?: Customer; onClose: () => void }> = ({ editCustomer, onClose }) => {
  const { data, addCustomer, updateCustomer } = useERP();
  const [fullName, setFullName] = useState(editCustomer?.personalInfo.fullName || '');
  const [phone, setPhone] = useState(editCustomer?.personalInfo.phone || '');
  const [email, setEmail] = useState(editCustomer?.personalInfo.email || '');
  const [gender, setGender] = useState(editCustomer?.personalInfo.gender || 'male');
  const [dob, setDob] = useState(editCustomer?.personalInfo.dateOfBirth || '');
  const [street, setStreet] = useState(editCustomer?.personalInfo.address.street || '');
  const [city, setCity] = useState(editCustomer?.personalInfo.address.city || '');
  const [state, setState] = useState(editCustomer?.personalInfo.address.state || '');
  const [country, setCountry] = useState(editCustomer?.personalInfo.address.country || 'US');
  const [zip, setZip] = useState(editCustomer?.personalInfo.address.postalCode || '');
  const [customerType, setCustomerType] = useState<Customer['businessInfo']['customerType']>(editCustomer?.businessInfo.customerType || 'retail');
  const [companyName, setCompanyName] = useState(editCustomer?.businessInfo.companyName || '');
  const [industry, setIndustry] = useState(editCustomer?.businessInfo.industry || '');
  const [source, setSource] = useState<Customer['businessInfo']['source']>(editCustomer?.businessInfo.source || 'manual');
  const [creditLimit, setCreditLimit] = useState(editCustomer?.financialInfo.creditLimit || 0);
  const [riskLevel, setRiskLevel] = useState<Customer['financialInfo']['riskLevel']>(editCustomer?.financialInfo.riskLevel || 'low');
  const [status, setStatus] = useState<Customer['status']>(editCustomer?.status || 'active');

  const handleSubmit = () => {
    if (!fullName || !phone) {
      alert('Please fill out Name and Phone number.');
      return;
    }

    const personalInfo = {
      fullName, phone, email, gender, dateOfBirth: dob,
      address: { street, city, state, country, postalCode: zip }
    };
    const businessInfo = { customerType, companyName, industry, source };

    if (editCustomer) {
      updateCustomer({
        ...editCustomer,
        personalInfo,
        businessInfo,
        financialInfo: {
          ...editCustomer.financialInfo,
          creditLimit,
          riskLevel
        },
        status
      });
    } else {
      addCustomer({
        personalInfo,
        businessInfo,
        status,
        creditLimit,
        riskLevel
      } as any);
    }
    onClose();
  };

  return (
    <MaterialModal title={editCustomer ? 'Edit Customer Profile' : 'Register New Customer'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-6" onSubmit={e => e.preventDefault()}>
        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Personal Bio Information</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Customer Full Name *</label>
              <input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="e.g. John Doe" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Contact Phone *</label>
              <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="e.g. +1 555-0199" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Email Address</label>
              <input value={email} type="email" onChange={e => setEmail(e.target.value)} placeholder="e.g. john@acme.com" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Gender ID</label>
              <select value={gender} onChange={e => setGender(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Date of Birth</label>
              <input value={dob} type="date" onChange={e => setDob(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Mailing / Billing Address</h4>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="flex flex-col gap-1 md:col-span-2">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Street</label>
              <input value={street} onChange={e => setStreet(e.target.value)} placeholder="e.g. 123 Oak St" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">City</label>
              <input value={city} onChange={e => setCity(e.target.value)} placeholder="Springfield" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">State/Province</label>
              <input value={state} onChange={e => setState(e.target.value)} placeholder="IL" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">ZIP / Postal</label>
              <input value={zip} onChange={e => setZip(e.target.value)} placeholder="62701" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Business Logistics & CRM Classification</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Account Type</label>
              <select value={customerType} onChange={e => setCustomerType(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="retail">Retail Consumer</option>
                <option value="wholesale">Wholesale Dealership</option>
                <option value="vip">VIP Partner</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Corporate Name</label>
              <input value={companyName} onChange={e => setCompanyName(e.target.value)} placeholder="e.g. Acme Industries" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Industry</label>
              <input value={industry} onChange={e => setIndustry(e.target.value)} placeholder="e.g. Energy" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Acquisition Channel</label>
              <select value={source} onChange={e => setSource(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="manual">Manual Entry</option>
                <option value="online">Online Search</option>
                <option value="referral">Customer Referral</option>
                <option value="marketing">Campaign Marketing</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Credit Limit ({data.config.currency})</label>
              <input value={creditLimit} type="number" onChange={e => setCreditLimit(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Credit Risk Level</label>
              <select value={riskLevel} onChange={e => setRiskLevel(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="low">Low Risk</option>
                <option value="medium">Medium Monitor</option>
                <option value="high">High Risk Balance</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Account Status</label>
              <select value={status} onChange={e => setStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="active">Active Activity</option>
                <option value="inactive">Inactive</option>
                <option value="blocked">Blocked Account</option>
              </select>
            </div>
          </div>
        </div>
      </form>
    </MaterialModal>
  );
};

// ==================== PRODUCT FORM ====================
export const ProductFormModal: React.FC<{ editProduct?: Product; onClose: () => void }> = ({ editProduct, onClose }) => {
  const { addProduct, updateProduct, data } = useERP();
  const [name, setName] = useState(editProduct?.basicInfo.name || '');
  const [category, setCategory] = useState(editProduct?.basicInfo.category || '');
  const [brand, setBrand] = useState(editProduct?.basicInfo.brand || '');
  const [sizes, setSizes] = useState(editProduct?.basicInfo.size || '');
  const [barcode, setBarcode] = useState(editProduct?.barcode || '');
  const [description, setDescription] = useState(editProduct?.basicInfo.description || '');
  const [costPrice, setCostPrice] = useState(editProduct?.pricing.costPrice || 0);
  const [salePrice, setSalePrice] = useState(editProduct?.pricing.salePrice || 0);
  const [taxRate, setTaxRate] = useState(editProduct?.pricing.taxRate || 0);
  const [discount, setDiscount] = useState(editProduct?.pricing.discount || 0);
  const [quantity, setQuantity] = useState(editProduct?.stock.quantity || 0);
  const [reorderLevel, setReorderLevel] = useState(editProduct?.stock.reorderLevel || 10);
  const [warehouseLocation, setWarehouseLocation] = useState(editProduct?.stock.warehouseLocation || '');
  const [supplierId, setSupplierId] = useState(editProduct?.supplierId || '');
  const [status, setStatus] = useState<Product['status']>(editProduct?.status || 'active');
  const [notes, setNotes] = useState(editProduct?.basicInfo.notes || '');

  const handleSubmit = () => {
    if (!name || costPrice <= 0 || salePrice <= 0) {
      alert('Please fill out Name, valid Cost Price and Sale Price.');
      return;
    }

    const payload = {
      barcode,
      basicInfo: { name, description, category, brand, size: sizes, notes },
      pricing: { costPrice, salePrice, taxRate, discount },
      supplierId: supplierId || null,
      status
    };

    if (editProduct) {
      updateProduct({
        ...editProduct,
        ...payload,
        stock: {
          ...editProduct.stock,
          quantity,
          available: quantity - editProduct.stock.reserved,
          reorderLevel,
          warehouseLocation
        }
      });
    } else {
      addProduct({
        ...payload,
        quantity,
        reorderLevel,
        warehouseLocation
      });
    }
    onClose();
  };

  return (
    <MaterialModal title={editProduct ? 'Edit Catalog Product' : 'Register New Inventory Product'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-6" onSubmit={e => e.preventDefault()}>
        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Product Core Profile</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Product Name *</label>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Leather Shoe Standard" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Barcode UPC</label>
              <input value={barcode} onChange={e => setBarcode(e.target.value)} placeholder="e.g. 880123412" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Product Brand</label>
              <input value={brand} onChange={e => setBrand(e.target.value)} placeholder="e.g. CoreWear" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Category</label>
              <input value={category} onChange={e => setCategory(e.target.value)} placeholder="e.g. Footwear" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Sizes (comma-separated list)</label>
              <input value={sizes} onChange={e => setSizes(e.target.value)} placeholder="e.g. 39, 40, 41, 42" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Supplier Partner</label>
              <select value={supplierId} onChange={e => setSupplierId(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="">— Select Supplier —</option>
                {data.suppliers.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.company})</option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex flex-col gap-1 mt-4">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Product technical parameters..." className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" rows={2} />
          </div>
        </div>

        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Prices & Tax Margins</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Cost Price ({data.config.currency}) *</label>
              <input value={costPrice} type="number" onChange={e => setCostPrice(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Retail Sale Price ({data.config.currency}) *</label>
              <input value={salePrice} type="number" onChange={e => setSalePrice(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Standard Tax Rate (%)</label>
              <input value={taxRate} type="number" onChange={e => setTaxRate(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">General Promo Discount (%)</label>
              <input value={discount} type="number" onChange={e => setDiscount(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Physical Storage Warehouses</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Initial Roster Stock</label>
              <input value={quantity} type="number" disabled={!!editProduct} onChange={e => setQuantity(parseInt(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full disabled:opacity-50" />
              {editProduct && <span className="text-[9px] text-[#6750A4] font-medium">Controlled via transactions log</span>}
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Low Stock Alert Level</label>
              <input value={reorderLevel} type="number" onChange={e => setReorderLevel(parseInt(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Warehouse Aisle / Bin</label>
              <input value={warehouseLocation} onChange={e => setWarehouseLocation(e.target.value)} placeholder="e.g. Aisle 35-C" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Catalog Status</label>
              <select value={status} onChange={e => setStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="active">Active Selling</option>
                <option value="inactive">Inactive</option>
                <option value="discontinued">Product Discontinued</option>
              </select>
            </div>
          </div>
        </div>
      </form>
    </MaterialModal>
  );
};

// ==================== INVOICE FORM ====================
export const InvoiceFormModal: React.FC<{ editInvoice?: Invoice; onClose: () => void }> = ({ editInvoice, onClose }) => {
  const { addInvoice, updateInvoice, data, addEmployee } = useERP();
  
  const [customerId, setCustomerId] = useState(editInvoice?.customer.customerId || '');
  const [sellerId, setSellerId] = useState(editInvoice?.seller?.id || '');
  const [paymentMethod, setPaymentMethod] = useState<Invoice['payment']['method']>(editInvoice?.payment.method || 'cash');
  const [paidAmount, setPaidAmount] = useState(editInvoice?.payment.paidAmount || 0);
  const [transactionId, setTransactionId] = useState(editInvoice?.payment.transactionId || '');
  const [invoiceStatus, setInvoiceStatus] = useState<Invoice['status']>(editInvoice?.status || 'draft');
  const [dueDate, setDueDate] = useState(editInvoice?.dueDate ? editInvoice.dueDate.slice(0, 10) : '');
  const [promoCode, setPromoCode] = useState(editInvoice?.promo?.code || '');
  const [note, setNote] = useState(editInvoice?.note || '');
  const [terms, setTerms] = useState(editInvoice?.terms || '');
  const [termsApplied, setTermsApplied] = useState(editInvoice?.termsApplied || false);

  // Manual overriding billing properties
  const [custName, setCustName] = useState(editInvoice?.customer.name || '');
  const [custPhone, setCustPhone] = useState(editInvoice?.customer.phone || '');
  const [custEmail, setCustEmail] = useState(editInvoice?.customer.email || '');
  const [customerAddress, setCustomerAddress] = useState(editInvoice?.customer.address || '');

  // Embedded fast employee insertion
  const [showEmbeddedAddEmp, setShowEmbeddedAddEmp] = useState(false);
  const [fastEmpName, setFastEmpName] = useState('');
  const [fastEmpRole, setFastEmpRole] = useState('Salesperson');

  // Checkout invoice item rows
  const [items, setItems] = useState<InvoiceItem[]>(editInvoice?.items || [
    { productId: '', name: '', size: '', quantity: 1, unitPrice: 0, discount: 0, taxRate: 0, subtotal: 0 }
  ]);

  // Calculations reactive summary
  const [subTotalSum, setSubTotalSum] = useState(0);
  const [totalDiscountSum, setTotalDiscountSum] = useState(0);
  const [totalTaxSum, setTotalTaxSum] = useState(0);
  const [grandTotalSum, setGrandTotalSum] = useState(0);

  // Re-run dynamic mathematics whenever items or coupon codes change
  useEffect(() => {
    let rawSubTotal = 0;
    let rawDiscountSum = 0;
    let rawTaxSum = 0;

    items.forEach(row => {
      const lineTotalRaw = row.quantity * row.unitPrice;
      const lineTax = (lineTotalRaw - row.discount) * (row.taxRate / 100);
      rawSubTotal += lineTotalRaw;
      rawDiscountSum += row.discount;
      rawTaxSum += lineTax;
    });

    let finalGrand = rawSubTotal - rawDiscountSum + rawTaxSum;

    // Apply promo deductions if verified
    let promoDeduction = 0;
    if (promoCode) {
      const pObj = data.offers.find(o => o.promoCode === promoCode && o.status === 'active');
      if (pObj) {
        if (pObj.type === 'percentage') {
          promoDeduction = rawSubTotal * (pObj.value / 100);
        } else {
          promoDeduction = Math.min(pObj.value, rawSubTotal);
        }
        finalGrand = Math.max(0, finalGrand - promoDeduction);
      }
    }

    setSubTotalSum(rawSubTotal);
    setTotalDiscountSum(rawDiscountSum + promoDeduction);
    setTotalTaxSum(rawTaxSum);
    setGrandTotalSum(finalGrand);
  }, [items, promoCode, data.offers]);

  // Populate client contacts on change
  const handleCustomerChanged = (idStr: string) => {
    setCustomerId(idStr);
    const target = data.customers.find(c => c.id === idStr);
    if (target) {
      setCustName(target.personalInfo.fullName);
      setCustPhone(target.personalInfo.phone);
      setCustEmail(target.personalInfo.email);
      const a = target.personalInfo.address;
      setCustomerAddress([a.street, a.city, a.state, a.country, a.postalCode].filter(Boolean).join(', '));
    }
  };

  // Roster item selected row populator
  const handleRowProductChanged = (index: number, pid: string) => {
    const targetProd = data.products.find(p => p.id === pid);
    const updated = [...items];
    if (targetProd) {
      updated[index] = {
        ...updated[index],
        productId: pid,
        name: targetProd.basicInfo.name,
        unitPrice: targetProd.pricing.salePrice,
        taxRate: targetProd.pricing.taxRate,
        discount: (targetProd.pricing.salePrice * (targetProd.pricing.discount / 100)) * updated[index].quantity,
        size: targetProd.basicInfo.size.split(',')[0]?.trim() || '',
        subtotal: 0 // handled by effect
      };
    } else {
      updated[index] = { ...updated[index], productId: '', name: '', unitPrice: 0, discount: 0, taxRate: 0, subtotal: 0 };
    }
    setItems(updated);
  };

  const handleRowNumericChanged = (index: number, field: 'quantity' | 'unitPrice' | 'discount' | 'taxRate', val: number) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [field]: val };
    
    // Scale line discounts dynamically if quant scale occurs
    if (field === 'quantity' && updated[index].productId) {
      const targetProd = data.products.find(p => p.id === updated[index].productId);
      if (targetProd) {
        updated[index].discount = (targetProd.pricing.salePrice * (targetProd.pricing.discount / 100)) * val;
      }
    }
    setItems(updated);
  };

  const addRow = () => {
    setItems([...items, { productId: '', name: '', size: '', quantity: 1, unitPrice: 0, discount: 0, taxRate: 0, subtotal: 0 }]);
  };

  const removeRow = (idx: number) => {
    setItems(items.filter((_, i) => i !== idx));
  };

  // embedded supplier salesperson hire hook
  const handleEmbeddedEmpAdd = () => {
    if (!fastEmpName) return;
    addEmployee({
      personalInfo: { fullName: fastEmpName, phone: '', email: '', address: '', NID: '', fatherName: '', motherName: '' },
      jobInfo: { department: 'Sales', role: fastEmpRole, status: 'active', salary: 1500, joinDate: new Date().toISOString() }
    });
    setFastEmpName('');
    setShowEmbeddedAddEmp(false);
  };

  const handleSubmit = () => {
    if (!customerId || items.some(it => !it.productId)) {
      alert('Provide a customer entity and ensure all transactional lines hold catalog products.');
      return;
    }

    const payload = {
      businessId: data.config.company.name,
      customer: { customerId, name: custName, phone: custPhone, email: custEmail, address: customerAddress },
      seller: sellerId ? {
        id: sellerId,
        name: data.employees.find(e => e.id === sellerId)?.personalInfo.fullName || '',
        role: data.employees.find(e => e.id === sellerId)?.jobInfo.role || 'Salesperson'
      } : null,
      items,
      paymentMethod,
      dueDate: dueDate ? new Date(dueDate + 'T00:00:00').toISOString() : null,
      promo: promoCode ? { code: promoCode, discountAmount: 0, promoId: '' } : null, // discountAmount calculated in context
      note,
      terms,
      termsApplied,
      status: invoiceStatus,
      paidAmount,
      transactionId
    };

    if (editInvoice) {
      updateInvoice({
        ...editInvoice,
        customer: payload.customer,
        seller: payload.seller,
        items,
        status: invoiceStatus,
        payment: {
          status: paidAmount >= grandTotalSum ? 'paid' : (paidAmount > 0 ? 'partial' : 'unpaid'),
          method: paymentMethod,
          paidAmount,
          dueAmount: Math.max(0, grandTotalSum - paidAmount),
          transactionId
        },
        calculations: {
          subTotal: subTotalSum,
          totalDiscount: totalDiscountSum,
          totalTax: totalTaxSum,
          grandTotal: grandTotalSum
        },
        dueDate: payload.dueDate,
        promo: promoCode ? { code: promoCode, discountAmount: totalDiscountSum - items.reduce((s,i)=>s+i.discount,0), promoId: data.offers.find(o=>o.promoCode===promoCode)?.id||'' } : null,
        note,
        terms,
        termsApplied
      });
    } else {
      addInvoice(payload);
    }
    onClose();
  };

  return (
    <MaterialModal title={editInvoice ? `Modify Invoice #${editInvoice.id}` : 'Draft New Checkout Invoice'} onClose={onClose} onSubmit={handleSubmit} submitLabel="Compile Invoice">
      <form className="space-y-6" onSubmit={e => e.preventDefault()}>
        
        {/* Core details layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Customer Profile *</label>
            <select value={customerId} onChange={e => handleCustomerChanged(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="">— Select Registered Name —</option>
              {data.customers.map(c => (
                <option key={c.id} value={c.id}>{c.personalInfo.fullName} ({c.personalInfo.phone})</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase flex justify-between">
              <span>Roster Seller (Agent)</span>
              <button type="button" onClick={() => setShowEmbeddedAddEmp(!showEmbeddedAddEmp)} className="text-[#6750A4] dark:text-[#D0BCFF] flex items-center gap-0.5 hover:underline pointer-events-auto cursor-pointer">
                <UserPlus className="w-3 h-3" /> Quick hire
              </button>
            </label>
            <select value={sellerId} onChange={e => setSellerId(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="">— Unassigned —</option>
              {data.employees.filter(e => e.jobInfo.status === 'active').map(e => (
                <option key={e.id} value={e.id}>{e.personalInfo.fullName} ({e.jobInfo.role})</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Payment Method</label>
            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="cash">Hard Cash</option>
              <option value="bank">Direct Bank Transfer</option>
              <option value="mobile">MFS Mobile wallet</option>
              <option value="card">Credit/Debit Card terminal</option>
              <option value="cod">Cash on Delivery</option>
            </select>
          </div>
        </div>

        {/* Embedded Add Employee Drawer */}
        {showEmbeddedAddEmp && (
          <div className="bg-[#FAF8FE] dark:bg-[#232127] p-4 rounded-2xl border border-[#D0BCFF]/30 flex flex-col sm:flex-row gap-3 items-end">
            <div className="flex-1 space-y-1">
              <label className="text-[9px] font-bold text-indigo-400 uppercase">Employee Full Name</label>
              <input value={fastEmpName} onChange={e => setFastEmpName(e.target.value)} placeholder="e.g. Donna Paulsen" className="border border-neutral-200 dark:border-neutral-850 p-2.5 rounded-xl text-xs bg-white dark:bg-[#1C1B1F] w-full" />
            </div>
            <div className="w-full sm:w-48 space-y-1">
              <label className="text-[9px] font-bold text-indigo-400 uppercase">Default Job Role</label>
              <select value={fastEmpRole} onChange={e => setFastEmpRole(e.target.value)} className="border border-neutral-200 dark:border-neutral-850 p-2.5 rounded-xl text-xs bg-white dark:bg-[#1C1B1F] w-full">
                <option value="Salesperson">Salesperson</option>
                <option value="Manager">Roster Manager</option>
                <option value="Accountant">Clerk Accountant</option>
              </select>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <button type="button" onClick={handleEmbeddedEmpAdd} className="px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 cursor-pointer">Hire</button>
              <button type="button" onClick={() => setShowEmbeddedAddEmp(false)} className="px-4 py-2.5 rounded-xl border border-neutral-200 text-xs font-bold cursor-pointer dark:bg-[#1C1B1F]">Close</button>
            </div>
          </div>
        )}

        {/* Override Contact values if manual billing occurs */}
        <div className="bg-[#FAF8FE]/50 dark:bg-[#25232a]/20 p-4 rounded-2xl border border-neutral-100 dark:border-neutral-800 space-y-4">
          <h5 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest leading-none">Billing Address Particulars</h5>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <input value={custName} onChange={e => setCustName(e.target.value)} placeholder="Full Name override" className="border border-neutral-200 dark:border-neutral-800/80 rounded-xl p-2.5 text-xs bg-transparent" />
            <input value={custPhone} onChange={e => setCustPhone(e.target.value)} placeholder="Contact Phone override" className="border border-neutral-200 dark:border-neutral-800/80 rounded-xl p-2.5 text-xs bg-transparent" />
            <input value={custEmail} onChange={e => setCustEmail(e.target.value)} placeholder="Email override" className="border border-neutral-200 dark:border-neutral-800/80 rounded-xl p-2.5 text-xs bg-transparent" />
          </div>
          <textarea value={customerAddress} onChange={e => setCustomerAddress(e.target.value)} placeholder="Complete billing / shipping address coordinates..." className="border border-neutral-200 dark:border-neutral-800/80 rounded-xl p-2.5 text-xs bg-transparent w-full" rows={2} />
        </div>

        {/* Dynamic transaction list rows */}
        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-2 uppercase tracking-wider">Purchase Lines</h4>
          <div className="space-y-4">
            {items.map((row, idx) => {
              const sizesAvailable = data.products.find(p => p.id === row.productId)?.basicInfo.size.split(',').map(s => s.trim()).filter(Boolean) || [];
              const availableInventoryQty = data.products.find(p => p.id === row.productId)?.stock.available || 0;
              const hasCriticalStock = availableInventoryQty < row.quantity && row.productId;

              return (
                <div key={idx} className="bg-white dark:bg-[#1C1B1F] p-4 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex flex-col md:flex-row gap-3 items-end shadow-sm">
                  <div className="flex-1 min-w-[200px] flex flex-col gap-1 w-full">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Product SKU or Name</label>
                    <select
                      value={row.productId}
                      onChange={e => handleRowProductChanged(idx, e.target.value)}
                      className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2.5 text-xs bg-transparent w-full dark:bg-[#1C1B1F]"
                    >
                      <option value="">— Choose product —</option>
                      {data.products.filter(p => p.status === 'active').map(p => (
                        <option key={p.id} value={p.id}>
                          {p.basicInfo.name} ({p.sku} – {data.config.currency}{p.pricing.salePrice}) (Stock: {p.stock.available})
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  {/* Size Selector */}
                  <div className="w-full md:w-32 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Design Size</label>
                    <select
                      value={row.size}
                      onChange={e => {
                        const updated = [...items];
                        updated[idx].size = e.target.value;
                        setItems(updated);
                      }}
                      className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2.5 text-xs bg-transparent w-full dark:bg-[#1C1B1F]"
                    >
                      {sizesAvailable.length === 0 ? (
                        <option value="">— N/A —</option>
                      ) : (
                        sizesAvailable.map(sz => (
                          <option key={sz} value={sz}>{sz}</option>
                        ))
                      )}
                      <option value="Custom">Custom</option>
                    </select>
                  </div>

                  {row.size === 'Custom' && (
                    <div className="w-full md:w-28 flex flex-col gap-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase">Custom Size Value</label>
                      <input
                        placeholder="e.g. 5m"
                        onChange={e => {
                          // Keep temporary input context or process size logic
                        }}
                        className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2 text-xs bg-transparent w-full"
                      />
                    </div>
                  )}

                  <div className="w-full md:w-20 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Quantity</label>
                    <input
                      type="number"
                      min={1}
                      value={row.quantity}
                      onChange={e => handleRowNumericChanged(idx, 'quantity', parseInt(e.target.value) || 1)}
                      className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2 text-xs bg-transparent w-full font-mono font-bold"
                    />
                  </div>

                  <div className="w-full md:w-24 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Sale Unit Price</label>
                    <input
                      type="number"
                      step="0.01"
                      value={row.unitPrice}
                      onChange={e => handleRowNumericChanged(idx, 'unitPrice', parseFloat(e.target.value) || 0)}
                      className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2 text-xs bg-transparent w-full font-mono"
                    />
                  </div>

                  <div className="w-full md:w-20 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Discount</label>
                    <input
                      type="number"
                      step="0.01"
                      value={row.discount}
                      onChange={e => handleRowNumericChanged(idx, 'discount', parseFloat(e.target.value) || 0)}
                      className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2 text-xs bg-transparent w-full font-mono text-red-500"
                    />
                  </div>

                  <div className="w-full md:w-20 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">VAT Tax %</label>
                    <input
                      type="number"
                      step="0.5"
                      value={row.taxRate}
                      onChange={e => handleRowNumericChanged(idx, 'taxRate', parseFloat(e.target.value) || 0)}
                      className="border border-neutral-200 dark:border-neutral-850 rounded-xl p-2 text-xs bg-transparent w-full font-mono"
                    />
                  </div>

                  {/* Remove Row */}
                  <button
                    type="button"
                    disabled={items.length === 1}
                    onClick={() => removeRow(idx)}
                    className="p-3 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors disabled:opacity-35 disabled:hover:bg-transparent flex-shrink-0 cursor-pointer"
                  >
                    <Trash className="w-4 h-4" />
                  </button>

                  {/* Out of Stock Indicators warning */}
                  {hasCriticalStock && (
                    <div className="w-full text-left text-[10px] text-amber-500 font-bold mt-1 tracking-tight">
                      ⚠️ Stock warning: Only {availableInventoryQty} left in inventory! Order may trigger negative availability levels.
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <button type="button" onClick={addRow} className="mt-3 px-4 py-2 border border-dashed border-neutral-300 dark:border-neutral-700 text-[#6750A4] dark:text-[#D0BCFF] text-xs font-bold rounded-2xl flex items-center gap-1 hover:bg-neutral-50 dark:hover:bg-neutral-850 cursor-pointer">
            <Plus className="w-4 h-4" /> Add Row Item
          </button>
        </div>

        {/* Extended Invoice States and totals layout */}
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Invoice Status</label>
                <select value={invoiceStatus} onChange={e => setInvoiceStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                  <option value="draft">Draft (Holds inventory safe)</option>
                  <option value="issued">Issued / Unpaid</option>
                  <option value="partial">Partial Payment Collected</option>
                  <option value="paid">Sales fully Paid</option>
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Payment Received ({data.config.currency})</label>
                <input value={paidAmount} type="number" step="0.01" onChange={e => setPaidAmount(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Payment Transact ID</label>
                <input value={transactionId} onChange={e => setTransactionId(e.target.value)} placeholder="e.g. TXN9824312" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Campaign Promo Coupon</label>
                <select value={promoCode} onChange={e => setPromoCode(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                  <option value="">— No Code —</option>
                  {data.offers.filter(o => o.status === 'active').map(o => (
                    <option key={o.id} value={o.promoCode}>{o.promoCode} ({o.type === 'percentage' ? `${o.value}%` : `${data.config.currency}${o.value}`} Off)</option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Maturity Due Date</label>
                <input value={dueDate} type="date" onChange={e => setDueDate(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
              </div>
            </div>

            <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Terms of shipping, delivery details..." className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" rows={2} />
          </div>

          {/* Checkout billing grid */}
          <div className="w-full md:w-80 bg-[#FAF8FE] dark:bg-[#201E24] p-5 border border-neutral-200 dark:border-neutral-800 rounded-[28px] h-fit space-y-3.5">
            <h5 className="font-bold text-xs uppercase text-neutral-400 tracking-wider">Dynamic Balance Sheet</h5>
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-neutral-500">Retail Sub-Total</span>
              <span className="font-mono">{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(subTotalSum)}</span>
            </div>
            <div className="flex justify-between text-xs font-semibold text-rose-500">
              <span>Total Promotions Discount</span>
              <span className="font-mono">-{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(totalDiscountSum)}</span>
            </div>
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-neutral-500">Total Charged VAT Tax</span>
              <span className="font-mono">+{new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(totalTaxSum)}</span>
            </div>
            <hr className="border-neutral-200 dark:border-neutral-850" />
            <div className="flex justify-between text-sm font-bold text-neutral-900 dark:text-neutral-100">
              <span>GRAND NET TOTAL</span>
              <span className="font-mono text-base text-[#6750A4] dark:text-[#D0BCFF]">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(grandTotalSum)}
              </span>
            </div>
            <div className="flex justify-between text-xs font-bold text-neutral-500">
              <span>Outstanding Due Balance</span>
              <span className="font-mono text-rose-500">
                {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(Math.max(0, grandTotalSum - paidAmount))}
              </span>
            </div>

            <div className="pt-3">
              <label className="flex items-start gap-2 text-neutral-600 dark:text-neutral-400 font-medium text-[10px] leading-relaxed cursor-pointer select-none">
                <input type="checkbox" checked={termsApplied} onChange={e => setTermsApplied(e.target.checked)} className="mt-1 flex-shrink-0" />
                <span>By compiled checklist, apply all corporate system terms & conditions to John Doe.</span>
              </label>
              {termsApplied && (
                <textarea value={terms} onChange={e => setTerms(e.target.value)} placeholder="Terms statement e.g. Shipping 5 Days standard terms" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-2.5 text-[10px] bg-transparent w-full mt-2" rows={1} />
              )}
            </div>
          </div>
        </div>

      </form>
    </MaterialModal>
  );
};

// ==================== MANUAL FINANCE ITEM ====================
export const FinanceFormModal: React.FC<{ type: 'income' | 'expense'; onClose: () => void }> = ({ type, onClose }) => {
  const { addFinanceItem, data } = useERP();
  const [amount, setAmount] = useState(0);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [source, setSource] = useState('manual');
  const [referenceId, setReferenceId] = useState('');
  const [category, setCategory] = useState('');
  const [note, setNote] = useState('');

  const handleSubmit = () => {
    if (amount <= 0) {
      alert('Supply a valid amount.');
      return;
    }

    addFinanceItem(type, {
      amount,
      date,
      source: type === 'income' ? source : undefined,
      referenceId: type === 'income' ? referenceId : undefined,
      category: type === 'expense' ? category : undefined,
      note: type === 'expense' ? note : undefined
    });
    onClose();
  };

  return (
    <MaterialModal title={type === 'income' ? 'Record Cash Inward Receipt' : 'Record Operating Outflow Expense'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-4" onSubmit={e => e.preventDefault()}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Amount ({data.config.currency}) *</label>
            <input value={amount} type="number" onChange={e => setAmount(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Transaction Date</label>
            <input value={date} type="date" onChange={e => setDate(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
        </div>

        {type === 'income' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Inflow Channel Source</label>
              <select value={source} onChange={e => setSource(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="manual">Manual Cash Balance</option>
                <option value="other">Investments returns</option>
                <option value="other_sales">Outside catalog sale</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">External Slip Reference</label>
              <input value={referenceId} onChange={e => setReferenceId(e.target.value)} placeholder="e.g. SLIP-67" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Expense Category</label>
              <input value={category} onChange={e => setCategory(e.target.value)} placeholder="e.g. Rent, Wages, Utility Bills" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full animate-fade-in" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Voucher Memo Notes</label>
              <input value={note} onChange={e => setNote(e.target.value)} placeholder="Wages for May 2026..." className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
          </div>
        )}
      </form>
    </MaterialModal>
  );
};

// ==================== EMPLOYEE FORM ====================
export const EmployeeFormModal: React.FC<{ editEmployee?: Employee; onClose: () => void }> = ({ editEmployee, onClose }) => {
  const { addEmployee, updateEmployee } = useERP();
  const [fullName, setFullName] = useState(editEmployee?.personalInfo.fullName || '');
  const [phone, setPhone] = useState(editEmployee?.personalInfo.phone || '');
  const [email, setEmail] = useState(editEmployee?.personalInfo.email || '');
  const [address, setAddress] = useState(editEmployee?.personalInfo.address || '');
  const [NID, setNId] = useState(editEmployee?.personalInfo.NID || '');
  const [fatherName, setFatherName] = useState(editEmployee?.personalInfo.fatherName || '');
  const [motherName, setMotherName] = useState(editEmployee?.personalInfo.motherName || '');
  const [department, setDepartment] = useState(editEmployee?.jobInfo.department || '');
  const [role, setRole] = useState(editEmployee?.jobInfo.role || 'Employee');
  const [salary, setSalary] = useState(editEmployee?.jobInfo.salary || 0);
  const [joinDate, setJoinDate] = useState(editEmployee?.jobInfo.joinDate ? editEmployee.jobInfo.joinDate.slice(0, 10) : '');
  const [status, setStatus] = useState<Employee['jobInfo']['status']>(editEmployee?.jobInfo.status || 'active');

  const handleSubmit = () => {
    if (!fullName) {
      alert('Provide full employee name.');
      return;
    }

    const payload = {
      personalInfo: { fullName, phone, email, address, NID, fatherName, motherName },
      jobInfo: { department, role, status, salary, joinDate: joinDate ? new Date(joinDate + 'T00:00:00').toISOString() : null }
    };

    if (editEmployee) {
      updateEmployee({
        ...editEmployee,
        ...payload
      });
    } else {
      addEmployee(payload);
    }
    onClose();
  };

  return (
    <MaterialModal title={editEmployee ? 'Update Employee Dossier' : 'Hire New Employee'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-6" onSubmit={e => e.preventDefault()}>
        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Bio identity Files</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Employee Full Name *</label>
              <input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="e.g. Donna Paulsen" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Contact Phone</label>
              <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+1 555-4011" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Identity National NID / SSN</label>
              <input value={NID} onChange={e => setNId(e.target.value)} placeholder="NID98341" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Corporate Email</label>
              <input value={email} type="email" onChange={e => setEmail(e.target.value)} placeholder="donna@acme.com" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Father's Name</label>
              <input value={fatherName} onChange={e => setFatherName(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Mother's Name</label>
              <input value={motherName} onChange={e => setMotherName(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
          </div>
          <div className="flex flex-col gap-1 mt-4">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Permanent Residence Address</label>
            <input value={address} onChange={e => setAddress(e.target.value)} placeholder="State warehouse 4 quarters..." className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
        </div>

        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-3 uppercase tracking-wider">Payroll & job Specification</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Corporate Department</label>
              <input value={department} onChange={e => setDepartment(e.target.value)} placeholder="e.g. Accounts, HR, Sales" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Designation Job Role</label>
              <input value={role} onChange={e => setRole(e.target.value)} placeholder="e.g. Sales Agent" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Monthly Salary</label>
              <input value={salary} type="number" onChange={e => setSalary(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full font-mono" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Join Date</label>
              <input value={joinDate} type="date" onChange={e => setJoinDate(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase">Roster Status</label>
              <select value={status} onChange={e => setStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
                <option value="active">Active Employed</option>
                <option value="inactive">On long leave</option>
                <option value="terminated">Fired / Contract Terminated</option>
              </select>
            </div>
          </div>
        </div>
      </form>
    </MaterialModal>
  );
};

// ==================== SUPPLIER FORM ====================
export const SupplierFormModal: React.FC<{ editSupplier?: Supplier; onClose: () => void }> = ({ editSupplier, onClose }) => {
  const { addSupplier, updateSupplier } = useERP();
  const [name, setName] = useState(editSupplier?.name || '');
  const [company, setCompany] = useState(editSupplier?.company || '');
  const [phone, setPhone] = useState(editSupplier?.phone || '');
  const [email, setEmail] = useState(editSupplier?.email || '');
  const [address, setAddress] = useState(editSupplier?.address || '');
  const [paymentTerms, setPaymentTerms] = useState(editSupplier?.paymentTerms || 'Net 30');
  const [rating, setRating] = useState(editSupplier?.rating || 5);

  const handleSubmit = () => {
    if (!name || !company) {
      alert('Provide supplier Name and corporate Company titles.');
      return;
    }

    const payload = { name, company, phone, email, address, paymentTerms, rating };

    if (editSupplier) {
      updateSupplier({
        ...editSupplier,
        ...payload
      });
    } else {
      addSupplier(payload);
    }
    onClose();
  };

  return (
    <MaterialModal title={editSupplier ? 'Edit Supplier logistics file' : 'Onboard New Raw Supplier'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-4" onSubmit={e => e.preventDefault()}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Contact Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Mike Ross" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Corporate Provider Name *</label>
            <input value={company} onChange={e => setCompany(e.target.value)} placeholder="e.g. Global Logistics Corp" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Contact Phone</label>
            <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+1 555-0202" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Company Email</label>
            <input value={email} type="email" onChange={e => setEmail(e.target.value)} placeholder="sales@global.com" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Standard Payment Terms</label>
            <input value={paymentTerms} onChange={e => setPaymentTerms(e.target.value)} placeholder="Net 30" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Supplier Standard Rating (1 to 5)</label>
            <select value={rating} onChange={e => setRating(parseInt(e.target.value) || 5)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="5">⭐⭐⭐⭐⭐ Prime Logistics</option>
              <option value="4">⭐⭐⭐⭐ Great Response</option>
              <option value="3">⭐⭐⭐ Standard Transit</option>
              <option value="2">⭐⭐ Slow Shipping</option>
              <option value="1">⭐ Poor Contract</option>
            </select>
          </div>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-neutral-400 uppercase">Warehouse Headquarters Address</label>
          <input value={address} onChange={e => setAddress(e.target.value)} placeholder="789 Industrial Drive" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
        </div>
      </form>
    </MaterialModal>
  );
};

// ==================== PURCHASE (PO) FORM ====================
export const PurchaseFormModal: React.FC<{ editPurchase?: Purchase; onClose: () => void }> = ({ editPurchase, onClose }) => {
  const { addPurchase, updatePurchase, data } = useERP();
  const [supplierId, setSupplierId] = useState(editPurchase?.supplierId || '');
  const [status, setStatus] = useState<Purchase['status']>(editPurchase?.status || 'pending');
  const [paymentMethod, setPaymentMethod] = useState(editPurchase?.paymentMethod || 'cash');
  const [transactionId, setTransactionId] = useState(editPurchase?.transactionId || '');

  // Procurement items list in row grid
  const [items, setItems] = useState<PurchaseItem[]>(editPurchase?.items || [
    { productId: '', quantity: 1, costPrice: 0, size: '', notes: '' }
  ]);
  
  const [totalCost, setTotalCost] = useState(0);

  useEffect(() => {
    let sum = 0;
    items.forEach(row => { sum += (row.quantity * row.costPrice); });
    setTotalCost(sum);
  }, [items]);

  const handleRowProductChanged = (idx: number, pid: string) => {
    const updated = [...items];
    const match = data.products.find(p => p.id === pid);
    if (match) {
      updated[idx] = {
        ...updated[idx],
        productId: pid,
        costPrice: match.pricing.costPrice,
        size: match.basicInfo.size.split(',')[0]?.trim() || '',
      };
    } else {
      updated[idx] = { ...updated[idx], productId: pid, costPrice: 0 };
    }
    setItems(updated);
  };

  const addRow = () => {
    setItems([...items, { productId: '', quantity: 1, costPrice: 0, size: '', notes: '' }]);
  };

  const removeRow = (idx: number) => {
    setItems(items.filter((_, i) => i !== idx));
  };

  const handleSubmit = () => {
    if (!supplierId || items.some(it => !it.productId)) {
      alert('Must select a partner supplier and catalog items.');
      return;
    }

    const payload = { supplierId, items, totalCost, status, paymentMethod, transactionId };

    if (editPurchase) {
      updatePurchase({
        ...editPurchase,
        ...payload
      });
    } else {
      addPurchase(payload);
    }
    onClose();
  };

  return (
    <MaterialModal title={editPurchase ? `Edit Procurement Order PO-${editPurchase.id}` : 'Draft New Supplier Purchase Order'} onClose={onClose} onSubmit={handleSubmit} submitLabel="Compile Order">
      <form className="space-y-6" onSubmit={e => e.preventDefault()}>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex flex-col gap-1 md:col-span-2">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Procuring from Supplier *</label>
            <select value={supplierId} onChange={e => setSupplierId(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="">— Select Supplier —</option>
              {data.suppliers.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.company})</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-[#6750A4] dark:text-[#D0BCFF] uppercase font-sans">Payment Method</label>
            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="cash">Hard Cash</option>
              <option value="bank">Direct Bank Transfer</option>
              <option value="card">Corporate Credit Card</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400">LOG TRANSACTION VOUCHER ID</label>
            <input value={transactionId} onChange={e => setTransactionId(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
        </div>

        {/* PO items row listing */}
        <div>
          <h4 className="text-sm font-bold text-neutral-500 mb-2 uppercase tracking-wider">Purchase Lines</h4>
          <div className="space-y-4">
            {items.map((row, idx) => {
              const sizesAvailable = data.products.find(p => p.id === row.productId)?.basicInfo.size.split(',').map(s => s.trim()).filter(Boolean) || [];

              return (
                <div key={idx} className="bg-[#FAF8FE] dark:bg-[#201E24]/30 p-4 border border-neutral-200 dark:border-neutral-850 rounded-2xl flex flex-col sm:flex-row gap-3 items-end">
                  <div className="flex-1 flex flex-col gap-1 min-w-[200px] w-full">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Item sku / Name</label>
                    <select
                      value={row.productId}
                      onChange={e => handleRowProductChanged(idx, e.target.value)}
                      className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-2.5 text-xs bg-transparent dark:bg-[#1C1B1F]"
                    >
                      <option value="">— Select Catalog Item —</option>
                      {data.products.map(p => (
                        <option key={p.id} value={p.id}>{p.basicInfo.name} ({p.sku}) – Cost: {data.config.currency}{p.pricing.costPrice}</option>
                      ))}
                    </select>
                  </div>

                  <div className="w-full sm:w-28 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400">SIZE</label>
                    <input
                      value={row.size}
                      onChange={e => {
                        const updated = [...items];
                        updated[idx].size = e.target.value;
                        setItems(updated);
                      }}
                      className="border border-neutral-200 p-2.5 text-xs bg-transparent w-full rounded-xl"
                      list={`procSizeList_${idx}`}
                    />
                    <datalist id={`procSizeList_${idx}`}>
                      {sizesAvailable.map(sz => <option key={sz} value={sz} />)}
                    </datalist>
                  </div>

                  <div className="w-full sm:w-24 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Quantity</label>
                    <input
                      type="number"
                      min={1}
                      value={row.quantity}
                      onChange={e => {
                        const updated = [...items];
                        updated[idx].quantity = parseInt(e.target.value) || 1;
                        setItems(updated);
                      }}
                      className="border border-neutral-200 rounded-xl p-2 text-xs bg-transparent w-full font-mono font-bold"
                    />
                  </div>

                  <div className="w-full sm:w-32 flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase">Cost Unit Price</label>
                    <input
                      type="number"
                      step="0.01"
                      value={row.costPrice}
                      onChange={e => {
                        const updated = [...items];
                        updated[idx].costPrice = parseFloat(e.target.value) || 0;
                        setItems(updated);
                      }}
                      className="border border-neutral-200 rounded-xl p-2 text-xs bg-transparent w-full font-mono"
                    />
                  </div>

                  <button
                    type="button"
                    disabled={items.length === 1}
                    onClick={() => removeRow(idx)}
                    className="p-3 text-rose-500 hover:bg-rose-50 rounded-xl cursor-pointer"
                  >
                    <Trash className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
          <button type="button" onClick={addRow} className="mt-3 px-4 py-2 border border-dashed border-neutral-300 dark:border-neutral-700 text-[#6750A4] dark:text-[#D0BCFF] text-xs font-bold rounded-2xl flex items-center gap-1 hover:bg-neutral-50 dark:hover:bg-neutral-850 cursor-pointer">
            <Plus className="w-4 h-4" /> Add Row Item
          </button>
        </div>

        {/* Total Cost ledger metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-450 uppercase">Roster Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="pending">Pending Delivery (Stock on-hold)</option>
              <option value="completed">Completed (Adds items to Stock count immediately & records expense)</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] font-bold text-neutral-400 uppercase">Total Procurement Value</span>
            <div className="text-xl font-mono font-bold text-neutral-900 dark:text-neutral-50 p-3 bg-neutral-50 dark:bg-neutral-950/20 rounded-xl border border-neutral-100 dark:border-neutral-850">
              {new Intl.NumberFormat('en-US', { style: 'currency', currency: data.config.currency }).format(totalCost)}
            </div>
          </div>
        </div>
      </form>
    </MaterialModal>
  );
};

// ==================== DELIVERY DISPATCH FORM ====================
export const DeliveryFormModal: React.FC<{ editDelivery?: Delivery; onClose: () => void }> = ({ editDelivery, onClose }) => {
  const { addDelivery, updateDelivery, data } = useERP();
  const [invoiceId, setInvoiceId] = useState(editDelivery?.invoiceId || '');
  const [address, setAddress] = useState(editDelivery?.address || '');
  const [status, setStatus] = useState<Delivery['status']>(editDelivery?.status || 'pending');
  const [cost, setCost] = useState(editDelivery?.cost || 0);

  const handleSubmit = () => {
    if (!invoiceId || !address) {
      alert('Provide invoice number references and customer addresses.');
      return;
    }

    const payload = {
      invoiceId,
      customerId: data.invoices.find(i => i.id === invoiceId)?.customer.customerId || '',
      address,
      status,
      cost
    };

    if (editDelivery) {
      updateDelivery({
        ...editDelivery,
        ...payload
      });
    } else {
      addDelivery(payload);
    }
    onClose();
  };

  const handleInvoiceIdChanged = (idStr: string) => {
    setInvoiceId(idStr);
    const invoice = data.invoices.find(i => i.id === idStr);
    if (invoice) {
      setAddress(invoice.customer.address);
    }
  };

  return (
    <MaterialModal title={editDelivery ? `Update Delivery Dispatch #${editDelivery.id}` : 'Dispatch New Courier Delivery'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-4" onSubmit={e => e.preventDefault()}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Active Invoice ID *</label>
            <select value={invoiceId} onChange={e => handleInvoiceIdChanged(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="">— Select Invoice —</option>
              {data.invoices.filter(i => i.status === 'issued' || i.status === 'paid').map(i => (
                <option key={i.id} value={i.id}>{i.id} – {i.customer.name} ({data.config.currency}{i.calculations.grandTotal})</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Courier Cost ({data.config.currency})</label>
            <input value={cost} type="number" onChange={e => setCost(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Mailing Delivery Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="pending">Pending Dispatch</option>
              <option value="shipped">Shipped / In Transit</option>
              <option value="delivered">Delivered Successfully</option>
            </select>
          </div>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-neutral-400 uppercase">Customer Address</label>
          <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Complete address text coordinates" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
        </div>
      </form>
    </MaterialModal>
  );
};

// ==================== CAMPAIGN OFFER (COUPON) FORM ====================
export const OfferFormModal: React.FC<{ editOffer?: Offer; onClose: () => void }> = ({ editOffer, onClose }) => {
  const { addOffer, updateOffer, data } = useERP();
  const [name, setName] = useState(editOffer?.name || '');
  const [promoCode, setPromoCode] = useState(editOffer?.promoCode || '');
  const [type, setType] = useState<Offer['type']>(editOffer?.type || 'percentage');
  const [value, setValue] = useState(editOffer?.value || 0);
  const [productId, setProductId] = useState(editOffer?.productId || '');
  const [startDate, setStartDate] = useState(editOffer?.startDate ? editOffer.startDate.slice(0, 10) : '');
  const [expiryDate, setExpiryDate] = useState(editOffer?.expiryDate ? editOffer.expiryDate.slice(0, 10) : '');
  const [status, setStatus] = useState<Offer['status']>(editOffer?.status || 'active');

  const handleSubmit = () => {
    if (!name || !promoCode || value <= 0) {
      alert('Provide campaign Coupon Name, unique Promo Code and credit Value.');
      return;
    }

    const payload = {
      name, promoCode: promoCode.toUpperCase().replace(/\s/g, ''),
      type, value,
      productId: productId || null,
      startDate: startDate ? new Date(startDate + 'T00:00:00').toISOString() : null,
      expiryDate: expiryDate ? new Date(expiryDate + 'T23:59:59').toISOString() : null,
      status
    };

    if (editOffer) {
      updateOffer({
        ...editOffer,
        ...payload
      });
    } else {
      addOffer(payload);
    }
    onClose();
  };

  return (
    <MaterialModal title={editOffer ? 'Edit Coupon Promo Campaign' : 'Create New Campaign Promo Code'} onClose={onClose} onSubmit={handleSubmit}>
      <form className="space-y-4" onSubmit={e => e.preventDefault()}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Campaign Custom Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Eid Super Sale" className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase font-mono font-bold text-[#6750A4] dark:text-[#D0BCFF]">COUPON PROMO CODE *</label>
            <input value={promoCode} onChange={e => setPromoCode(e.target.value)} placeholder="e.g. SUMMER10" className="border border-neutral-200 dark:border-[#6750A4]/30 rounded-xl p-3 text-sm bg-transparent w-full font-mono font-bold leading-none" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Discount Method Type</label>
            <select value={type} onChange={e => setType(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="percentage">Percentage Off (%)</option>
              <option value="fixed">Fixed Cash deduction</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Reduction Credit Value *</label>
            <input value={value} type="number" step="0.1" onChange={e => setValue(parseFloat(e.target.value) || 0)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full font-mono" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Campaign Applicability</label>
            <select value={productId} onChange={e => setProductId(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="">— Entire Shop (Store-wide coupon) —</option>
              {data.products.map(p => (
                <option key={p.id} value={p.id}>{p.basicInfo.name} ({p.sku})</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase font-sans">Campaign Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as any)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full dark:bg-[#1C1B1F]">
              <option value="active">Active Activity</option>
              <option value="inactive">Paused Campaign</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Active start Date</label>
            <input value={startDate} type="date" onChange={e => setStartDate(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold text-neutral-400 uppercase">Campaign Expiry Code Date</label>
            <input value={expiryDate} type="date" onChange={e => setExpiryDate(e.target.value)} className="border border-neutral-200 dark:border-neutral-800 rounded-xl p-3 text-sm bg-transparent w-full" />
          </div>
        </div>
      </form>
    </MaterialModal>
  );
};
