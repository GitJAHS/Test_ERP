/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  Customer, Product, Invoice, Sale, FinanceState, Employee, Supplier, 
  Purchase, Delivery, Offer, Report, AuditLog, SystemConfig, BusinessProfile, 
  ERPDataState, ToastMessage, HeadsUpNotification, SaleItem, InvoicePayment, IncomeRecord
} from '../types';

interface ERPContextType {
  activeProfileId: string | null;
  profiles: BusinessProfile[];
  data: ERPDataState;
  toasts: ToastMessage[];
  activeHeadsUp: HeadsUpNotification | null;
  headsUpHistory: HeadsUpNotification[];
  networkOnline: boolean;
  googleToken: string | null;
  syncStatus: 'Offline' | 'Online' | 'Syncing...' | 'Error';
  
  // Actions
  switchProfile: (profileId: string) => void;
  createProfile: (name: string) => void;
  renameProfile: (profileId: string, newName: string) => void;
  deleteProfile: (profileId: string) => void;
  
  // Handlers
  addCustomer: (cust: Omit<Customer, 'id' | 'createdAt' | 'updatedAt' | 'financialInfo'>) => void;
  updateCustomer: (cust: Customer) => void;
  deleteCustomer: (id: string) => void;
  
  addProduct: (prod: Omit<Product, 'id' | 'sku' | 'createdAt' | 'stock'> & { quantity: number; reorderLevel: number; warehouseLocation: string }) => void;
  updateProduct: (prod: Product) => void;
  deleteProduct: (id: string) => void;
  
  addInvoice: (inv: Omit<Invoice, 'id' | 'createdAt' | 'updatedAt' | 'calculations' | 'payment' | 'stockDeducted'> & { paidAmount: number; paymentMethod?: string; transactionId?: string }) => void;
  updateInvoice: (inv: Invoice) => void;
  deleteInvoice: (id: string) => void;
  
  addFinanceItem: (type: 'income' | 'expense', record: { amount: number; date: string; source?: string; referenceId?: string; category?: string; note?: string }) => void;
  deleteFinanceItem: (type: 'income' | 'expense', id: string) => void;
  
  addEmployee: (emp: Omit<Employee, 'id' | 'attendance' | 'payroll'>) => void;
  updateEmployee: (emp: Employee) => void;
  deleteEmployee: (id: string) => void;
  
  addSupplier: (supp: Omit<Supplier, 'id' | 'suppliedProducts'>) => void;
  updateSupplier: (supp: Supplier) => void;
  deleteSupplier: (id: string) => void;
  
  addPurchase: (purch: Omit<Purchase, 'id' | 'date'>) => void;
  updatePurchase: (purch: Purchase) => void;
  deletePurchase: (id: string) => void;
  
  addDelivery: (del: Omit<Delivery, 'id' | 'tracking'>) => void;
  updateDelivery: (del: Delivery) => void;
  deleteDelivery: (id: string) => void;
  
  addOffer: (ofr: Omit<Offer, 'id' | 'createdAt'>) => void;
  updateOffer: (ofr: Offer) => void;
  deleteOffer: (id: string) => void;
  
  generateReport: () => void;
  saveSettings: (config: SystemConfig) => void;
  addAudit: (action: string, details: string) => void;
  clearAllLocalData: () => void;
  
  // Feedback
  triggerToast: (msg: string, type?: ToastMessage['type']) => void;
  triggerHeadsUp: (title: string, message: string, icon: string, type: HeadsUpNotification['type'], durationMs?: number) => void;
  clearHeadsUp: () => void;
  clearToast: (id: string) => void;
  
  // Google Drive
  gDriveConnect: () => void;
  gDriveDisconnect: () => void;
  syncNow: () => void;
}

const ERPContext = createContext<ERPContextType | undefined>(undefined);

const initialConfig: SystemConfig = {
  company: {
    name: 'Acme Corp',
    address: '123 Main St, Springfield, IL 62701',
    phone: '+1-555-0000'
  },
  language: 'en',
  country: 'US',
  currency: 'USD',
  timezone: 'America/New_York',
  theme: {
    mode: 'light',
    accentColor: '#6750A4'
  },
  settings: {
    autoBackup: true,
    performanceMode: 'standard',
    googleClientId: ''
  },
  logo: null
};

const initialDataState = (): ERPDataState => ({
  customers: [],
  products: [],
  invoices: [],
  sales: [],
  finance: { income: [], expenses: [] },
  employees: [],
  suppliers: [],
  purchases: [],
  deliveries: [],
  offers: [],
  reports: [],
  auditLog: [],
  config: { ...initialConfig }
});

export const ERPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);
  const [profiles, setProfiles] = useState<BusinessProfile[]>([]);
  const [data, setData] = useState<ERPDataState>(initialDataState());
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [activeHeadsUp, setActiveHeadsUp] = useState<HeadsUpNotification | null>(null);
  const [headsUpHistory, setHeadsUpHistory] = useState<HeadsUpNotification[]>([]);
  const [networkOnline, setNetworkOnline] = useState<boolean>(navigator.onLine);
  const [googleToken, setGoogleToken] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<ERPContextType['syncStatus']>('Offline');
  
  const rawDataRef = useRef<ERPDataState>(data);
  rawDataRef.current = data;

  // Sound generator (Web Audio API)
  const playAlertSound = (type: 'beep' | 'success' | 'alert') => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      if (type === 'success') {
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2); // G5
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else if (type === 'alert') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, ctx.currentTime); // A4
        osc.frequency.setValueAtTime(349.23, ctx.currentTime + 0.15); // F4
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else {
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      }
    } catch (e) {
      // Audio context block protection
    }
  };

  // Toast / HeadsUp helper helper
  const triggerToast = (message: string, type: ToastMessage['type'] = 'info') => {
    const id = Date.now().toString(36) + Math.random().toString(36).substr(2, 4);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const triggerHeadsUp = (title: string, message: string, icon: string, type: HeadsUpNotification['type'], durationMs = 6000) => {
    const id = Date.now().toString(36);
    const notification: HeadsUpNotification = {
      id,
      title,
      message,
      icon,
      type,
      timestamp: new Date().toISOString(),
      durationMs
    };
    
    setActiveHeadsUp(notification);
    setHeadsUpHistory(prev => [notification, ...prev].slice(0, 50));
    playAlertSound(type === 'alert' ? 'alert' : 'success');
  };

  const clearHeadsUp = () => setActiveHeadsUp(null);
  const clearToast = (id: string) => setToasts(prev => prev.filter(t => t.id !== id));

  // UID Generator
  const uid = (prefix: string) => {
    return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
  };

  // Log active state audits
  const addAudit = (action: string, details: string) => {
    const activeLog: AuditLog = {
      id: uid('AUDIT'),
      timestamp: new Date().toISOString(),
      user: 'System User',
      role: 'Admin',
      action,
      details
    };
    setData(prev => {
      const updatedLogs = [activeLog, ...prev.auditLog].slice(0, 300);
      return { ...prev, auditLog: updatedLogs };
    });
  };

  // Google sync hooks
  const findOrCreateErpFile = async (token: string): Promise<string> => {
    const res = await fetch('https://www.googleapis.com/drive/v3/files?q=name%3D%22erp_data.json%22%20and%20mimeType%3D%22application%2Fjson%22&spaces=drive&fields=files(id%2Cname)', {
      headers: { Authorization: `Bearer ${token}` }
    });
    const parsed = await res.json();
    if (parsed.files && parsed.files.length > 0) {
      return parsed.files[0].id;
    } else {
      const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: 'erp_data.json',
          mimeType: 'application/json',
        }),
      });
      const file = await createRes.json();
      return file.id;
    }
  };

  const syncBackupToDrive = async (token: string, stateToBackup: any) => {
    try {
      setSyncStatus('Syncing...');
      const fileId = await findOrCreateErpFile(token);
      await fetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(stateToBackup),
      });
      setSyncStatus('Online');
    } catch (e) {
      setSyncStatus('Error');
    }
  };

  const getBackupPayload = () => {
    const backupProfiles = JSON.parse(localStorage.getItem('erp_profiles') || '[]');
    const backupActive = localStorage.getItem('erp_activeProfileId');
    const dataByProfile: any = {};
    backupProfiles.forEach((p: BusinessProfile) => {
      const profileData: any = {};
      const keys = ['customers', 'products', 'invoices', 'sales', 'finance', 'employees', 'suppliers', 'purchases', 'deliveries', 'offers', 'reports', 'auditLog', 'config'];
      keys.forEach(k => {
        const raw = localStorage.getItem(`erp_${p.id}_${k}`);
        if (raw) {
          try {
            profileData[k] = JSON.parse(raw);
          } catch {
            profileData[k] = k === 'finance' ? { income: [], expenses: [] } : (k === 'config' ? { ...initialConfig } : []);
          }
        }
      });
      dataByProfile[p.id] = profileData;
    });
    return { version: 1, profiles: backupProfiles, activeProfileId: backupActive, data: dataByProfile };
  };

  const triggerBackupDebounce = useRef<any>(null);
  const triggerAutoSaveAndBackup = () => {
    if (triggerBackupDebounce.current) clearTimeout(triggerBackupDebounce.current);
    triggerBackupDebounce.current = setTimeout(() => {
      if (googleToken) {
        const payload = getBackupPayload();
        syncBackupToDrive(googleToken, payload);
      }
    }, 3000);
  };

  // Main save function
  const saveAllToLocal = (id: string, updatedData: ERPDataState) => {
    Object.keys(updatedData).forEach(key => {
      localStorage.setItem(`erp_${id}_${key}`, JSON.stringify((updatedData as any)[key]));
    });
    triggerAutoSaveAndBackup();
  };

  // Multi Profiles State Initialization
  useEffect(() => {
    // Sync network online indicator
    const handleOnline = () => {
      setNetworkOnline(true);
      if (googleToken) setSyncStatus('Online');
      triggerToast('System is back online - offline buffer active', 'success');
    };
    const handleOffline = () => {
      setNetworkOnline(false);
      setSyncStatus('Offline');
      triggerToast('System went offline - running in native local mode', 'warning');
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Load Profiles
    let savedProfiles: BusinessProfile[] = [];
    try {
      savedProfiles = JSON.parse(localStorage.getItem('erp_profiles') || '[]');
    } catch {
      savedProfiles = [];
    }

    let savedActiveId = localStorage.getItem('erp_activeProfileId');

    if (!savedProfiles.length) {
      const defaultProf: BusinessProfile = {
        id: 'PROF-DEFAULT',
        name: 'Default Business',
        createdAt: new Date().toISOString()
      };
      savedProfiles = [defaultProf];
      localStorage.setItem('erp_profiles', JSON.stringify(savedProfiles));
      savedActiveId = defaultProf.id;
      localStorage.setItem('erp_activeProfileId', defaultProf.id);
    } else {
      if (!savedActiveId || !savedProfiles.find(p => p.id === savedActiveId)) {
        savedActiveId = savedProfiles[0].id;
        localStorage.setItem('erp_activeProfileId', savedActiveId);
      }
    }

    setProfiles(savedProfiles);
    setActiveProfileId(savedActiveId);

    // Load active profile data
    const activeId = savedActiveId!;
    const loadedData = initialDataState();
    
    Object.keys(loadedData).forEach(k => {
      const raw = localStorage.getItem(`erp_${activeId}_${k}`);
      if (raw) {
        try {
          (loadedData as any)[k] = JSON.parse(raw);
        } catch {
          // fallback
        }
      }
    });

    // Seed dummy metrics on perfect first launch
    if (!loadedData.customers.length && activeId === 'PROF-DEFAULT') {
      const demoCustId = 'CUST-DEMO-1';
      const demoProdId = 'PROD-DEMO-1';
      const demoSaleDate = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString();
      const demoInTransitDate = new Date().toISOString();

      loadedData.customers = [{
        id: demoCustId,
        createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString(),
        personalInfo: {
          fullName: 'John Smith',
          phone: '+1-555-0199',
          email: 'john.smith@gmail.com',
          gender: 'male',
          dateOfBirth: '1988-05-12',
          address: { street: '742 Evergreen Terrace', city: 'Springfield', state: 'IL', country: 'US', postalCode: '62704' }
        },
        businessInfo: { customerType: 'retail', companyName: 'Springfield Nuclear', industry: 'Energy', source: 'online' },
        financialInfo: { creditLimit: 5000, totalSpent: 99.98, totalPaid: 99.98, totalDue: 0, loyaltyPoints: 100, riskLevel: 'low' },
        status: 'active'
      }, {
        id: 'CUST-DEMO-2',
        createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString(),
        personalInfo: {
          fullName: 'Acme Enterprise',
          phone: '+1-555-0100',
          email: 'billing@acme.com',
          gender: 'other',
          dateOfBirth: '',
          address: { street: '1 Infinite Loop', city: 'Cupertino', state: 'CA', country: 'US', postalCode: '95014' }
        },
        businessInfo: { customerType: 'wholesale', companyName: 'Acme Corp Wholesale', industry: 'General', source: 'referral' },
        financialInfo: { creditLimit: 25000, totalSpent: 2450.00, totalPaid: 1450.00, totalDue: 1000.00, loyaltyPoints: 2450, riskLevel: 'medium' },
        status: 'active'
      }];

      loadedData.products = [{
        id: demoProdId,
        sku: 'SKU-WIDGET-01',
        barcode: '880123456789',
        basicInfo: {
          name: 'Super Widget Standard Edition',
          description: 'High-performance processing widget',
          category: 'Hardware',
          brand: 'CoreSystems',
          size: 'Standard, Large, Pro Edition',
          notes: 'Keep dry at all room temperatures'
        },
        pricing: { costPrice: 20.00, salePrice: 49.99, taxRate: 10, discount: 5 },
        stock: { quantity: 120, reserved: 2, available: 118, reorderLevel: 25, warehouseLocation: 'Aisle-4A' },
        supplierId: 'SUPP-DEMO-1',
        status: 'active',
        createdAt: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000).toISOString()
      }, {
        id: 'PROD-DEMO-2',
        sku: 'SKU-CABLE-02',
        barcode: '880987654321',
        basicInfo: {
          name: 'Optical Fiber Cable gold-plated',
          description: 'Gold-plated zero latency data connection',
          category: 'Accesories',
          brand: 'LinkTech',
          size: '2m, 5m',
          notes: ''
        },
        pricing: { costPrice: 5.00, salePrice: 15.00, taxRate: 5, discount: 0 },
        stock: { quantity: 200, reserved: 0, available: 8, reorderLevel: 15, warehouseLocation: 'Aisle-2C' }, // triggers low stock warning!
        supplierId: 'SUPP-DEMO-1',
        status: 'active',
        createdAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString()
      }];

      loadedData.suppliers = [{
        id: 'SUPP-DEMO-1',
        name: 'Nexus Logistics & Supply',
        company: 'Nexus LLC',
        phone: '+1-555-8933',
        email: 'partners@nexuslogistics.com',
        address: '500 Logistics Way, Chicago, IL',
        paymentTerms: 'Net 30',
        rating: 5,
        suppliedProducts: [demoProdId, 'PROD-DEMO-2']
      }];

      loadedData.invoices = [{
        id: 'INV-DEMO-123',
        createdAt: demoSaleDate,
        updatedAt: demoSaleDate,
        businessId: 'Acme Corp',
        customer: { customerId: demoCustId, name: 'John Smith', phone: '+1-555-0199', email: 'john.smith@gmail.com', address: '742 Evergreen Terrace, Springfield, IL' },
        seller: { id: 'EMP-DEMO-1', name: 'Sarah Connor', role: 'Salesperson' },
        items: [{
          productId: demoProdId,
          name: 'Super Widget Standard Edition',
          size: 'Standard',
          quantity: 2,
          unitPrice: 49.99,
          discount: 5.00,
          taxRate: 10,
          subtotal: 99.98
        }],
        calculations: { subTotal: 99.98, totalDiscount: 10.00, totalTax: 9.00, grandTotal: 98.98 },
        payment: { status: 'paid', method: 'cash', paidAmount: 98.98, dueAmount: 0, transactionId: 'TXN-CASH-998' },
        status: 'paid',
        dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
        promo: null,
        note: 'Customer loyalty points applied.',
        terms: 'Payment is standard COD.',
        termsApplied: true,
        stockDeducted: true
      }, {
        id: 'INV-DEMO-124',
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString(),
        businessId: 'Acme Corp',
        customer: { customerId: 'CUST-DEMO-2', name: 'Acme Enterprise', phone: '+1-555-0100', email: 'billing@acme.com', address: '1 Infinite Loop, Cupertino, CA' },
        seller: null,
        items: [{
          productId: demoProdId,
          name: 'Super Widget Standard Edition',
          size: 'Pro Edition',
          quantity: 1,
          unitPrice: 49.99,
          discount: 0,
          taxRate: 10,
          subtotal: 54.99
        }],
        calculations: { subTotal: 49.99, totalDiscount: 0, totalTax: 5.00, grandTotal: 54.99 },
        payment: { status: 'partial', method: 'bank', paidAmount: 20.00, dueAmount: 34.99, transactionId: 'TX-BANK-101' },
        status: 'partial',
        dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // overdue!
        promo: null,
        note: '',
        terms: '',
        termsApplied: false,
        stockDeducted: true
      }];

      loadedData.sales = [{
        id: 'SALE-DEMO-1',
        invoiceId: 'INV-DEMO-123',
        customerId: demoCustId,
        seller: { id: 'EMP-DEMO-1', name: 'Sarah Connor', role: 'Salesperson' },
        items: [{ productId: demoProdId, quantity: 2, price: 49.99 }],
        totalAmount: 98.98,
        profit: 58.98,
        date: demoSaleDate,
        status: 'completed'
      }];

      loadedData.finance = {
        income: [
          { id: 'INC-DEMO-1', source: 'invoice', amount: 98.98, date: demoSaleDate, referenceId: 'INV-DEMO-123' },
          { id: 'INC-DEMO-2', source: 'manual', amount: 500.00, date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString() }
        ],
        expenses: [
          { id: 'EXP-DEMO-1', category: 'Rent', amount: 300.00, date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), note: 'Acre central warehouse rent' },
          { id: 'EXP-DEMO-2', category: 'Utility', amount: 75.00, date: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(), note: 'Broadband, high-voltage' }
        ]
      };

      loadedData.employees = [{
        id: 'EMP-DEMO-1',
        personalInfo: { fullName: 'Sarah Connor', phone: '+1-555-9000', email: 'sarah.connor@proton.me', address: 'Unknown Hill, CA', NID: '98453412', fatherName: 'Unknown', motherName: 'Unknown' },
        jobInfo: { department: 'Sales', role: 'Salesperson', salary: 3400, joinDate: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000).toISOString(), status: 'active' },
        attendance: [],
        payroll: []
      }, {
        id: 'EMP-DEMO-2',
        personalInfo: { fullName: 'Marcus Wright', phone: '+1-555-4011', email: 'marcus@cyberdyne.org', address: 'Chicago Warehouse 4', NID: '12445589', fatherName: 'Joseph Wright', motherName: 'Elena Wright' },
        jobInfo: { department: 'Logistics', role: 'Shipper', salary: 2800, joinDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(), status: 'active' },
        attendance: [],
        payroll: []
      }];

      loadedData.deliveries = [{
        id: 'DEL-DEMO-1',
        invoiceId: 'INV-DEMO-124',
        customerId: 'CUST-DEMO-2',
        address: '1 Infinite Loop, Cupertino, CA',
        status: 'shipped',
        tracking: [{ timestamp: demoInTransitDate, location: 'San Jose Depot', status: 'In Transit' }],
        cost: 15.00
      }];

      loadedData.offers = [{
        id: 'PROM-DEMO-1',
        name: 'Eid/Summer Super Sale',
        promoCode: 'SUMMER2026',
        type: 'percentage',
        value: 10,
        productId: null,
        startDate: new Date().toISOString(),
        expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'active',
        createdAt: new Date().toISOString()
      }];

      loadedData.auditLog = [{
        id: 'AUD-DEMO-1',
        timestamp: new Date().toISOString(),
        user: 'System Admin',
        role: 'Admin',
        action: 'system_initialized',
        details: 'ERP System demo databases successfully bootstrapped on user sandbox.'
      }];
      
      // Save
      Object.keys(loadedData).forEach(key => {
        localStorage.setItem(`erp_${activeId}_${key}`, JSON.stringify((loadedData as any)[key]));
      });
    }

    setData(loadedData);

    // RESTORE Google token if available in sessionStorage
    const savedToken = sessionStorage.getItem('erp_google_token');
    if (savedToken) {
      setGoogleToken(savedToken);
      setSyncStatus('Online');
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync to local whenever data state edits trigger
  const updateDataStateAndLocal = (updater: (prev: ERPDataState) => ERPDataState) => {
    setData(prev => {
      const next = updater(prev);
      if (activeProfileId) {
        saveAllToLocal(activeProfileId, next);
      }
      return next;
    });
  };

  const switchProfile = (profileId: string) => {
    setActiveProfileId(profileId);
    localStorage.setItem('erp_activeProfileId', profileId);

    const loadedData = initialDataState();
    Object.keys(loadedData).forEach(k => {
      const raw = localStorage.getItem(`erp_${profileId}_${k}`);
      if (raw) {
        try {
          (loadedData as any)[k] = JSON.parse(raw);
        } catch {
          // fallback
        }
      }
    });
    setData(loadedData);
    triggerToast(`Switched Business Profile: ${profiles.find(p => p.id === profileId)?.name || 'Default'}`);
  };

  const createProfile = (name: string) => {
    const profileId = uid('PROF');
    const newProfile: BusinessProfile = {
      id: profileId,
      name,
      createdAt: new Date().toISOString()
    };
    const nextProfiles = [...profiles, newProfile];
    setProfiles(nextProfiles);
    localStorage.setItem('erp_profiles', JSON.stringify(nextProfiles));
    
    // Seed new config profile
    const freshDataState = initialDataState();
    freshDataState.config.company.name = name;
    
    setData(freshDataState);
    setActiveProfileId(profileId);
    localStorage.setItem('erp_activeProfileId', profileId);
    
    saveAllToLocal(profileId, freshDataState);
    triggerToast(`Created Profile: ${name}`, 'success');
  };

  const renameProfile = (profileId: string, newName: string) => {
    const nextProfiles = profiles.map(p => p.id === profileId ? { ...p, name: newName } : p);
    setProfiles(nextProfiles);
    localStorage.setItem('erp_profiles', JSON.stringify(nextProfiles));
    if (activeProfileId === profileId) {
      updateDataStateAndLocal(prev => {
        const nextConfig = { ...prev.config, company: { ...prev.config.company, name: newName } };
        return { ...prev, config: nextConfig };
      });
    }
    triggerToast(`Renamed Business Profile to: ${newName}`);
  };

  const deleteProfile = (profileId: string) => {
    if (profiles.length <= 1) {
      triggerToast('Cannot delete the last business profile', 'error');
      return;
    }
    const nextProfiles = profiles.filter(p => p.id !== profileId);
    setProfiles(nextProfiles);
    localStorage.setItem('erp_profiles', JSON.stringify(nextProfiles));

    // Clear local storage for deleted profile keys
    const keys = ['customers', 'products', 'invoices', 'sales', 'finance', 'employees', 'suppliers', 'purchases', 'deliveries', 'offers', 'reports', 'auditLog', 'config'];
    keys.forEach(k => localStorage.removeItem(`erp_${profileId}_${k}`));

    if (activeProfileId === profileId) {
      const fallbackId = nextProfiles[0].id;
      switchProfile(fallbackId);
    } else {
      triggerToast('Business profile deleted');
    }
  };

  // CORE ENTITY ACTIONS

  // Customers
  const addCustomer = (cust: Omit<Customer, 'id' | 'createdAt' | 'updatedAt' | 'financialInfo'>) => {
    const newCust: Customer = {
      ...cust,
      id: uid('CUST'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      financialInfo: {
        creditLimit: (cust as any).creditLimit || 0,
        totalSpent: 0,
        totalPaid: 0,
        totalDue: 0,
        loyaltyPoints: 0,
        riskLevel: (cust as any).riskLevel || 'low'
      }
    };
    updateDataStateAndLocal(prev => ({
      ...prev,
      customers: [...prev.customers, newCust]
    }));
    addAudit('add_customer', `Added customer ${newCust.personalInfo.fullName}`);
    triggerToast(`Customer ${newCust.personalInfo.fullName} added successfully`, 'success');
  };

  const updateCustomer = (cust: Customer) => {
    const updated = { ...cust, updatedAt: new Date().toISOString() };
    updateDataStateAndLocal(prev => ({
      ...prev,
      customers: prev.customers.map(c => c.id === cust.id ? updated : c)
    }));
    addAudit('update_customer', `Updated customer ${cust.personalInfo.fullName} (${cust.id})`);
    triggerToast(`Customer ${cust.personalInfo.fullName} updated`);
  };

  const deleteCustomer = (id: string) => {
    const cust = data.customers.find(c => c.id === id);
    updateDataStateAndLocal(prev => ({
      ...prev,
      customers: prev.customers.filter(c => c.id !== id)
    }));
    addAudit('delete_customer', `Deleted customer ${cust?.personalInfo.fullName || id}`);
    triggerToast('Customer profile deleted');
  };

  // Products
  const addProduct = (prod: Omit<Product, 'id' | 'sku' | 'createdAt' | 'stock'> & { quantity: number; reorderLevel: number; warehouseLocation: string }) => {
    const newProd: Product = {
      id: uid('PROD'),
      sku: 'SKU-' + Date.now().toString(36).toUpperCase(),
      barcode: prod.barcode,
      basicInfo: prod.basicInfo,
      pricing: prod.pricing,
      stock: {
        quantity: prod.quantity,
        reserved: 0,
        available: prod.quantity,
        reorderLevel: prod.reorderLevel,
        warehouseLocation: prod.warehouseLocation
      },
      supplierId: prod.supplierId,
      status: prod.status,
      createdAt: new Date().toISOString()
    };
    updateDataStateAndLocal(prev => ({
      ...prev,
      products: [...prev.products, newProd]
    }));
    addAudit('add_product', `Added product SKU: ${newProd.sku} - ${newProd.basicInfo.name}`);
    triggerToast(`Product ${newProd.basicInfo.name} loaded into inventory`, 'success');
  };

  const updateProduct = (prod: Product) => {
    updateDataStateAndLocal(prev => ({
      ...prev,
      products: prev.products.map(p => p.id === prod.id ? prod : p)
    }));
    addAudit('update_product', `Updated product ${prod.basicInfo.name} (${prod.id})`);
    triggerToast(`Product ${prod.basicInfo.name} specs updated`);
  };

  const deleteProduct = (id: string) => {
    const prod = data.products.find(p => p.id === id);
    updateDataStateAndLocal(prev => ({
      ...prev,
      products: prev.products.filter(p => p.id !== id)
    }));
    addAudit('delete_product', `Deleted product ${prod?.basicInfo.name || id}`);
    triggerToast('Product deleted from active index');
  };

  // Invoices & Sales Engine
  const addInvoice = (inv: Omit<Invoice, 'id' | 'createdAt' | 'updatedAt' | 'calculations' | 'payment' | 'stockDeducted'> & { paidAmount: number; paymentMethod?: string; transactionId?: string }) => {
    const id = 'INV-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.random().toString(36).substr(2, 4).toUpperCase();
    
    // Subtotal calculations
    let subTotal = 0;
    let totalDiscount = 0;
    let totalTax = 0;
    
    inv.items.forEach(it => {
      const lineTotalRaw = it.quantity * it.unitPrice;
      const taxAmt = (lineTotalRaw - it.discount) * (it.taxRate / 100);
      subTotal += lineTotalRaw;
      totalDiscount += it.discount;
      totalTax += taxAmt;
    });

    let grandTotal = subTotal - totalDiscount + totalTax;
    
    // Check for Promo application
    let promoDiscount = 0;
    let finalPromo: Invoice['promo'] = null;
    if (inv.promo?.code) {
      const promoObj = data.offers.find(o => o.promoCode === inv.promo?.code && o.status === 'active');
      if (promoObj) {
        if (promoObj.type === 'percentage') {
          promoDiscount = subTotal * (promoObj.value / 100);
        } else {
          promoDiscount = Math.min(promoObj.value, subTotal);
        }
        grandTotal = Math.max(0, grandTotal - promoDiscount);
        finalPromo = {
          code: promoObj.promoCode,
          discountAmount: promoDiscount,
          promoId: promoObj.id
        };
      }
    }

    const paid = inv.paidAmount;
    const due = Math.max(0, grandTotal - paid);
    
    let paymentStatus: InvoicePayment['status'] = 'unpaid';
    if (paid >= grandTotal && grandTotal > 0) paymentStatus = 'paid';
    else if (paid > 0) paymentStatus = 'partial';

    const finalInvoice: Invoice = {
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      businessId: inv.businessId,
      customer: inv.customer,
      seller: inv.seller,
      items: inv.items.map(it => ({ ...it, subtotal: (it.quantity * it.unitPrice) - it.discount + ((it.quantity * it.unitPrice - it.discount) * (it.taxRate/100)) })),
      calculations: { subTotal, totalDiscount, totalTax, grandTotal },
      payment: {
        status: paymentStatus,
        method: inv.paymentMethod as any,
        paidAmount: paid,
        dueAmount: due,
        transactionId: inv.transactionId || ''
      },
      status: inv.status,
      dueDate: inv.dueDate,
      promo: finalPromo,
      note: inv.note,
      terms: inv.terms,
      termsApplied: inv.termsApplied,
      stockDeducted: inv.status === 'issued' || inv.status === 'paid'
    };

    updateDataStateAndLocal(prev => {
      const nextState = { ...prev };
      
      // Deduct active stock immediately if issued/paid
      if (finalInvoice.stockDeducted) {
        nextState.products = nextState.products.map(p => {
          const matchingItem = inv.items.find(it => it.productId === p.id);
          if (matchingItem) {
            const qty = matchingItem.quantity;
            const updatedStock = {
              ...p.stock,
              available: Math.max(0, p.stock.available - qty),
            };
            return { ...p, stock: updatedStock };
          }
          return p;
        });
      }

      // Add to Sales Ledger if valid transaction
      if (finalInvoice.status === 'issued' || finalInvoice.status === 'paid') {
        const costSum = inv.items.reduce((s, it) => {
          const matchingProd = nextState.products.find(p => p.id === it.productId);
          return s + (matchingProd?.pricing.costPrice || 0) * it.quantity;
        }, 0);

        const newSale: Sale = {
          id: uid('SALE'),
          invoiceId: id,
          customerId: inv.customer.customerId,
          seller: inv.seller,
          items: inv.items.map(it => ({ productId: it.productId, quantity: it.quantity, price: it.unitPrice })),
          totalAmount: grandTotal,
          profit: grandTotal - costSum,
          date: new Date().toISOString(),
          status: 'completed'
        };
        nextState.sales.push(newSale);

        // Add corresponding finance income
        const financeIncome: IncomeRecord = {
          id: uid('INC'),
          source: 'invoice',
          amount: paid,
          date: new Date().toISOString(),
          referenceId: id
        };
        nextState.finance.income.push(financeIncome);

        // Record customer ledger balances
        nextState.customers = nextState.customers.map(c => {
          if (c.id === inv.customer.customerId) {
            const nextSpent = (c.financialInfo.totalSpent || 0) + grandTotal;
            const nextPaid = (c.financialInfo.totalPaid || 0) + paid;
            return {
              ...c,
              financialInfo: {
                ...c.financialInfo,
                totalSpent: nextSpent,
                totalPaid: nextPaid,
                totalDue: Math.max(0, nextSpent - nextPaid),
                loyaltyPoints: c.financialInfo.loyaltyPoints + Math.floor(grandTotal)
              }
            };
          }
          return c;
        });
      }

      nextState.invoices.push(finalInvoice);
      return nextState;
    });

    addAudit('create_invoice', `Created invoice #${id} for customer ${inv.customer.name}`);
    triggerToast(`Invoice #${id} generated!`, 'success');
    
    // Check reorder boundaries for dynamic low stock alerts trigger
    inv.items.forEach(it => {
      const prod = data.products.find(p => p.id === it.productId);
      if (prod) {
        const remaining = prod.stock.available - it.quantity;
        if (remaining < prod.stock.reorderLevel) {
          triggerHeadsUp('⚠️ Stock Alert', `Product "${prod.basicInfo.name}" is below reorder level. Only ${Math.max(0, remaining)} remaining.`, '📦', 'alert');
        }
      }
    });
  };

  const updateInvoice = (inv: Invoice) => {
    // Standard update
    updateDataStateAndLocal(prev => {
      const idx = prev.invoices.findIndex(i => i.id === inv.id);
      if (idx === -1) return prev;
      const oldInv = prev.invoices[idx];
      const nextState = { ...prev };

      // Reverse original stock deduction if recorded
      if (oldInv.stockDeducted) {
        nextState.products = nextState.products.map(p => {
          const prevItem = oldInv.items.find(it => it.productId === p.id);
          if (prevItem) {
            return {
              ...p,
              stock: { ...p.stock, available: p.stock.available + prevItem.quantity }
            };
          }
          return p;
        });
      }

      // Re-apply next stock deduction if updated invoice holds issue/paid status
      const applyNextDeduction = inv.status === 'issued' || inv.status === 'paid';
      if (applyNextDeduction) {
        nextState.products = nextState.products.map(p => {
          const nextItem = inv.items.find(it => it.productId === p.id);
          if (nextItem) {
            return {
              ...p,
              stock: { ...p.stock, available: Math.max(0, p.stock.available - nextItem.quantity) }
            };
          }
          return p;
        });
      }

      // Adjust customer ledger totals
      if (oldInv.status === 'issued' || oldInv.status === 'paid') {
        nextState.customers = nextState.customers.map(c => {
          if (c.id === oldInv.customer.customerId) {
            const nextSpent = Math.max(0, (c.financialInfo.totalSpent || 0) - oldInv.calculations.grandTotal);
            const nextPaid = Math.max(0, (c.financialInfo.totalPaid || 0) - oldInv.payment.paidAmount);
            return {
              ...c,
              financialInfo: {
                ...c.financialInfo,
                totalSpent: nextSpent,
                totalPaid: nextPaid,
                totalDue: Math.max(0, nextSpent - nextPaid),
                loyaltyPoints: Math.max(0, c.financialInfo.loyaltyPoints - Math.floor(oldInv.calculations.grandTotal))
              }
            };
          }
          return c;
        });
      }

      if (inv.status === 'issued' || inv.status === 'paid') {
        nextState.customers = nextState.customers.map(c => {
          if (c.id === inv.customer.customerId) {
            const nextSpent = (c.financialInfo.totalSpent || 0) + inv.calculations.grandTotal;
            const nextPaid = (c.financialInfo.totalPaid || 0) + inv.payment.paidAmount;
            return {
              ...c,
              financialInfo: {
                ...c.financialInfo,
                totalSpent: nextSpent,
                totalPaid: nextPaid,
                totalDue: Math.max(0, nextSpent - nextPaid),
                loyaltyPoints: c.financialInfo.loyaltyPoints + Math.floor(inv.calculations.grandTotal)
              }
            };
          }
          return c;
        });
      }

      // Sync active associated Sale ledger entries
      nextState.sales = nextState.sales.filter(s => s.invoiceId !== inv.id);
      if (inv.status === 'issued' || inv.status === 'paid') {
        const costSum = inv.items.reduce((s, it) => {
          const matchingProd = nextState.products.find(p => p.id === it.productId);
          return s + (matchingProd?.pricing.costPrice || 0) * it.quantity;
        }, 0);
        
        nextState.sales.push({
          id: uid('SALE'),
          invoiceId: inv.id,
          customerId: inv.customer.customerId,
          seller: inv.seller,
          items: inv.items.map(it => ({ productId: it.productId, quantity: it.quantity, price: it.unitPrice })),
          totalAmount: inv.calculations.grandTotal,
          profit: inv.calculations.grandTotal - costSum,
          date: oldInv.createdAt,
          status: 'completed'
        });
      }

      // Sync associated income transactions
      nextState.finance.income = nextState.finance.income.filter(inc => inc.referenceId !== inv.id);
      if (inv.status === 'issued' || inv.status === 'paid') {
        nextState.finance.income.push({
          id: uid('INC'),
          source: 'invoice',
          amount: inv.payment.paidAmount,
          date: new Date().toISOString(),
          referenceId: inv.id
        });
      }

      nextState.invoices[idx] = { ...inv, stockDeducted: applyNextDeduction, updatedAt: new Date().toISOString() };
      return nextState;
    });

    addAudit('update_invoice', `Updated invoice ${inv.id}`);
    triggerToast(`Invoice ${inv.id} balances resolved`);
  };

  const deleteInvoice = (id: string) => {
    updateDataStateAndLocal(prev => {
      const found = prev.invoices.find(i => i.id === id);
      if (!found) return prev;
      const nextState = { ...prev };

      // Return stock back to inventory
      if (found.stockDeducted) {
        nextState.products = nextState.products.map(p => {
          const prevItem = found.items.find(it => it.productId === p.id);
          if (prevItem) {
            return {
              ...p,
              stock: { ...p.stock, available: p.stock.available + prevItem.quantity }
            };
          }
          return p;
        });
      }

      // Drop associated spent loyalty values on client CRM
      if (found.status === 'issued' || found.status === 'paid') {
        nextState.customers = nextState.customers.map(c => {
          if (c.id === found.customer.customerId) {
            const nextSpent = Math.max(0, (c.financialInfo.totalSpent || 0) - found.calculations.grandTotal);
            const nextPaid = Math.max(0, (c.financialInfo.totalPaid || 0) - found.payment.paidAmount);
            return {
              ...c,
              financialInfo: {
                ...c.financialInfo,
                totalSpent: nextSpent,
                totalPaid: nextPaid,
                totalDue: Math.max(0, nextSpent - nextPaid),
                loyaltyPoints: Math.max(0, c.financialInfo.loyaltyPoints - Math.floor(found.calculations.grandTotal))
              }
            };
          }
          return c;
        });
      }

      nextState.invoices = nextState.invoices.filter(i => i.id !== id);
      nextState.sales = nextState.sales.filter(s => s.invoiceId !== id);
      nextState.finance.income = nextState.finance.income.filter(inc => inc.referenceId !== id);

      return nextState;
    });

    addAudit('delete_invoice', `Deleted invoice #${id}`);
    triggerToast(`Invoice #${id} deleted from active state`);
  };

  // Finance Actions (Cash accounts)
  const addFinanceItem = (
    type: 'income' | 'expense', 
    record: { amount: number; date: string; source?: string; referenceId?: string; category?: string; note?: string }
  ) => {
    const id = uid(type === 'income' ? 'INC' : 'EXP');
    const timestamp = record.date ? new Date(record.date).toISOString() : new Date().toISOString();
    
    updateDataStateAndLocal(prev => {
      const nextState = { ...prev };
      if (type === 'income') {
        nextState.finance.income.push({
          id,
          source: (record.source as any) || 'manual',
          amount: record.amount,
          date: timestamp,
          referenceId: record.referenceId
        });
      } else {
        nextState.finance.expenses.push({
          id,
          category: record.category || 'General',
          amount: record.amount,
          date: timestamp,
          note: record.note || ''
        });
      }
      return nextState;
    });

    addAudit(`add_${type}`, `Recorded ${type} transaction: ID ${id}, Amount: ${record.amount}`);
    triggerToast(`Finance Ledger: ${type} of ${record.amount} recorded`, 'success');
  };

  const deleteFinanceItem = (type: 'income' | 'expense', id: string) => {
    updateDataStateAndLocal(prev => {
      if (type === 'income') {
        return {
          ...prev,
          finance: { ...prev.finance, income: prev.finance.income.filter(i => i.id !== id) }
        };
      } else {
        return {
          ...prev,
          finance: { ...prev.finance, expenses: prev.finance.expenses.filter(e => e.id !== id) }
        };
      }
    });

    addAudit(`delete_${type}`, `Removed ${type} transaction ${id}`);
    triggerToast(`Finance item deleted`);
  };

  // Employees (HRM)
  const addEmployee = (emp: Omit<Employee, 'id' | 'attendance' | 'payroll'>) => {
    const newEmp: Employee = {
      ...emp,
      id: uid('EMP'),
      attendance: [],
      payroll: []
    };
    updateDataStateAndLocal(prev => ({
      ...prev,
      employees: [...prev.employees, newEmp]
    }));
    addAudit('add_employee', `Hired employee ${newEmp.personalInfo.fullName}`);
    triggerToast(`Hired ${newEmp.personalInfo.fullName} successfully!`, 'success');
  };

  const updateEmployee = (emp: Employee) => {
    updateDataStateAndLocal(prev => ({
      ...prev,
      employees: prev.employees.map(e => e.id === emp.id ? emp : e)
    }));
    addAudit('update_employee', `Updated employee roster files for ${emp.personalInfo.fullName}`);
    triggerToast(`Roster updated for ${emp.personalInfo.fullName}`);
  };

  const deleteEmployee = (id: string) => {
    const emp = data.employees.find(e => e.id === id);
    updateDataStateAndLocal(prev => ({
      ...prev,
      employees: prev.employees.filter(e => e.id !== id)
    }));
    addAudit('delete_employee', `Released employee ${emp?.personalInfo.fullName || id}`);
    triggerToast('Employee records archived');
  };

  // Suppliers
  const addSupplier = (supp: Omit<Supplier, 'id' | 'suppliedProducts'>) => {
    const newSupp: Supplier = {
      ...supp,
      id: uid('SUPP'),
      suppliedProducts: []
    };
    updateDataStateAndLocal(prev => ({
      ...prev,
      suppliers: [...prev.suppliers, newSupp]
    }));
    addAudit('add_supplier', `Joined partner supplier ${newSupp.name}`);
    triggerToast(`Supplier ${newSupp.name} indexed successfully!`, 'success');
  };

  const updateSupplier = (supp: Supplier) => {
    updateDataStateAndLocal(prev => ({
      ...prev,
      suppliers: prev.suppliers.map(s => s.id === supp.id ? supp : s)
    }));
    addAudit('update_supplier', `Updated supplier ${supp.name}`);
    triggerToast(`Supplier ${supp.name} details saved`);
  };

  const deleteSupplier = (id: string) => {
    const sName = data.suppliers.find(s => s.id === id)?.name || id;
    updateDataStateAndLocal(prev => ({
      ...prev,
      suppliers: prev.suppliers.filter(s => s.id !== id)
    }));
    addAudit('delete_supplier', `Partner Supplier ${sName} terminated`);
    triggerToast('Supplier deleted from logistics list');
  };

  // Purchases
  const addPurchase = (purch: Omit<Purchase, 'id' | 'date'>) => {
    const pId = uid('PURCH');
    const newPurch: Purchase = {
      ...purch,
      id: pId,
      date: new Date().toISOString()
    };

    updateDataStateAndLocal(prev => {
      const nextState = { ...prev };
      
      // Stock values additions if completed order
      if (newPurch.status === 'completed') {
        newPurch.items.forEach(it => {
          nextState.products = nextState.products.map(p => {
            if (p.id === it.productId) {
              const qty = it.quantity;
              return {
                ...p,
                stock: {
                  ...p.stock,
                  quantity: p.stock.quantity + qty,
                  available: p.stock.available + qty
                }
              };
            }
            return p;
          });
        });

        // Push corresponding ledger expense
        nextState.finance.expenses.push({
          id: uid('EXP'),
          category: 'Inventory Purchase',
          amount: newPurch.totalCost,
          date: new Date().toISOString(),
          note: `Auto expense for Order ${pId}`
        });
      }

      nextState.purchases.push(newPurch);
      return nextState;
    });

    addAudit('create_purchase', `Placed purchase order ${pId} on supplier ${purch.supplierId}`);
    triggerToast(`Purchase order ${pId} recorded!`, 'success');
  };

  const updatePurchase = (purch: Purchase) => {
    updateDataStateAndLocal(prev => {
      const idx = prev.purchases.findIndex(p => p.id === purch.id);
      if (idx === -1) return prev;
      const oldPurch = prev.purchases[idx];
      const nextState = { ...prev };

      // Reverse stock from original purchase orders if complete
      if (oldPurch.status === 'completed') {
        oldPurch.items.forEach(it => {
          nextState.products = nextState.products.map(p => {
            if (p.id === it.productId) {
              const qty = it.quantity;
              return {
                ...p,
                stock: {
                  ...p.stock,
                  quantity: Math.max(0, p.stock.quantity - qty),
                  available: Math.max(0, p.stock.available - qty)
                }
              };
            }
            return p;
          });
        });
      }

      // Apply stock value additions for updated order state if completed
      if (purch.status === 'completed') {
        purch.items.forEach(it => {
          nextState.products = nextState.products.map(p => {
            if (p.id === it.productId) {
              const qty = it.quantity;
              return {
                ...p,
                stock: {
                  ...p.stock,
                  quantity: p.stock.quantity + qty,
                  available: p.stock.available + qty
                }
              };
            }
            return p;
          });
        });

        // Sync ledger expense entries
        nextState.finance.expenses = nextState.finance.expenses.filter(e => !e.note.includes(purch.id));
        nextState.finance.expenses.push({
          id: uid('EXP'),
          category: 'Inventory Purchase',
          amount: purch.totalCost,
          date: new Date().toISOString(),
          note: `Auto expense for Order ${purch.id}`
        });
      }

      nextState.purchases[idx] = purch;
      return nextState;
    });

    addAudit('update_purchase', `Updated purchase order ${purch.id}`);
    triggerToast(`Purchase order ${purch.id} reconciled`);
  };

  const deletePurchase = (id: string) => {
    updateDataStateAndLocal(prev => {
      const found = prev.purchases.find(p => p.id === id);
      if (!found) return prev;
      const nextState = { ...prev };

      if (found.status === 'completed') {
        found.items.forEach(it => {
          nextState.products = nextState.products.map(p => {
            if (p.id === it.productId) {
              return {
                ...p,
                stock: {
                  ...p.stock,
                  quantity: Math.max(0, p.stock.quantity - it.quantity),
                  available: Math.max(0, p.stock.available - it.quantity)
                }
              };
            }
            return p;
          });
        });
        nextState.finance.expenses = nextState.finance.expenses.filter(e => !e.note.includes(id));
      }

      nextState.purchases = nextState.purchases.filter(p => p.id !== id);
      return nextState;
    });

    addAudit('delete_purchase', `Deleted order files for purchase PO-${id}`);
    triggerToast('Purchase record archived');
  };

  // Deliveries
  const addDelivery = (del: Omit<Delivery, 'id' | 'tracking'>) => {
    const newDel: Delivery = {
      ...del,
      id: uid('DEL'),
      tracking: [{ timestamp: new Date().toISOString(), location: 'Central Warehouse Depot', status: del.status }]
    };
    updateDataStateAndLocal(prev => ({
      ...prev,
      deliveries: [...prev.deliveries, newDel]
    }));
    addAudit('add_delivery', `Dispatched courier delivery ${newDel.id} for invoice: ${del.invoiceId}`);
    triggerToast('Delivery file initialized');
  };

  const updateDelivery = (del: Delivery) => {
    const oldDel = data.deliveries.find(d => d.id === del.id);
    let updatedTracking = [...del.tracking];
    if (oldDel && oldDel.status !== del.status) {
      updatedTracking.push({
        timestamp: new Date().toISOString(),
        location: del.address.split(',')[1]?.trim() || del.address,
        status: del.status
      });
    }
    const finalDel = { ...del, tracking: updatedTracking };
    
    updateDataStateAndLocal(prev => ({
      ...prev,
      deliveries: prev.deliveries.map(d => d.id === del.id ? finalDel : d)
    }));
    addAudit('update_delivery', `Delivery status ${del.id} resolved to: ${del.status}`);
    triggerToast(`Delivery updated to ${del.status}`);
  };

  const deleteDelivery = (id: string) => {
    updateDataStateAndLocal(prev => ({
      ...prev,
      deliveries: prev.deliveries.filter(d => d.id !== id)
    }));
    addAudit('delete_delivery', `Deleted delivery dispatch ${id}`);
    triggerToast('Delivery routing cancelled');
  };

  // Offers & Promos
  const addOffer = (ofr: Omit<Offer, 'id' | 'createdAt'>) => {
    const newOffer: Offer = {
      ...ofr,
      id: uid('PROMO'),
      createdAt: new Date().toISOString()
    };
    updateDataStateAndLocal(prev => ({
      ...prev,
      offers: [...prev.offers, newOffer]
    }));
    addAudit('add_offer', `Arranged campaign discount promo code: ${newOffer.promoCode}`);
    triggerToast(`Promo ${newOffer.promoCode} active!`, 'success');
  };

  const updateOffer = (ofr: Offer) => {
    updateDataStateAndLocal(prev => ({
      ...prev,
      offers: prev.offers.map(o => o.id === ofr.id ? ofr : o)
    }));
    addAudit('update_offer', `Edited discount parameters for campaign ${ofr.promoCode}`);
    triggerToast(`Promo ${ofr.promoCode} updated`);
  };

  const deleteOffer = (id: string) => {
    const offerCode = data.offers.find(o => o.id === id)?.promoCode || id;
    updateDataStateAndLocal(prev => ({
      ...prev,
      offers: prev.offers.filter(o => o.id !== id)
    }));
    addAudit('delete_offer', `Promo campaign ${offerCode} dropped`);
    triggerToast('Discount code deactivated');
  };

  // Saved reports history
  const generateReport = () => {
    const totalSales = data.sales.reduce((s, sl) => s + sl.totalAmount, 0);
    const totalProfit = data.sales.reduce((s, sl) => s + sl.profit, 0);
    const totalExpense = data.finance.expenses.reduce((s, e) => s + e.amount, 0);
    
    const newReport: Report = {
      id: uid('RPT'),
      type: 'monthly',
      data: { totalSales, totalProfit, totalExpense },
      generatedAt: new Date().toISOString()
    };

    updateDataStateAndLocal(prev => ({
      ...prev,
      reports: [...prev.reports, newReport]
    }));

    addAudit('generate_report', `Generated snapshot report profile ${newReport.id}`);
    triggerToast('Business snapshot generated successfully', 'success');
  };

  // Settings
  const saveSettings = (config: SystemConfig) => {
    updateDataStateAndLocal(prev => ({
      ...prev,
      config
    }));
    addAudit('save_settings', 'Modified company settings and UI coordinates');
    triggerToast('Theme values and credentials saved successfully');
  };

  const clearAllLocalData = () => {
    if (activeProfileId) {
      const emptyState = initialDataState();
      // Keep profile switch reference
      setData(emptyState);
      saveAllToLocal(activeProfileId, emptyState);
      triggerToast('Local user workspace erased completely', 'warning');
    }
  };

  // Google Sign-In & Connected API backbones
  const gDriveConnect = () => {
    const clientId = data.config.settings.googleClientId;
    if (!clientId) {
      triggerToast('Supply a valid Google Client ID in settings first', 'error');
      return;
    }

    try {
      if (!(window as any).google?.accounts?.oauth2) {
        triggerToast('Google Identity library not loaded. Check internet access.', 'error');
        return;
      }
      
      const client = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: 'https://www.googleapis.com/auth/drive.file',
        callback: (response: any) => {
          if (response.error) {
            triggerToast(`Drive connection failed: ${response.error}`, 'error');
            return;
          }
          const token = response.access_token;
          setGoogleToken(token);
          sessionStorage.setItem('erp_google_token', token);
          setSyncStatus('Online');
          triggerToast('Google Drive backup sync connected!', 'success');
          
          // Initial download synchronization
          setSyncStatus('Syncing...');
          findOrCreateErpFile(token).then(async fileId => {
            const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
              headers: { Authorization: `Bearer ${token}` }
            });
            if (res.ok) {
              const driveData = await res.json();
              if (driveData && driveData.profiles && driveData.data) {
                // Merge data back on client
                localStorage.setItem('erp_profiles', JSON.stringify(driveData.profiles));
                setProfiles(driveData.profiles);
                
                Object.keys(driveData.data).forEach(pId => {
                  const profileData = driveData.data[pId];
                  Object.keys(profileData).forEach(k => {
                    localStorage.setItem(`erp_${pId}_${k}`, JSON.stringify(profileData[k]));
                  });
                });

                if (driveData.activeProfileId) {
                  localStorage.setItem('erp_activeProfileId', driveData.activeProfileId);
                  setActiveProfileId(driveData.activeProfileId);
                  const freshState = initialDataState();
                  Object.keys(freshState).forEach(k => {
                    const raw = localStorage.getItem(`erp_${driveData.activeProfileId}_${k}`);
                    if (raw) (freshState as any)[k] = JSON.parse(raw);
                  });
                  setData(freshState);
                }
                triggerToast('Loaded dynamic structures from Google Drive Backup', 'success');
              }
              setSyncStatus('Online');
            } else {
              // file empty, push current state up
              syncBackupToDrive(token, getBackupPayload());
            }
          }).catch(() => {
            setSyncStatus('Error');
          });
        }
      });
      client.requestAccessToken();
    } catch (e: any) {
      triggerToast(`Drive initialization crash: ${e.message}`, 'error');
    }
  };

  const gDriveDisconnect = () => {
    setGoogleToken(null);
    sessionStorage.removeItem('erp_google_token');
    setSyncStatus('Offline');
    triggerToast('Google Drive disconnected. Workspace remains local-only.');
  };

  const syncNow = () => {
    if (!googleToken) {
      triggerToast('Google Drive not connected. Sync requires sign-in API.', 'error');
      return;
    }
    const payload = getBackupPayload();
    syncBackupToDrive(googleToken, payload).then(() => {
      triggerToast('Google Drive Backup update complete!', 'success');
    });
  };

  return (
    <ERPContext.Provider value={{
      activeProfileId,
      profiles,
      data,
      toasts,
      activeHeadsUp,
      headsUpHistory,
      networkOnline,
      googleToken,
      syncStatus,
      
      switchProfile,
      createProfile,
      renameProfile,
      deleteProfile,
      
      addCustomer,
      updateCustomer,
      deleteCustomer,
      
      addProduct,
      updateProduct,
      deleteProduct,
      
      addInvoice,
      updateInvoice,
      deleteInvoice,
      
      addFinanceItem,
      deleteFinanceItem,
      
      addEmployee,
      updateEmployee,
      deleteEmployee,
      
      addSupplier,
      updateSupplier,
      deleteSupplier,
      
      addPurchase,
      updatePurchase,
      deletePurchase,
      
      addDelivery,
      updateDelivery,
      deleteDelivery,
      
      addOffer,
      updateOffer,
      deleteOffer,
      
      generateReport,
      saveSettings,
      addAudit,
      clearAllLocalData,
      
      triggerToast,
      triggerHeadsUp,
      clearHeadsUp,
      clearToast,
      
      gDriveConnect,
      gDriveDisconnect,
      syncNow
    }}>
      {children}
    </ERPContext.Provider>
  );
};

export const useERP = () => {
  const context = useContext(ERPContext);
  if (context === undefined) {
    throw new Error('useERP must be wrapped inside ERPProvider code block');
  }
  return context;
};
