/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ERPProvider, useERP } from './context/ERPContext';
import { 
  HeadsUpNotificationContainer, 
  NotificationHistoryDrawer 
} from './components/HeadsUpNotification';
import { DashboardView } from './components/DashboardView';
import { SettingsView } from './components/SettingsView';
import { 
  CustomerListView, ProductListView, InvoiceListView, SalesListView, 
  FinanceListView, EmployeeListView, SupplierListView, PurchaseListView, 
  DeliveryListView, OfferListView, ReportsListView, AuditLogView 
} from './components/ListViews';
import { 
  CustomerFormModal, ProductFormModal, InvoiceFormModal, FinanceFormModal, 
  EmployeeFormModal, SupplierFormModal, PurchaseFormModal, DeliveryFormModal, 
  OfferFormModal 
} from './components/Forms';
import { 
  LayoutDashboard, Users, Package, Receipt, TrendingUp, HandCoins, 
  Contact, Truck, ShoppingBag, Send, Tag, BarChart3, Settings2, 
  ShieldAlert, Bell, Menu, X, Plus, LogOut, LayoutGrid, CheckSquare, Zap
} from 'lucide-react';
import { Customer, Product, Invoice, Employee, Supplier, Purchase, Delivery, Offer } from './types';

function AppContent() {
  const { data, networkOnline, syncStatus, activeHeadsUp, headsUpHistory, profiles, activeProfileId } = useERP();
  const networkStatus = networkOnline ? 'online' : 'offline';
  
  // Navigation tabs state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [notificationDrawerOpen, setNotificationDrawerOpen] = useState<boolean>(false);

  // Form Modal States
  const [activeModal, setActiveModal] = useState<
    'customer' | 'product' | 'invoice' | 'finance_income' | 'finance_expense' | 'employee' | 'supplier' | 'purchase' | 'delivery' | 'offer' | null
  >(null);
  const [editingItem, setEditingItem] = useState<any>(null);

  // Modal Launcher Functions
  const handleEditCustomer = (c: Customer) => { setEditingItem(c); setActiveModal('customer'); };
  const handleEditProduct = (p: Product) => { setEditingItem(p); setActiveModal('product'); };
  const handleEditInvoice = (inv: Invoice) => { setEditingItem(inv); setActiveModal('invoice'); };
  const handleEditEmployee = (emp: Employee) => { setEditingItem(emp); setActiveModal('employee'); };
  const handleEditSupplier = (s: Supplier) => { setEditingItem(s); setActiveModal('supplier'); };
  const handleEditPurchase = (po: Purchase) => { setEditingItem(po); setActiveModal('purchase'); };
  const handleEditDelivery = (del: Delivery) => { setEditingItem(del); setActiveModal('delivery'); };
  const handleEditOffer = (o: Offer) => { setEditingItem(o); setActiveModal('offer'); };

  // Menu Definition
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'invoices', label: 'Invoices', icon: Receipt },
    { id: 'sales', label: 'Sales Ledger', icon: TrendingUp },
    { id: 'finance', label: 'Finance Ledger', icon: HandCoins },
    { id: 'employees', label: 'Employees', icon: Contact },
    { id: 'suppliers', label: 'Suppliers', icon: Truck },
    { id: 'purchases', label: 'Purchases PO', icon: ShoppingBag },
    { id: 'deliveries', label: 'Deliveries', icon: Send },
    { id: 'offers', label: 'Offers & Promo', icon: Tag },
    { id: 'reports', label: 'Reports Snapshots', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings2 },
    { id: 'audit', label: 'Audit Logs', icon: ShieldAlert },
  ];

  // Helper to open new item form based on current tab automatically, or show quick triggers
  const openNewItemModal = () => {
    setEditingItem(null);
    if (activeTab === 'customers') setActiveModal('customer');
    else if (activeTab === 'products') setActiveModal('product');
    else if (activeTab === 'invoices') setActiveModal('invoice');
    else if (activeTab === 'employees') setActiveModal('employee');
    else if (activeTab === 'suppliers') setActiveModal('supplier');
    else if (activeTab === 'purchases') setActiveModal('purchase');
    else if (activeTab === 'deliveries') setActiveModal('delivery');
    else if (activeTab === 'offers') setActiveModal('offer');
    else setActiveModal('invoice'); // fallback to checkout invoice creator
  };

  const getTabHeaderTitle = () => {
    const found = menuItems.find(m => m.id === activeTab);
    return found ? found.label : 'Enterprise App Workspace';
  };

  return (
    <div className="min-h-screen bg-[#FAF8FE] dark:bg-[#141218] text-neutral-800 dark:text-[#E6E1E5] flex font-sans subpixel-antialiased overflow-x-hidden">
      
      {/* 1. Headsup Countdown Toast sits top-center */}
      <HeadsUpNotificationContainer />

      {/* 2. Notification Audit Logs Slider Panel */}
      <NotificationHistoryDrawer 
        isOpen={notificationDrawerOpen} 
        onClose={() => setNotificationDrawerOpen(false)} 
      />

      {/* 3. SIDEBAR NAVIGATION PANELS (Desktop Mode) */}
      <aside className="hidden lg:flex flex-col w-72 bg-white dark:bg-[#1C1B1F] border-r border-neutral-200 dark:border-neutral-800 flex-shrink-0 select-none">
        
        {/* Sidebar Header Brand Card */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#6750A4] text-white flex items-center justify-center font-black text-lg shadow-md shadow-indigo-600/15">
              EP
            </div>
            <div>
              <h2 className="font-bold text-sm tracking-tight text-neutral-900 dark:text-neutral-50 leading-none">Enterprise ERP</h2>
              <span className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider block mt-1">Single-User Suite</span>
            </div>
          </div>
          {data.config.company.name && (
            <div className="mt-4 px-3.5 py-1.5 rounded-full bg-[#FAF8FE] dark:bg-neutral-950/20 border border-neutral-200 dark:border-neutral-800 text-[10px] text-neutral-450 font-bold truncate">
              🏢 {data.config.company.name}
            </div>
          )}
        </div>

        {/* Sidebar Navigation Items */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-1 scrollbar-thin scrollbar-thumb-neutral-250">
          {menuItems.map(item => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id); setMobileSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer select-none pointer-events-auto ${
                  active 
                    ? 'bg-[#EADDFF] text-[#21005D] dark:bg-[#4F378B] dark:text-[#EADDFF] shadow-sm' 
                    : 'text-neutral-500 hover:bg-neutral-50 dark:hover:bg-neutral-950/25 dark:text-neutral-400'
                }`}
              >
                <Icon className={`w-4 h-4 flex-shrink-0 ${active ? 'text-[#21005D] dark:text-[#EADDFF]' : 'text-neutral-400'}`} />
                <span>{item.label}</span>
                {item.id === 'invoices' && data.invoices.filter(i=>i.status==='unpaid').length > 0 && (
                  <span className="ml-auto w-4 h-4 rounded-full bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] text-[9px] flex items-center justify-center font-bold">
                    {data.invoices.filter(i=>i.status==='unpaid').length}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Bottom Profile Card */}
        <div className="p-4 border-t border-neutral-100 dark:border-neutral-900 select-none">
          <div className="p-3 bg-[#FAF8FE] dark:bg-neutral-950/15 rounded-2xl border border-neutral-150 dark:border-neutral-850 flex items-center justify-between">
            <div className="flex items-center gap-2 truncate">
              {data.config.logo ? (
                <img src={data.config.logo} alt="Logo" className="w-8 h-8 rounded-lg object-contain" />
              ) : (
                <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 font-extrabold flex items-center justify-center text-xs">
                  A
                </div>
              )}
              <div className="truncate">
                <div className="font-bold text-neutral-800 dark:text-neutral-200 text-xs">Active Profile</div>
                <div className="text-[10px] text-neutral-450 mt-0.5 font-mono truncate">{profiles.find(p => p.id === activeProfileId)?.name || 'Standard Corp'}</div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* MOBILE DRAWER NAVIGATION (Open on click) */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-[280] lg:hidden flex pointer-events-auto">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs cursor-pointer" onClick={() => setMobileSidebarOpen(false)} />
          <motion.div 
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'tween', duration: 0.2 }}
            className="relative w-72 max-w-xs bg-white dark:bg-[#1C1B1F] shadow-2xl flex flex-col h-full z-10"
          >
            <div className="p-5 border-b border-neutral-100 dark:border-neutral-900 flex items-center justify-between">
              <span className="font-bold text-neutral-900 dark:text-neutral-100 text-sm">Enterprise ERP Suite</span>
              <button onClick={() => setMobileSidebarOpen(false)} className="p-1 rounded-full hover:bg-neutral-105 text-neutral-500 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-4 space-y-1">
              {menuItems.map(item => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => { setActiveTab(item.id); setMobileSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold cursor-pointer select-none ${
                      active 
                        ? 'bg-[#EADDFF] text-[#21005D] dark:bg-[#4F378B] dark:text-[#EADDFF]' 
                        : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-950/25'
                    }`}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </motion.div>
        </div>
      )}

      {/* 4. MAIN CONTAINER FRAME */}
      <main className="flex-1 flex flex-col min-w-0 min-h-screen">
        
        {/* Main Workspace Dynamic Toolbar App Bar */}
        <header className="sticky top-0 z-[150] bg-white/70 dark:bg-[#141218]/75 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800 p-4 px-6 flex items-center justify-between select-none">
          
          <div className="flex items-center gap-3">
            {/* Mobile Hamburger toggle */}
            <button 
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl border border-neutral-250 dark:border-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-50 cursor-pointer pointer-events-auto"
            >
              <Menu className="w-5 h-5" />
            </button>
            
            <div>
              <h1 id="app-workspace-title" className="font-bold text-neutral-900 dark:text-neutral-50 text-sm md:text-base tracking-tight">{getTabHeaderTitle()}</h1>
              <p className="text-[10px] text-neutral-400 font-medium hidden md:block">Connected local database: compiled offline-ready</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            
            {/* Online-Offline status lights blink indicator, as requested! */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-50 dark:bg-neutral-950/20 border border-neutral-200 dark:border-neutral-850 shadow-sm leading-none font-semibold text-[10px]">
              <span className={`w-2.5 h-2.5 rounded-full ${networkStatus === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500 animate-blink'}`}></span>
              <span className="uppercase text-[9px] font-bold tracking-wider text-neutral-450">
                {networkStatus === 'online' ? 'Online' : 'Offline Mode'}
              </span>
            </div>

            {/* Notification History Drawer open trigger button */}
            <button
              onClick={() => setNotificationDrawerOpen(true)}
              className="p-2.5 rounded-full border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-[#1C1B1F] text-neutral-600 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-950/15 relative pointer-events-auto cursor-pointer"
              title="Alert Notifications Drawer"
            >
              <Bell className="w-4 h-4" />
              {headsUpHistory.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 text-[9px] font-bold rounded-full bg-rose-500 text-white flex items-center justify-center leading-none">
                  {headsUpHistory.length}
                </span>
              )}
            </button>

            {/* Quick Create Invoice Trigger (Floating context launcher) */}
            <button
              onClick={openNewItemModal}
              className="px-4.5 py-2 rounded-full bg-[#6750A4] dark:bg-[#D0BCFF] text-white dark:text-[#381E72] hover:opacity-90 font-bold text-xs flex items-center gap-1 shadow-sm cursor-pointer pointer-events-auto"
            >
              <Plus className="w-4 h-4" /> 
              <span className="hidden sm:inline">Add New</span>
            </button>

          </div>
        </header>

        {/* Dynamic Workspace Workspace Viewport Container */}
        <div id="erp-workspace-viewport" className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto space-y-6">
          {activeTab === 'dashboard' && <DashboardView />}
          {activeTab === 'customers' && <CustomerListView onEdit={handleEditCustomer} />}
          {activeTab === 'products' && <ProductListView onEdit={handleEditProduct} />}
          {activeTab === 'invoices' && <InvoiceListView onEdit={handleEditInvoice} />}
          {activeTab === 'sales' && <SalesListView />}
          {activeTab === 'finance' && (
            <div className="space-y-6">
              <div className="flex gap-2 justify-end pointer-events-auto">
                <button onClick={() => setActiveModal('finance_income')} className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-full cursor-pointer flex items-center gap-1.5 shadow-sm shadow-emerald-750/10">
                  <Plus className="w-4 h-4" /> Inflow Income
                </button>
                <button onClick={() => setActiveModal('finance_expense')} className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-full cursor-pointer flex items-center gap-1.5 shadow-sm shadow-rose-750/10">
                  <Plus className="w-4 h-4" /> Operating Expense
                </button>
              </div>
              <FinanceListView />
            </div>
          )}
          {activeTab === 'employees' && <EmployeeListView onEdit={handleEditEmployee} />}
          {activeTab === 'suppliers' && <SupplierListView onEdit={handleEditSupplier} />}
          {activeTab === 'purchases' && <PurchaseListView onEdit={handleEditPurchase} />}
          {activeTab === 'deliveries' && <DeliveryListView onEdit={handleEditDelivery} />}
          {activeTab === 'offers' && <OfferListView onEdit={handleEditOffer} />}
          {activeTab === 'reports' && <ReportsListView />}
          {activeTab === 'settings' && <SettingsView />}
          {activeTab === 'audit' && <AuditLogView />}
        </div>
      </main>

      {/* ==================== CONDITIONAL INPUT FORMS MODALS ==================== */}
      {activeModal === 'customer' && (
        <CustomerFormModal editCustomer={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'product' && (
        <ProductFormModal editProduct={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'invoice' && (
        <InvoiceFormModal editInvoice={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'finance_income' && (
        <FinanceFormModal type="income" onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'finance_expense' && (
        <FinanceFormModal type="expense" onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'employee' && (
        <EmployeeFormModal editEmployee={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'supplier' && (
        <SupplierFormModal editSupplier={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'purchase' && (
        <PurchaseFormModal editPurchase={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'delivery' && (
        <DeliveryFormModal editDelivery={editingItem} onClose={() => setActiveModal(null)} />
      )}
      {activeModal === 'offer' && (
        <OfferFormModal editOffer={editingItem} onClose={() => setActiveModal(null)} />
      )}

    </div>
  );
}

export default function App() {
  return (
    <ERPProvider>
      <AppContent />
    </ERPProvider>
  );
}
